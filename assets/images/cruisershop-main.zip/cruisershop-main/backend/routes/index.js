const router   = require('express').Router();
const auth     = require('../controllers/authController');
const products = require('../controllers/productController');
const orders   = require('../controllers/orderController');
const { requireAuth, requireAdmin, optionalAuth } = require('../middleware/auth');
const { authLimiter, passwordResetLimiter }       = require('../middleware/rateLimiter');
const db = require('../config/db');

// ── AUTH ──────────────────────────────────────────────
router.post('/auth/register',        authLimiter, auth.registerValidators, auth.register);
router.post('/auth/login',           authLimiter, auth.loginValidators, auth.login);
router.post('/auth/refresh',         auth.refresh);
router.post('/auth/logout',          auth.logout);
router.get ('/auth/verify-email',    auth.verifyEmail);
router.post('/auth/forgot-password', passwordResetLimiter, auth.forgotPassword);
router.post('/auth/reset-password',  auth.resetPassword);
router.get  ('/auth/me',             requireAuth, auth.me);
router.patch('/auth/me',             requireAuth, auth.updateMe);
router.post ('/auth/change-password',requireAuth, auth.changePassword);

// ── TERMÉKEK (publikus) ───────────────────────────────
router.get('/products',       products.getProducts);
router.get('/products/:slug', products.getProduct);
router.get('/categories',     products.getCategories);

// ── KÍVÁNSÁGLISTA ─────────────────────────────────────
router.get('/wishlist', requireAuth, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT w.product_id, w.created_at,
              p.name, p.slug, p.price, p.image_url, p.stock, p.is_active,
              c.name AS category_name, c.slug AS category_slug
       FROM wishlists w
       JOIN products p ON w.product_id = p.id
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE w.user_id = ?
       ORDER BY w.created_at DESC`,
      [req.user.id]
    );
    return res.json(rows);
  } catch (err) {
    console.error('Wishlist GET hiba:', err);
    return res.status(500).json({ message: 'Szerver hiba.' });
  }
});

router.post('/wishlist', requireAuth, async (req, res) => {
  const { product_id } = req.body;
  if (!product_id) return res.status(400).json({ message: 'product_id kötelező.' });
  try {
    const [prod] = await db.query('SELECT id FROM products WHERE id = ? AND is_active = 1', [product_id]);
    if (!prod.length) return res.status(404).json({ message: 'Termék nem található.' });
    await db.query(
      'INSERT IGNORE INTO wishlists (user_id, product_id) VALUES (?,?)',
      [req.user.id, product_id]
    );
    return res.json({ message: 'Hozzáadva a kívánságlistához.' });
  } catch (err) {
    console.error('Wishlist POST hiba:', err);
    return res.status(500).json({ message: 'Szerver hiba.' });
  }
});

router.delete('/wishlist/:productId', requireAuth, async (req, res) => {
  try {
    await db.query(
      'DELETE FROM wishlists WHERE user_id = ? AND product_id = ?',
      [req.user.id, req.params.productId]
    );
    return res.json({ message: 'Eltávolítva a kívánságlistáról.' });
  } catch (err) {
    console.error('Wishlist DELETE hiba:', err);
    return res.status(500).json({ message: 'Szerver hiba.' });
  }
});

// Wishlist IDs lekérése (gyors ellenőrzéshez)
router.get('/wishlist/ids', requireAuth, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT product_id FROM wishlists WHERE user_id = ?',
      [req.user.id]
    );
    return res.json(rows.map(r => r.product_id));
  } catch (err) {
    return res.status(500).json({ message: 'Szerver hiba.' });
  }
});

// ── RENDELÉSEK ────────────────────────────────────────
router.post('/orders/checkout', optionalAuth, orders.createCheckout);
router.get ('/orders/my',       requireAuth,  orders.myOrders);
router.get ('/orders/my/:uuid', requireAuth,  orders.myOrderDetail);

// ── ADMIN — Termékek ──────────────────────────────────
router.get   ('/admin/products',     requireAuth, requireAdmin, products.adminGetProducts);
router.post  ('/admin/products',     requireAuth, requireAdmin, products.productValidators, products.createProduct);
router.put   ('/admin/products/:id', requireAuth, requireAdmin, products.updateProduct);
router.delete('/admin/products/:id', requireAuth, requireAdmin, products.deleteProduct);

// ── ADMIN — Rendelések ────────────────────────────────
router.get  ('/admin/orders',              requireAuth, requireAdmin, orders.adminGetOrders);
router.get  ('/admin/orders/:uuid',        requireAuth, requireAdmin, orders.adminGetOrderDetail);
router.patch('/admin/orders/:uuid/status', requireAuth, requireAdmin, orders.adminUpdateStatus);
router.get  ('/admin/stats',               requireAuth, requireAdmin, orders.adminStats);

// ── ADMIN — Felhasználók ──────────────────────────────
router.get('/admin/users', requireAuth, requireAdmin, async (req, res) => {
  const { page = 1, limit = 50 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  const [rows] = await db.query(
    'SELECT id, uuid, email, name, phone, role, is_verified, is_banned, created_at FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?',
    [parseInt(limit), offset]
  );
  return res.json(rows);
});

// ── ADMIN — Felhasználó tiltás/feloldás ───────────────
router.patch('/admin/users/:uuid/ban', requireAuth, requireAdmin, async (req, res) => {
  const { ban } = req.body; // true = tiltás, false = feloldás
  const [rows] = await db.query('SELECT id, role FROM users WHERE uuid = ?', [req.params.uuid]);
  if (!rows.length) return res.status(404).json({ message: 'Felhasználó nem található.' });
  if (rows[0].role === 'admin') return res.status(403).json({ message: 'Admin felhasználót nem lehet letiltani.' });
  await db.query('UPDATE users SET is_banned = ? WHERE uuid = ?', [ban ? 1 : 0, req.params.uuid]);
  return res.json({ message: ban ? 'Felhasználó letiltva.' : 'Tiltás feloldva.' });
});

module.exports = router;