const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host:               process.env.DB_HOST,
  port:               parseInt(process.env.DB_PORT) || 3306,
  database:           process.env.DB_NAME,
  user:               process.env.DB_USER,
  password:           process.env.DB_PASSWORD,
  waitForConnections: true,
  connectionLimit:    10,
  queueLimit:         0,
  enableKeepAlive:    true,
  keepAliveInitialDelay: 0,
  timezone:           '+01:00',
  charset:            'utf8mb4',
});

// Kapcsolat tesztelése induláskor
pool.getConnection()
  .then(conn => {
    console.log('✓ MySQL kapcsolat OK');
    conn.release();
  })
  .catch(err => {
    console.error('✗ MySQL kapcsolat HIBA:', err.message);
    process.exit(1);
  });

module.exports = pool;
