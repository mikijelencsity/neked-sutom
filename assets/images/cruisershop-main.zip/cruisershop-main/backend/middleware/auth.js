const jwt = require('jsonwebtoken');
const db  = require('../config/db');

async function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Hitelesítés szükséges.' });
  }
  const token = header.slice(7);
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // check banned
    const [rows] = await db.query('SELECT id, uuid, email, role, is_banned FROM users WHERE id = ?', [decoded.id]);
    if (!rows.length) return res.status(401).json({ message: 'Felhasználó nem található.' });
    if (rows[0].is_banned) return res.status(403).json({ message: 'A fiók le van tiltva.' });
    req.user = rows[0];
    next();
  } catch {
    return res.status(401).json({ message: 'Érvénytelen vagy lejárt token.' });
  }
}

async function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Hozzáférés megtagadva.' });
  }
  next();
}

async function optionalAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) { return next(); }
  try {
    const decoded = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    const [rows] = await db.query('SELECT id, uuid, email, role FROM users WHERE id = ?', [decoded.id]);
    if (rows.length && !rows[0].is_banned) req.user = rows[0];
  } catch {}
  next();
}

module.exports = { requireAuth, requireAdmin, optionalAuth };
