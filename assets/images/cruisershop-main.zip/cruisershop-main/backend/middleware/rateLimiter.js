const rateLimit = require('express-rate-limit');

// Általános API limit
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 perc
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Túl sok kérés. Kérjük, próbálja újra 15 perc múlva.' },
});

// Szigorú limit bejelentkezéshez / regisztrációhoz
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Túl sok bejelentkezési kísérlet. Próbálja újra 15 perc múlva.' },
  skipSuccessfulRequests: true,
});

// Nagyon szigorú limit jelszó-visszaállításhoz
const passwordResetLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 óra
  max: 5,
  message: { message: 'Túl sok jelszó-visszaállítási kísérlet. Próbálja 1 óra múlva.' },
});

module.exports = { apiLimiter, authLimiter, passwordResetLimiter };
