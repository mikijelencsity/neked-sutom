const nodemailer = require('nodemailer');

// ── Lazy transporter — csak első híváskor jön létre ──────────
let _transporter = null;

function getTransporter() {
  if (_transporter) return _transporter;

  const host = process.env.EMAIL_HOST;
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;

  if (!host || !user || !pass) {
    throw new Error(
      `Email konfig hiányzik. Ellenőrizd a .env fájlt:\n` +
      `  EMAIL_HOST=${host || '❌ HIÁNYZIK'}\n` +
      `  EMAIL_USER=${user || '❌ HIÁNYZIK'}\n` +
      `  EMAIL_PASS=${pass ? '✓ beállítva' : '❌ HIÁNYZIK'}`
    );
  }

  _transporter = nodemailer.createTransport({
    host,
    port:   parseInt(process.env.EMAIL_PORT) || 587,
    secure: process.env.EMAIL_SECURE === 'true',
    auth:   { user, pass },
    // Gmail-hez:
    ...(host.includes('gmail') && {
      service: 'gmail',
    }),
    tls: {
      rejectUnauthorized: process.env.NODE_ENV === 'production',
    },
  });

  return _transporter;
}

// ── Induláskor ellenőrzés (server.js-ből hívható) ─────────────
async function verifyEmailConfig() {
  try {
    const t = getTransporter();
    await t.verify();
    console.log('  ✅ Email SMTP kapcsolat: OK');
    console.log(`     Host: ${process.env.EMAIL_HOST}:${process.env.EMAIL_PORT || 587}`);
    console.log(`     User: ${process.env.EMAIL_USER}`);
  } catch (err) {
    console.warn('  ⚠️  Email SMTP kapcsolat SIKERTELEN:');
    console.warn(`     ${err.message}`);
    console.warn('     Email küldés nem fog működni amíg ez nincs javítva!');
    console.warn('     Gmail esetén App Password szükséges: https://myaccount.google.com/apppasswords');
  }
}

// ── HTML sablon ───────────────────────────────────────────────
const baseStyle = `font-family: 'Helvetica Neue', Arial, sans-serif; background: #FDF8F5; color: #1A1210;`;
const btnStyle  = `display:inline-block; background:#C85C48; color:#fff !important; padding:14px 36px; text-decoration:none; font-weight:600; font-size:13px; letter-spacing:0.1em; text-transform:uppercase; border-radius:4px;`;

function emailWrapper(content) {
  return `<!DOCTYPE html><html lang="hu"><head><meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>The Cruiser Shop</title></head>
  <body style="${baseStyle} margin:0; padding:0;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#F5EDE8; padding:40px 20px;">
      <tr><td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px; background:#fff; border-radius:8px; overflow:hidden;">
          <tr><td style="background:#1C1C1E; padding:28px 40px;">
            <span style="font-family:'Outfit',Georgia,serif; font-size:22px; font-weight:700; color:#fff; letter-spacing:0.04em;">
              THE CRUISER<span style="color:#C85C48;">.</span>
            </span>
          </td></tr>
          <tr><td style="padding:40px;">${content}</td></tr>
          <tr><td style="background:#F5EDE8; padding:20px 40px; font-size:12px; color:#7A5060; text-align:center;">
            &copy; ${new Date().getFullYear()} The Cruiser Shop &nbsp;&middot;&nbsp;
            <a href="mailto:${process.env.EMAIL_USER}" style="color:#C85C48;">${process.env.EMAIL_USER}</a>
          </td></tr>
        </table>
      </td></tr>
    </table>
  </body></html>`;
}

// ── Segédfüggvény: küldés + naplózás ─────────────────────────
async function sendMail(options) {
  const t = getTransporter();
  const info = await t.sendMail({
    from: process.env.EMAIL_FROM || `"The Cruiser Shop" <${process.env.EMAIL_USER}>`,
    ...options,
  });
  console.log(`  📧 Email elküldve → ${options.to} [${options.subject}] (msgId: ${info.messageId})`);
  return info;
}

// ══════════════════════════════════════════════════════════════
// Email sablonok
// ══════════════════════════════════════════════════════════════

// 1. Rendelés visszaigazolás ───────────────────────────────────
async function sendOrderConfirmation(order, items) {
  const rows = items.map(i =>
    `<tr>
      <td style="padding:10px 0; border-bottom:1px solid #F5EDE8; font-size:14px;">${i.product_name}</td>
      <td style="padding:10px 0; border-bottom:1px solid #F5EDE8; text-align:center; font-size:14px;">${i.quantity} db</td>
      <td style="padding:10px 0; border-bottom:1px solid #F5EDE8; text-align:right; font-weight:600; font-size:14px; white-space:nowrap;">${Number(i.subtotal).toLocaleString('hu-HU')} Ft</td>
    </tr>`
  ).join('');

  const paymentLabel = order.payment_method === 'cod' ? 'Utánvétes fizetés' : 'Online bankkártyás fizetés';

  const html = emailWrapper(`
    <h2 style="font-family:Georgia,serif; font-size:26px; color:#1C1C1E; margin:0 0 8px;">Köszönjük a rendelést!</h2>
    <p style="color:#7A5060; margin:0 0 24px; line-height:1.7; font-size:14px;">
      Kedves <strong>${order.shipping_name}</strong>!<br>
      Rendelése beérkezett. Rendelésszám: <strong style="color:#C85C48;">#${order.uuid.slice(0,8).toUpperCase()}</strong>
    </p>

    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
      <thead>
        <tr style="font-size:11px; text-transform:uppercase; letter-spacing:0.1em; color:#7A5060;">
          <th style="text-align:left; padding-bottom:12px; border-bottom:2px solid #C85C48;">Termék</th>
          <th style="text-align:center; padding-bottom:12px; border-bottom:2px solid #C85C48;">Db</th>
          <th style="text-align:right; padding-bottom:12px; border-bottom:2px solid #C85C48;">Összeg</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr>
          <td colspan="2" style="padding-top:16px; font-weight:700; font-size:18px;">Végösszeg</td>
          <td style="padding-top:16px; font-weight:700; font-size:18px; text-align:right; color:#C85C48; white-space:nowrap;">
            ${Number(order.total_amount).toLocaleString('hu-HU')} Ft
          </td>
        </tr>
      </tfoot>
    </table>

    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
      <tr>
        <td width="50%" style="vertical-align:top; padding-right:16px;">
          <p style="font-size:12px; text-transform:uppercase; letter-spacing:0.08em; color:#7A5060; margin:0 0 8px; font-weight:600;">Szállítási cím</p>
          <p style="font-size:14px; line-height:1.8; color:#1C1C1E; margin:0;">
            <strong>${order.shipping_name}</strong><br>
            ${order.shipping_street}<br>
            ${order.shipping_zip} ${order.shipping_city}<br>
            ${order.shipping_country || 'Magyarország'}
            ${order.shipping_phone ? '<br>' + order.shipping_phone : ''}
          </p>
        </td>
        <td width="50%" style="vertical-align:top; padding-left:16px;">
          <p style="font-size:12px; text-transform:uppercase; letter-spacing:0.08em; color:#7A5060; margin:0 0 8px; font-weight:600;">Fizetési mód</p>
          <p style="font-size:14px; color:#1C1C1E; margin:0;">${paymentLabel}</p>
        </td>
      </tr>
    </table>

    <p style="color:#7A5060; font-size:13px; margin:0; line-height:1.7;">
      Kérdés esetén keress minket:<br>
      <a href="mailto:${process.env.EMAIL_USER}" style="color:#C85C48; font-weight:600;">${process.env.EMAIL_USER}</a>
    </p>
  `);

  await sendMail({
    to:      order.guest_email || order.user_email,
    subject: `The Cruiser Shop — Rendelés visszaigazolás #${order.uuid.slice(0,8).toUpperCase()}`,
    html,
  });
}

// 2. Email-cím megerősítés ─────────────────────────────────────
async function sendVerificationEmail(email, token, name) {
  const url  = `${process.env.FRONTEND_URL}/verify-email?token=${token}`;
  const html = emailWrapper(`
    <h2 style="font-family:Georgia,serif; font-size:26px; color:#1C1C1E; margin:0 0 16px;">Erősítsd meg az e-mail-címed</h2>
    <p style="color:#7A5060; line-height:1.7; margin:0 0 28px; font-size:14px;">
      Kedves <strong>${name}</strong>!<br>
      Köszönjük a regisztrációt a The Cruiser Shop-ban. Kattints az alábbi gombra a fiókod aktiválásához.
    </p>
    <a href="${url}" style="${btnStyle}">E-mail megerősítése</a>
    <p style="color:#7A5060; font-size:12px; margin:24px 0 0; line-height:1.6;">
      A link 24 óráig érvényes. Ha nem te regisztráltál, hagyd figyelmen kívül ezt az e-mailt.
    </p>
  `);

  await sendMail({
    to:      email,
    subject: 'The Cruiser Shop — E-mail-cím megerősítése',
    html,
  });
}

// 3. Jelszó visszaállítás ──────────────────────────────────────
async function sendPasswordReset(email, token, name) {
  const url  = `${process.env.FRONTEND_URL}/reset-password?token=${token}`;
  const html = emailWrapper(`
    <h2 style="font-family:Georgia,serif; font-size:26px; color:#1C1C1E; margin:0 0 16px;">Jelszó visszaállítása</h2>
    <p style="color:#7A5060; line-height:1.7; margin:0 0 28px; font-size:14px;">
      Kedves <strong>${name}</strong>!<br>
      Jelszó-visszaállítási kérelmet kaptunk ehhez a fiókhoz. Kattints az alábbi gombra az új jelszó beállításához.
    </p>
    <a href="${url}" style="${btnStyle}">Jelszó visszaállítása</a>
    <p style="color:#7A5060; font-size:12px; margin:24px 0 0; line-height:1.6;">
      A link <strong>1 óráig</strong> érvényes. Ha nem te kérted, hagyd figyelmen kívül ezt az e-mailt — a jelszavad nem változott meg.
    </p>
  `);

  await sendMail({
    to:      email,
    subject: 'The Cruiser Shop — Jelszó visszaállítása',
    html,
  });
}

// 4. Rendelés státusz frissítés ───────────────────────────────
async function sendStatusUpdate(email, name, orderUuid, status) {
  const statusMap = {
    processing: { label: 'Feldolgozás alatt',   icon: '⚙️', desc: 'A rendelésedet feldolgozzuk.' },
    shipped:    { label: 'Kiszállítás alatt',    icon: '🚚', desc: 'A csomag útban van feléd.' },
    delivered:  { label: 'Kézbesítve',           icon: '📦', desc: 'A rendelésed megérkezett.' },
    cancelled:  { label: 'Lemondva',             icon: '❌', desc: 'A rendelésed sajnos lemondásra került.' },
    refunded:   { label: 'Visszafizetve',         icon: '↩️', desc: 'A visszatérítés folyamatban van.' },
  };
  const s = statusMap[status] || { label: status, icon: '📋', desc: '' };

  const html = emailWrapper(`
    <h2 style="font-family:Georgia,serif; font-size:26px; color:#1C1C1E; margin:0 0 16px;">Rendelés állapota frissült</h2>
    <p style="color:#7A5060; line-height:1.7; margin:0 0 16px; font-size:14px;">
      Kedves <strong>${name}</strong>!<br>
      A <strong style="color:#C85C48;">#${orderUuid.slice(0,8).toUpperCase()}</strong> számú rendelésed állapota megváltozott:
    </p>
    <div style="background:#F5EDE8; border-left:4px solid #C85C48; padding:16px 20px; margin-bottom:24px; border-radius:4px;">
      <div style="font-size:24px; margin-bottom:6px;">${s.icon}</div>
      <div style="font-size:18px; font-weight:700; color:#C85C48;">${s.label}</div>
      ${s.desc ? `<div style="font-size:13px; color:#7A5060; margin-top:4px;">${s.desc}</div>` : ''}
    </div>
    <p style="color:#7A5060; font-size:13px; margin:0; line-height:1.7;">
      Kérdésed van? Írj nekünk:<br>
      <a href="mailto:${process.env.EMAIL_USER}" style="color:#C85C48; font-weight:600;">${process.env.EMAIL_USER}</a>
    </p>
  `);

  await sendMail({
    to:      email,
    subject: `The Cruiser Shop — Rendelés #${orderUuid.slice(0,8).toUpperCase()} — ${s.label}`,
    html,
  });
}

module.exports = {
  verifyEmailConfig,
  sendOrderConfirmation,
  sendVerificationEmail,
  sendPasswordReset,
  sendStatusUpdate,
};