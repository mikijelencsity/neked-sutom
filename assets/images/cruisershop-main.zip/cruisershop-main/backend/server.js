require('dotenv').config();
const express    = require('express');
const helmet     = require('helmet');
const cors       = require('cors');
const morgan     = require('morgan');
const cookieParser = require('cookie-parser');
const { apiLimiter } = require('./middleware/rateLimiter');
const routes     = require('./routes/index');
const orderCtrl  = require('./controllers/orderController');
const { verifyEmailConfig } = require('./utils/email');

const app = express();

// ── Biztonság ──────────────────────────────────────────
app.set('trust proxy', 1); // Nginx mögött
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'", 'js.stripe.com'],
      frameSrc:   ['js.stripe.com'],
      connectSrc: ["'self'", 'api.stripe.com'],
    },
  },
}));

// ── CORS ───────────────────────────────────────────────
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ── Stripe webhook — RAW body kell BEFORE json() ──────
app.post(
  '/api/orders/webhook',
  express.raw({ type: 'application/json' }),
  orderCtrl.stripeWebhook
);

// ── Body parsing ──────────────────────────────────────
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// ── Logging ───────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// ── Rate limit ────────────────────────────────────────
app.use('/api', apiLimiter);

// ── Routes ────────────────────────────────────────────
app.use('/api', routes);

// ── Health check ──────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

// ── 404 ───────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ message: 'A végpont nem található.' }));

// ── Globális hibakezelő ───────────────────────────────
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.stack || err.message);
  const status = err.status || err.statusCode || 500;
  const message = process.env.NODE_ENV === 'production'
    ? 'Szerver hiba. Kérjük, próbálja újra.'
    : (err.message || 'Szerver hiba.');
  res.status(status).json({ message });
});

// ── Indítás ───────────────────────────────────────────
const PORT = parseInt(process.env.PORT) || 5000;
app.listen(PORT, async () => {
  console.log(`\n  Cruiser Shop API`);
  console.log(`  Fut: http://localhost:${PORT}`);
  console.log(`  Mód: ${process.env.NODE_ENV || 'development'}\n`);

  // Email konfiguráció ellenőrzése induláskor
  await verifyEmailConfig();
  console.log('');
});

module.exports = app;