const db   = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');

const productValidators = [
  body('name').trim().isLength({ min: 2, max: 255 }).withMessage('A terméknév kötelező.'),
  body('price').isFloat({ min: 0 }).withMessage('Érvénytelen ár.'),
  body('stock').isInt({ min: 0 }).withMessage('Érvénytelen készlet.'),
  body('category_id').isInt({ min: 1 }).withMessage('Kategória kötelező.'),
];

// GET /api/products
async function getProducts(req, res) {
  const { category, featured, search, page = 1, limit = 12 } = req.query;
  const offset = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);
  const params = [];
  let where = 'WHERE p.is_active = 1';

  if (category) { where += ' AND c.slug = ?'; params.push(category); }
  if (featured === 'true') { where += ' AND p.is_featured = 1'; }
  if (search) {
    where += ' AND (p.name LIKE ? OR p.description LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }

  const [countRows] = await db.query(
    `SELECT COUNT(*) AS total FROM products p JOIN categories c ON p.category_id = c.id ${where}`,
    params
  );
  const total = countRows[0].total;

  const [rows] = await db.query(
    `SELECT p.id, p.uuid, p.name, p.slug, p.description, p.price, p.stock, p.image_url,
            p.is_featured, c.name AS category_name, c.slug AS category_slug
     FROM products p JOIN categories c ON p.category_id = c.id
     ${where} ORDER BY p.is_featured DESC, p.created_at DESC
     LIMIT ? OFFSET ?`,
    [...params, parseInt(limit), offset]
  );

  return res.json({ products: rows, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
}

// GET /api/products/:slug
async function getProduct(req, res) {
  const [rows] = await db.query(
    `SELECT p.*, c.name AS category_name, c.slug AS category_slug
     FROM products p JOIN categories c ON p.category_id = c.id
     WHERE p.slug = ? AND p.is_active = 1`,
    [req.params.slug]
  );
  if (!rows.length) return res.status(404).json({ message: 'A termék nem található.' });
  return res.json(rows[0]);
}

// GET /api/categories
async function getCategories(req, res) {
  const [rows] = await db.query('SELECT * FROM categories ORDER BY sort_order');
  return res.json(rows);
}

// --- ADMIN végpontok ---

// POST /api/admin/products
async function createProduct(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  const { name, description, price, stock, category_id, image_url, is_featured } = req.body;
  const slug = name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const uuid = uuidv4();

  const [result] = await db.query(
    'INSERT INTO products (uuid, category_id, name, slug, description, price, stock, image_url, is_featured) VALUES (?,?,?,?,?,?,?,?,?)',
    [uuid, category_id, name, slug, description || null, price, stock, image_url || null, is_featured ? 1 : 0]
  );
  return res.status(201).json({ message: 'Termék létrehozva.', id: result.insertId, uuid });
}

// PUT /api/admin/products/:id
async function updateProduct(req, res) {
  const { name, description, price, stock, category_id, image_url, is_featured, is_active } = req.body;
  const [result] = await db.query(
    `UPDATE products SET name=?, description=?, price=?, stock=?, category_id=?,
     image_url=?, is_featured=?, is_active=?, updated_at=NOW() WHERE id=?`,
    [name, description || null, price, stock, category_id, image_url || null,
     is_featured ? 1 : 0, is_active !== false ? 1 : 0, req.params.id]
  );
  if (!result.affectedRows) return res.status(404).json({ message: 'Termék nem található.' });
  return res.json({ message: 'Termék frissítve.' });
}

// DELETE /api/admin/products/:id (soft delete)
async function deleteProduct(req, res) {
  const [result] = await db.query('UPDATE products SET is_active = 0 WHERE id = ?', [req.params.id]);
  if (!result.affectedRows) return res.status(404).json({ message: 'Termék nem található.' });
  return res.json({ message: 'Termék archiválva.' });
}

// GET /api/admin/products (összes, is_active=0 is)
async function adminGetProducts(req, res) {
  const [rows] = await db.query(
    `SELECT p.*, c.name AS category_name FROM products p
     JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC`
  );
  return res.json(rows);
}

module.exports = { getProducts, getProduct, getCategories, createProduct, updateProduct, deleteProduct, adminGetProducts, productValidators };
