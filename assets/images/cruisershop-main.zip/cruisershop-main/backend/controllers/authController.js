const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db       = require('../config/db');
const { sendVerificationEmail, sendPasswordReset } = require('../utils/email');

// Token generálás
function generateTokens(user) {
  const payload = { id: user.id, uuid: user.uuid, email: user.email, role: user.role };
  const accessToken  = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN });
  const refreshToken = jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN });
  return { accessToken, refreshToken };
}

// Validátorok
const registerValidators = [
  body('email').isEmail().normalizeEmail().withMessage('Érvénytelen e-mail-cím.'),
  body('password')
    .isLength({ min: 8 }).withMessage('A jelszó legalább 8 karakter legyen.')
    .matches(/[A-Z]/).withMessage('A jelszó tartalmazzon nagybetűt.')
    .matches(/[0-9]/).withMessage('A jelszó tartalmazzon számot.'),
  body('name').trim().isLength({ min: 2, max: 200 }).withMessage('Teljes név kötelező.'),
];

const loginValidators = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
];

// POST /api/auth/register
async function register(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  const { email, password, name, phone } = req.body;

  const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
  if (existing.length) return res.status(409).json({ message: 'Ez az e-mail-cím már regisztrált.' });

  const hashed      = await bcrypt.hash(password, 12);
  const uuid        = uuidv4();
  const verifyToken = uuidv4();

  await db.query(
    'INSERT INTO users (uuid, email, password, name, phone, verify_token) VALUES (?,?,?,?,?,?)',
    [uuid, email, hashed, name.trim(), phone || null, verifyToken]
  );

  try {
    await sendVerificationEmail(email, verifyToken, name.trim());
  } catch (err) {
    console.warn('Email küldési hiba (nem fatális):', err.message);
  }

  return res.status(201).json({ message: 'Regisztráció sikeres. Kérjük, erősítse meg e-mail-címét.' });
}

// POST /api/auth/login
async function login(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  const { email, password } = req.body;
  const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
  const user = rows[0];

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ message: 'Hibás e-mail-cím vagy jelszó.' });
  }

  const { accessToken, refreshToken } = generateTokens(user);

  const hashedRefresh = await bcrypt.hash(refreshToken, 10);
  await db.query('UPDATE users SET refresh_token = ? WHERE id = ?', [hashedRefresh, user.id]);

  res.cookie('refreshToken', refreshToken, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge:   7 * 24 * 60 * 60 * 1000,
  });

  return res.json({
    accessToken,
    user: { id: user.uuid, email: user.email, name: user.name, role: user.role },
  });
}

// POST /api/auth/refresh
async function refresh(req, res) {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ message: 'Nincs érvényes munkamenet.' });

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
  } catch {
    return res.status(401).json({ message: 'Érvénytelen vagy lejárt refresh token.' });
  }

  const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [decoded.id]);
  const user = rows[0];
  if (!user || !user.refresh_token) return res.status(401).json({ message: 'Munkamenet nem található.' });

  const valid = await bcrypt.compare(token, user.refresh_token);
  if (!valid) return res.status(401).json({ message: 'Érvénytelen munkamenet.' });

  const { accessToken, refreshToken: newRefresh } = generateTokens(user);
  const hashedRefresh = await bcrypt.hash(newRefresh, 10);
  await db.query('UPDATE users SET refresh_token = ? WHERE id = ?', [hashedRefresh, user.id]);

  res.cookie('refreshToken', newRefresh, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge:   7 * 24 * 60 * 60 * 1000,
  });

  return res.json({ accessToken });
}

// POST /api/auth/logout
async function logout(req, res) {
  const token = req.cookies?.refreshToken;
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
      await db.query('UPDATE users SET refresh_token = NULL WHERE id = ?', [decoded.id]);
    } catch {}
  }
  res.clearCookie('refreshToken');
  return res.json({ message: 'Kijelentkezés sikeres.' });
}

// GET /api/auth/verify-email?token=...
async function verifyEmail(req, res) {
  const { token } = req.query;
  if (!token) return res.status(400).json({ message: 'Hiányzó token.' });

  const [rows] = await db.query('SELECT id FROM users WHERE verify_token = ?', [token]);
  if (!rows.length) return res.status(400).json({ message: 'Érvénytelen vagy már felhasznált token.' });

  await db.query('UPDATE users SET is_verified = 1, verify_token = NULL WHERE id = ?', [rows[0].id]);
  return res.json({ message: 'E-mail-cím megerősítve. Most már bejelentkezhet.' });
}

// POST /api/auth/forgot-password
async function forgotPassword(req, res) {
  const { email } = req.body;
  const [rows] = await db.query('SELECT id, name FROM users WHERE email = ?', [email]);
  if (rows.length) {
    const token   = uuidv4();
    const expires = new Date(Date.now() + 60 * 60 * 1000);
    await db.query(
      'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?',
      [token, expires, rows[0].id]
    );
    try {
      await sendPasswordReset(email, token, rows[0].name);
    } catch (err) {
      console.warn('Email küldési hiba:', err.message);
    }
  }
  return res.json({ message: 'Ha ez az e-mail-cím regisztrált, küldtünk egy visszaállítási linket.' });
}

// POST /api/auth/reset-password
async function resetPassword(req, res) {
  const { token, password } = req.body;
  if (!token || !password || password.length < 8) {
    return res.status(400).json({ message: 'Érvénytelen kérés.' });
  }

  const [rows] = await db.query(
    'SELECT id FROM users WHERE reset_token = ? AND reset_token_expires > NOW()',
    [token]
  );
  if (!rows.length) return res.status(400).json({ message: 'Érvénytelen vagy lejárt token.' });

  const hashed = await bcrypt.hash(password, 12);
  await db.query(
    'UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?',
    [hashed, rows[0].id]
  );
  return res.json({ message: 'Jelszó sikeresen megváltoztatva.' });
}

// GET /api/auth/me
async function me(req, res) {
  const [rows] = await db.query(
    'SELECT uuid, email, name, phone, role, is_verified, created_at FROM users WHERE id = ?',
    [req.user.id]
  );
  if (!rows.length) return res.status(404).json({ message: 'Felhasználó nem található.' });
  return res.json(rows[0]);
}


// PATCH /api/auth/me — profil adatok frissítése
async function updateMe(req, res) {
  const { name, phone } = req.body;
  if (!name || name.trim().length < 2) {
    return res.status(400).json({ message: 'A név legalább 2 karakter legyen.' });
  }
  await db.query(
    'UPDATE users SET name = ?, phone = ? WHERE id = ?',
    [name.trim(), phone || null, req.user.id]
  );
  const [rows] = await db.query(
    'SELECT uuid, email, name, phone, role, is_verified, created_at FROM users WHERE id = ?',
    [req.user.id]
  );
  return res.json(rows[0]);
}

// POST /api/auth/change-password — jelszó módosítás
async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword || newPassword.length < 8) {
    return res.status(400).json({ message: 'Érvénytelen kérés.' });
  }
  const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [req.user.id]);
  const user = rows[0];
  if (!user) return res.status(404).json({ message: 'Felhasználó nem található.' });

  const valid = await bcrypt.compare(currentPassword, user.password);
  if (!valid) return res.status(401).json({ message: 'A jelenlegi jelszó helytelen.' });

  if (!/[A-Z]/.test(newPassword)) return res.status(400).json({ message: 'Az új jelszónak tartalmaznia kell legalább egy nagybetűt.' });
  if (!/[0-9]/.test(newPassword)) return res.status(400).json({ message: 'Az új jelszónak tartalmaznia kell legalább egy számot.' });

  const hashed = await bcrypt.hash(newPassword, 12);
  await db.query('UPDATE users SET password = ? WHERE id = ?', [hashed, req.user.id]);
  return res.json({ message: 'Jelszó sikeresen megváltoztatva.' });
}

module.exports = {
  register, login, refresh, logout,
  verifyEmail, forgotPassword, resetPassword, me, updateMe, changePassword,
  registerValidators, loginValidators,
};