const stripe  = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { v4: uuidv4 } = require('uuid');
const db      = require('../config/db');
const { sendOrderConfirmation, sendStatusUpdate } = require('../utils/email');

// POST /api/orders/checkout
async function createCheckout(req, res) {
  const { items, shipping, guest_email } = req.body;

  if (!items || !items.length) return res.status(400).json({ message: 'Üres kosár.' });
  if (!shipping) return res.status(400).json({ message: 'Szállítási cím kötelező.' });
  if (!shipping.name || !shipping.street || !shipping.city || !shipping.zip) {
    return res.status(400).json({ message: 'Hiányos szállítási cím.' });
  }

  const ids = items.map(i => i.product_id);
  const [products] = await db.query(
    'SELECT id, name, price, stock FROM products WHERE id IN (?) AND is_active = 1',
    [ids]
  );

  const productMap = {};
  products.forEach(p => { productMap[p.id] = p; });

  let total = 0;
  const lineItems = [];
  const validatedItems = [];

  for (const item of items) {
    const product = productMap[item.product_id];
    if (!product) return res.status(400).json({ message: `Termék #${item.product_id} nem elérhető.` });
    if (product.stock < item.quantity) return res.status(400).json({ message: `${product.name} — nincs elegendő készlet.` });
    const qty      = Math.max(1, parseInt(item.quantity));
    const subtotal = parseFloat(product.price) * qty;
    total += subtotal;
    validatedItems.push({ product_id: product.id, product_name: product.name, price: product.price, quantity: qty, subtotal });
    lineItems.push({
      price_data: {
        currency: 'huf',
        product_data: { name: product.name },
        unit_amount: Math.round(parseFloat(product.price)),
      },
      quantity: qty,
    });
  }

  const orderUuid = uuidv4();
  const [orderResult] = await db.query(
    `INSERT INTO orders (uuid, user_id, guest_email, status, total_amount,
     shipping_name, shipping_street, shipping_city, shipping_zip, shipping_country, shipping_phone)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [
      orderUuid,
      req.user ? req.user.id : null,
      req.user ? null : (guest_email || null),
      'pending',
      total,
      shipping.name, shipping.street, shipping.city, shipping.zip,
      shipping.country || 'Magyarország', shipping.phone || null,
    ]
  );
  const orderId = orderResult.insertId;

  for (const item of validatedItems) {
    await db.query(
      'INSERT INTO order_items (order_id, product_id, product_name, price, quantity, subtotal) VALUES (?,?,?,?,?,?)',
      [orderId, item.product_id, item.product_name, item.price, item.quantity, item.subtotal]
    );
    await db.query('UPDATE products SET stock = stock - ? WHERE id = ?', [item.quantity, item.product_id]);
  }

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: lineItems,
    mode: 'payment',
    success_url: `${process.env.FRONTEND_URL}/rendeles-sikeres?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url:  `${process.env.FRONTEND_URL}/kosar`,
    customer_email: req.user ? req.user.email : (guest_email || undefined),
    metadata: { order_uuid: orderUuid },
  });

  await db.query('UPDATE orders SET stripe_session_id = ? WHERE id = ?', [session.id, orderId]);
  return res.json({ sessionId: session.id, url: session.url });
}

// POST /api/orders/webhook
async function stripeWebhook(req, res) {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook aláírás hiba:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session   = event.data.object;
    const orderUuid = session.metadata?.order_uuid;
    if (orderUuid) {
      await db.query(
        'UPDATE orders SET status = ?, payment_intent_id = ? WHERE uuid = ?',
        ['paid', session.payment_intent, orderUuid]
      );
      const [orders] = await db.query('SELECT * FROM orders WHERE uuid = ?', [orderUuid]);
      const [its]    = await db.query('SELECT * FROM order_items WHERE order_id = ?', [orders[0].id]);
      try {
        await sendOrderConfirmation({ ...orders[0], user_email: session.customer_email }, its);
      } catch (err) {
        console.warn('Email hiba:', err.message);
      }
    }
  }

  if (event.type === 'checkout.session.expired') {
    const session   = event.data.object;
    const orderUuid = session.metadata?.order_uuid;
    if (orderUuid) {
      const [orders] = await db.query(
        'SELECT id FROM orders WHERE uuid = ? AND status = ?', [orderUuid, 'pending']
      );
      if (orders.length) {
        const [its] = await db.query('SELECT * FROM order_items WHERE order_id = ?', [orders[0].id]);
        for (const item of its) {
          await db.query('UPDATE products SET stock = stock + ? WHERE id = ?', [item.quantity, item.product_id]);
        }
        await db.query('UPDATE orders SET status = ? WHERE uuid = ?', ['cancelled', orderUuid]);
      }
    }
  }

  res.json({ received: true });
}

// GET /api/orders/my — termékképekkel
async function myOrders(req, res) {
  const [orders] = await db.query(
    `SELECT o.uuid, o.status, o.total_amount, o.created_at,
            o.shipping_name, o.shipping_street, o.shipping_city, o.shipping_zip, o.shipping_country,
            o.payment_method
     FROM orders o WHERE o.user_id = ? ORDER BY o.created_at DESC`,
    [req.user.id]
  );
  // fetch items with product images
  for (const order of orders) {
    const [its] = await db.query(
      `SELECT oi.*, p.image_url, p.slug
       FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = (SELECT id FROM orders WHERE uuid = ?)`,
      [order.uuid]
    );
    order.items = its;
  }
  return res.json(orders);
}

// GET /api/orders/my/:uuid — termékképekkel
async function myOrderDetail(req, res) {
  const [orders] = await db.query(
    'SELECT * FROM orders WHERE uuid = ? AND user_id = ?',
    [req.params.uuid, req.user.id]
  );
  if (!orders.length) return res.status(404).json({ message: 'Rendelés nem található.' });
  const [its] = await db.query(
    `SELECT oi.*, p.image_url, p.slug
     FROM order_items oi
     LEFT JOIN products p ON oi.product_id = p.id
     WHERE oi.order_id = ?`,
    [orders[0].id]
  );
  return res.json({ ...orders[0], items: its });
}

// GET /api/admin/orders
async function adminGetOrders(req, res) {
  const { status, page = 1, limit = 20 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  const params = [];
  let where = '';
  if (status) { where = 'WHERE o.status = ?'; params.push(status); }

  const [[countRow]] = await db.query(
    `SELECT COUNT(*) AS total FROM orders o ${where}`,
    params
  );

  const [orders] = await db.query(
    `SELECT o.uuid, o.status, o.total_amount, o.shipping_name, o.shipping_city,
            o.shipping_street, o.shipping_zip, o.shipping_country, o.shipping_phone,
            o.payment_method, o.created_at,
            COALESCE(u.email, o.guest_email) AS customer_email,
            COALESCE(u.name, o.shipping_name) AS customer_name
     FROM orders o LEFT JOIN users u ON o.user_id = u.id
     ${where} ORDER BY o.created_at DESC LIMIT ? OFFSET ?`,
    [...params, parseInt(limit), offset]
  );
  return res.json({ orders, total: countRow.total });
}

// GET /api/admin/orders/:uuid — termékképekkel
async function adminGetOrderDetail(req, res) {
  const [orders] = await db.query(
    `SELECT o.*, COALESCE(u.email, o.guest_email) AS customer_email, u.name AS customer_name
     FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE o.uuid = ?`,
    [req.params.uuid]
  );
  if (!orders.length) return res.status(404).json({ message: 'Rendelés nem található.' });
  const [its] = await db.query(
    `SELECT oi.*, p.image_url, p.slug
     FROM order_items oi
     LEFT JOIN products p ON oi.product_id = p.id
     WHERE oi.order_id = ?`,
    [orders[0].id]
  );
  return res.json({ ...orders[0], items: its });
}

// PATCH /api/admin/orders/:uuid/status
async function adminUpdateStatus(req, res) {
  const allowed = ['pending','paid','processing','shipped','delivered','cancelled','refunded'];
  const { status } = req.body;
  if (!allowed.includes(status)) return res.status(400).json({ message: 'Érvénytelen státusz.' });

  const [orders] = await db.query('SELECT * FROM orders WHERE uuid = ?', [req.params.uuid]);
  if (!orders.length) return res.status(404).json({ message: 'Rendelés nem található.' });

  await db.query('UPDATE orders SET status = ? WHERE uuid = ?', [status, req.params.uuid]);

  if (['processing','shipped','delivered','cancelled','refunded'].includes(status)) {
    let userEmail, userName;
    if (orders[0].user_id) {
      const [us] = await db.query('SELECT email, name FROM users WHERE id = ?', [orders[0].user_id]);
      userEmail = us[0]?.email;
      userName  = us[0]?.name;
    } else {
      userEmail = orders[0].guest_email;
      userName  = orders[0].shipping_name;
    }
    if (userEmail) {
      try {
        await sendStatusUpdate(userEmail, userName || orders[0].shipping_name, req.params.uuid, status);
      } catch (err) {
        console.warn('Email hiba:', err.message);
      }
    }
  }

  return res.json({ message: 'Rendelés státusza frissítve.' });
}

// GET /api/admin/stats — havi bontással grafikonhoz
async function adminStats(req, res) {
  const [[revenue]]      = await db.query(
    "SELECT COALESCE(SUM(total_amount),0) AS total FROM orders WHERE status IN ('paid','processing','shipped','delivered')"
  );
  const [[orderCount]]   = await db.query("SELECT COUNT(*) AS total FROM orders WHERE status != 'cancelled'");
  const [[userCount]]    = await db.query("SELECT COUNT(*) AS total FROM users WHERE role = 'customer'");
  const [[pending]]      = await db.query("SELECT COUNT(*) AS total FROM orders WHERE status = 'pending'");
  const [[todayOrders]]  = await db.query(
    "SELECT COUNT(*) AS total FROM orders WHERE DATE(created_at) = CURDATE()"
  );
  const [[productCount]] = await db.query("SELECT COUNT(*) AS total FROM products WHERE is_active = 1");
  const [recentOrders]   = await db.query(
    `SELECT o.uuid, o.status, o.total_amount, o.created_at,
            COALESCE(u.email, o.guest_email) AS user_email,
            COALESCE(u.name, o.shipping_name) AS customer_name
     FROM orders o LEFT JOIN users u ON o.user_id = u.id
     ORDER BY o.created_at DESC LIMIT 5`
  );

  // Havi bevétel az elmúlt 6 hónapra (grafikon)
  const [monthlyRevenue] = await db.query(
    `SELECT DATE_FORMAT(created_at, '%Y-%m') AS month,
            COALESCE(SUM(total_amount), 0) AS revenue,
            COUNT(*) AS orders
     FROM orders
     WHERE status IN ('paid','processing','shipped','delivered')
       AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
     GROUP BY month
     ORDER BY month ASC`
  );

  // Rendelés státusz eloszlás (pie chart)
  const [statusBreakdown] = await db.query(
    `SELECT status, COUNT(*) AS count FROM orders GROUP BY status`
  );

  return res.json({
    total_revenue:    revenue.total,
    total_orders:     orderCount.total,
    total_users:      userCount.total,
    pending_orders:   pending.total,
    today_orders:     todayOrders.total,
    total_products:   productCount.total,
    recent_orders:    recentOrders,
    monthly_revenue:  monthlyRevenue,
    status_breakdown: statusBreakdown,
  });
}

module.exports = {
  createCheckout, stripeWebhook,
  myOrders, myOrderDetail,
  adminGetOrders, adminGetOrderDetail, adminUpdateStatus, adminStats,
};