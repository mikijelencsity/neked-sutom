-- =============================================
-- CRUISER SHOP - MySQL Adatbázis Séma v2.1
-- Futtatás: mysql -u root -p < schema.sql
-- =============================================

CREATE DATABASE IF NOT EXISTS cruiser_shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cruiser_shop;

-- Felhasználók
CREATE TABLE IF NOT EXISTS users (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uuid         CHAR(36) NOT NULL UNIQUE,
  email        VARCHAR(255) NOT NULL UNIQUE,
  password     VARCHAR(255) NOT NULL,
  name         VARCHAR(200) NOT NULL,
  phone        VARCHAR(30),
  role         ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  is_verified  TINYINT(1) NOT NULL DEFAULT 0,
  is_banned    TINYINT(1) NOT NULL DEFAULT 0,
  verify_token VARCHAR(255),
  reset_token  VARCHAR(255),
  reset_token_expires DATETIME,
  refresh_token VARCHAR(512),
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_uuid (uuid)
) ENGINE=InnoDB;

-- Kategóriák
CREATE TABLE IF NOT EXISTS categories (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  sort_order  INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- Termékek
CREATE TABLE IF NOT EXISTS products (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uuid          CHAR(36) NOT NULL UNIQUE,
  category_id   INT UNSIGNED NOT NULL,
  name          VARCHAR(255) NOT NULL,
  slug          VARCHAR(255) NOT NULL UNIQUE,
  description   TEXT,
  price         DECIMAL(12,2) NOT NULL,
  stock         INT NOT NULL DEFAULT 0,
  image_url         VARCHAR(512),
  original_price    DECIMAL(12,2),
  spec_motor_w      INT,
  spec_battery_v    INT,
  spec_battery_ah   DECIMAL(5,1),
  spec_max_speed    INT,
  spec_range_km     INT,
  spec_weight_kg    DECIMAL(5,1),
  spec_wheel_size   VARCHAR(20),
  spec_brake_front  VARCHAR(50),
  spec_brake_rear   VARCHAR(50),
  spec_gears        VARCHAR(80),
  spec_colors       VARCHAR(200),
  spec_accessories  VARCHAR(300),
  spec_pedal        TINYINT(1) DEFAULT 1,
  spec_throttle     TINYINT(1) DEFAULT 0,
  spec_max_load_kg  INT,
  spec_charge_hours DECIMAL(3,1),
  spec_battery_type VARCHAR(30),
  spec_license_required TINYINT(1) DEFAULT 0,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  is_featured   TINYINT(1) NOT NULL DEFAULT 0,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
  INDEX idx_slug (slug),
  INDEX idx_category (category_id),
  INDEX idx_active (is_active)
) ENGINE=InnoDB;

-- Szállítási címek
CREATE TABLE IF NOT EXISTS addresses (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  name         VARCHAR(255) NOT NULL,
  street       VARCHAR(255) NOT NULL,
  city         VARCHAR(100) NOT NULL,
  zip          VARCHAR(20) NOT NULL,
  country      VARCHAR(100) NOT NULL DEFAULT 'Magyarország',
  is_default   TINYINT(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Rendelések
CREATE TABLE IF NOT EXISTS orders (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uuid             CHAR(36) NOT NULL UNIQUE,
  user_id          INT UNSIGNED,
  guest_email      VARCHAR(255),
  status           ENUM('pending','paid','processing','shipped','delivered','cancelled','refunded') NOT NULL DEFAULT 'pending',
  total_amount     DECIMAL(12,2) NOT NULL,
  shipping_name    VARCHAR(255) NOT NULL,
  shipping_street  VARCHAR(255) NOT NULL,
  shipping_city    VARCHAR(100) NOT NULL,
  shipping_zip     VARCHAR(20) NOT NULL,
  shipping_country VARCHAR(100) NOT NULL DEFAULT 'Magyarország',
  shipping_phone   VARCHAR(30),
  payment_method   ENUM('stripe','cod') NOT NULL DEFAULT 'stripe',
  payment_intent_id VARCHAR(255),
  stripe_session_id VARCHAR(255),
  notes            TEXT,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_uuid (uuid),
  INDEX idx_user (user_id),
  INDEX idx_status (status),
  INDEX idx_payment_intent (payment_intent_id)
) ENGINE=InnoDB;

-- Rendelési tételek
CREATE TABLE IF NOT EXISTS order_items (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id     INT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED NOT NULL,
  product_name VARCHAR(255) NOT NULL,
  price        DECIMAL(12,2) NOT NULL,
  quantity     INT UNSIGNED NOT NULL,
  subtotal     DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Kívánságlista (Wishlist)
CREATE TABLE IF NOT EXISTS wishlists (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_wishlist (user_id, product_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_user_wishlist (user_id)
) ENGINE=InnoDB;

-- Cookie beleegyezések (GDPR)
CREATE TABLE IF NOT EXISTS cookie_consents (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED,
  session_id   VARCHAR(64),
  analytics    TINYINT(1) NOT NULL DEFAULT 0,
  marketing    TINYINT(1) NOT NULL DEFAULT 0,
  ip_hash      VARCHAR(64),
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Alap kategóriák
INSERT IGNORE INTO categories (name, slug, description, sort_order) VALUES
  ('Elektromos kerékpár', 'elektromos', 'Modern elektromos kerékpárok városra és túrára', 1),
  ('Túrakerékpár',        'tura',       'Terepre tervezett, erős túrakerékpárok', 2),
  ('Városi kerékpár',     'varosi',     'Elegáns és praktikus megoldások a mindennapi közlekedéshez', 3),
  ('Gyermekkerékpár',     'gyermek',    'Biztonságos kerékpárok a legkisebbeknek', 4);

-- Alap admin user (jelszó: Admin123!) — VÁLTOZTASD MEG ÉLESBEN!
INSERT IGNORE INTO users (uuid, email, password, name, role, is_verified)
VALUES (
  UUID(),
  'admin@cruisershop.hu',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TdxBKAMxSPiNHn9VPxN2xoMLhAaO',
  'Admin',
  'admin',
  1
);

-- Ha már létező adatbázisnál futtatod, add hozzá a wishlists táblát:
-- ALTER TABLE ... (ha a tábla hiányzik, a CREATE IF NOT EXISTS már kezeli)