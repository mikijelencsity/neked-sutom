# Cruiser Shop — Telepítési és beállítási útmutató

## 1. Követelmények
- Node.js 18+
- MySQL 8+
- Stripe fiók (webhook beállításhoz)

---

## 2. Adatbázis felállítása

```bash
mysql -u root -p < backend/schema.sql
```

Ez létrehozza az adatbázist, az összes táblát, az alapkategóriákat, és az admin felhasználót.

**Alapértelmezett admin:**
- Email: `admin@cruisershop.hu`
- Jelszó: `Admin123!` ← **ÉLESBEN FELTÉTLENÜL VÁLTOZTASD MEG!**

---

## 3. Backend (.env beállítása)

M�sold le a `.env` fájlt és töltsd ki:

```
DB_HOST=localhost
DB_USER=cruiser_user
DB_PASSWORD=<mysql jelszó>
DB_NAME=cruiser_shop

JWT_SECRET=<min. 64 véletlenszerű karakter>
JWT_REFRESH_SECRET=<másik min. 64 kar.>

STRIPE_SECRET_KEY=sk_live_...  (vagy sk_test_... fejlesztéshez)
STRIPE_WEBHOOK_SECRET=whsec_... (ld. 5. pont)

EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=info@cruisershop.hu
EMAIL_PASS=<Gmail App jelszó>
EMAIL_FROM="Cruiser Shop <info@cruisershop.hu>"

FRONTEND_URL=https://cruisershop.hu
```

---

## 4. Backend indítása

```bash
cd backend
npm install
npm start        # éles
# vagy
npm run dev      # fejlesztés (nodemon)
```

---

## 5. Stripe Webhook beállítása

### Fejlesztési környezetben (Stripe CLI)
```bash
# Stripe CLI telepítése: https://stripe.com/docs/stripe-cli
stripe login
stripe listen --forward-to http://localhost:5000/api/orders/webhook
# A CLI kiírja: "whsec_..." → ezt másold a .env-be STRIPE_WEBHOOK_SECRET értékként
```

### Éles környezetben (Stripe Dashboard)
1. Stripe Dashboard → Developers → Webhooks → Add endpoint
2. Endpoint URL: `https://te-domained.hu/api/orders/webhook`
3. Events to listen:
   - `checkout.session.completed`
   - `checkout.session.expired`
4. A webhook létrehozása után megkapod a `whsec_...` signing secret-et → másold a `.env`-be

---

## 6. Frontend indítása

```bash
cd frontend
npm install
npm start        # fejlesztés
npm run build    # production build
```

---

## 7. Árformátum az adatbázisban

Az árak **Forintban** (egész számként) kerülnek tárolásra a `DECIMAL(12,2)` oszlopban.
Pl.: 189 900 Ft → `189900.00`

**FONTOS:** Ne adj meg vesszőt az árakban. A frontend automatikusan formázza (189 900 Ft).

---

## 8. Admin jelszó megváltoztatása

Az adatbázisba kerülő alapértelmezett admin hash az `Admin123!` jelszóhoz tartozik.
Biztonságos környezetben:
1. Jelentkezz be az admin fiókba
2. Fiókom → Jelszó módosítás

---

## 9. Email beállítása (Gmail)

1. Gmail fiókban engedélyezd a 2FA-t
2. Google fiók → Biztonság → Alkalmazásjelszavak → Új jelszó (Cruiser Shop)
3. Másold az app jelszót a `.env` `EMAIL_PASS` mezőjébe

---

## 10. Cookie / GDPR megfelelőség

A sütibeleegyező banner automatikusan megjelenik első látogatáskor.
A beleegyezés a böngésző localStorage-ban kerül tárolásra (`cruiser_cookie_consent`).

Az `/adatvedelem` és `/aszf` oldalak valódi jogi tartalmát mielőbb frissítsd
a tényleges cégadatokkal és ügyvédi jóváhagyással!
