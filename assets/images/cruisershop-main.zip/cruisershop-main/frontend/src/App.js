import React, { useContext } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, AuthContext } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishListContext';

import Navbar         from './components/Navbar';
import Footer         from './components/Footer';
import CookieBanner   from './components/CookieBanner';
import ScrollToTop    from './components/ScrollToTop';
import Home           from './pages/Home';
import Shop           from './pages/Shop';
import ProductDetail  from './pages/ProductDetail';
import Cart           from './pages/Cart';
import Checkout       from './pages/Checkout';
import Login          from './pages/Login';
import Register       from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword  from './pages/ResetPassword';
import VerifyEmail    from './pages/VerifyEmail';
import OrderSuccess   from './pages/OrderSuccess';
import MyOrders       from './pages/MyOrders';
import ProfilePage    from './pages/Profilepage';
import AdminDashboard from './pages/admin/Dashboard';
import AdminProducts  from './pages/admin/Products';
import AdminOrders    from './pages/admin/Orders';
import AdminUsers     from './pages/admin/Users';
import Chatbot        from './components/Chatbot';
import Compare        from './pages/Compare';
import About          from './pages/About';
import Services       from './pages/Services';
import Contact        from './pages/Contact';
import { ASZFPage, AdatvedelemPage } from './pages/LegalPages';

function Spinner() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: 'var(--white)', flexDirection: 'column', gap: 20 }}>
      <img src="/logo.png" alt="The Cruiser Shop" style={{ height: 56 }} />
      <div className="spinner" style={{ width: 36, height: 36, borderWidth: 3 }} />
    </div>
  );
}

function RequireAuth({ children }) {
  const { user, loading } = useContext(AuthContext);
  if (loading) return <Spinner />;
  if (!user)   return <Navigate to="/bejelentkezes" replace />;
  return children;
}

function RequireAdmin({ children }) {
  const { user, loading } = useContext(AuthContext);
  if (loading)               return <Spinner />;
  if (!user)                 return <Navigate to="/bejelentkezes" replace />;
  if (user.role !== 'admin') return <Navigate to="/" replace />;
  return children;
}

function RedirectIfAuth({ children }) {
  const { user, loading } = useContext(AuthContext);
  if (loading) return null;
  if (user)    return <Navigate to="/" replace />;
  return children;
}

// Külön komponens, hogy useLocation működjön (BrowserRouter-en belül kell lennie)
function AppRoutes() {
  const location = useLocation();
  const isAdmin  = location.pathname.startsWith('/admin');

  return (
    <>
      <ScrollToTop />
      {/* Admin oldalakon nem jelenítjük meg a Navbart és a Footert */}
      {!isAdmin && <Navbar />}
      <Routes>
        {/* Publikus oldalak */}
        <Route path="/"                   element={<Home />} />
        <Route path="/kerekparok"         element={<Shop />} />
        <Route path="/kerekparok/:slug"   element={<ProductDetail />} />
        <Route path="/kosar"              element={<Cart />} />
        <Route path="/osszehasonlitas"    element={<Compare />} />
        <Route path="/rolunk"             element={<About />} />
        <Route path="/szolgaltatasaink"   element={<Services />} />
        <Route path="/kapcsolat"          element={<Contact />} />
        <Route path="/verify-email"       element={<VerifyEmail />} />
        <Route path="/reset-password"     element={<ResetPassword />} />
        {/* Jogi oldalak */}
        <Route path="/aszf"               element={<ASZFPage />} />
        <Route path="/adatvedelem"        element={<AdatvedelemPage />} />
        {/* Auth (bejelentkezett user-t átirányítja) */}
        <Route path="/bejelentkezes"      element={<RedirectIfAuth><Login /></RedirectIfAuth>} />
        <Route path="/regisztracio"       element={<RedirectIfAuth><Register /></RedirectIfAuth>} />
        <Route path="/elfelejtett-jelszo" element={<RedirectIfAuth><ForgotPassword /></RedirectIfAuth>} />
        {/* Bejelentkezés szükséges */}
        <Route path="/rendeles"           element={<RequireAuth><Checkout /></RequireAuth>} />
        <Route path="/rendeles-sikeres"   element={<RequireAuth><OrderSuccess /></RequireAuth>} />
        <Route path="/fiokom"             element={<RequireAuth><ProfilePage /></RequireAuth>} />
        <Route path="/rendeleiseim"       element={<RequireAuth><MyOrders /></RequireAuth>} />
        {/* Admin */}
        <Route path="/admin"              element={<RequireAdmin><AdminDashboard /></RequireAdmin>} />
        <Route path="/admin/termekek"     element={<RequireAdmin><AdminProducts /></RequireAdmin>} />
        <Route path="/admin/rendelesek"   element={<RequireAdmin><AdminOrders /></RequireAdmin>} />
        <Route path="/admin/felhasznalok" element={<RequireAdmin><AdminUsers /></RequireAdmin>} />
        {/* 404 */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {!isAdmin && <Footer />}
      {!isAdmin && <Chatbot />}
      {!isAdmin && <CookieBanner />}
    </>
  );
}

function AppInner() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <WishlistProvider>
        <CartProvider>
          <AppInner />
        </CartProvider>
      </WishlistProvider>
    </AuthProvider>
  );
}