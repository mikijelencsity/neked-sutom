import React, { useState, useRef, useEffect } from 'react';

const INITIAL = [
  { type: 'bot', text: 'Szia! 👋 Miben segíthetek? Kérdezz bátran a kerékpárokról, szállításról vagy bármi másról.' },
];

export default function Chatbot() {
  const [open, setOpen]           = useState(false);
  const [messages, setMessages]   = useState(INITIAL);
  const [inputVal, setInputVal]   = useState('');
  const [thinking, setThinking]   = useState(false);
  const messagesEndRef             = useRef(null);

  useEffect(() => {
    if (open) messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  const handleSend = () => {
    const text = inputVal.trim();
    if (!text || thinking) return;
    setMessages(prev => [...prev, { type: 'user', text }]);
    setInputVal('');
    setThinking(true);
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          type: 'bot',
          text: getBotResponse(text),
        },
      ]);
      setThinking(false);
    }, 900);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  return (
    <>
      {/* Chat window */}
      <div className={`chatbot-window${open ? ' open' : ''}`} role="dialog" aria-label="Segítség chat">
        <div className="chatbot-header">
          <div style={{ width:36, height:36, borderRadius:'var(--r-full)', background:'rgba(255,255,255,0.2)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
              <line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>
            </svg>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:700, color:'white', fontSize:'var(--fs-sm)' }}>Cruiser Segítség</div>
            <div style={{ fontSize:'var(--fs-xs)', color:'rgba(255,255,255,0.75)', display:'flex', alignItems:'center', gap:4 }}>
              <span style={{ width:7, height:7, borderRadius:'50%', background:'var(--success)', display:'inline-block' }}/>
              Online
            </div>
          </div>
          <button onClick={() => setOpen(false)} style={{ color:'rgba(255,255,255,0.7)', padding:4, transition:'color var(--t-fast)' }}
            onMouseEnter={e => e.currentTarget.style.color='white'}
            onMouseLeave={e => e.currentTarget.style.color='rgba(255,255,255,0.7)'}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>

        <div className="chatbot-messages">
          {messages.map((msg, i) => (
            <div key={i} className={`chatbot-msg ${msg.type}`}>{msg.text}</div>
          ))}
          {thinking && (
            <div className="chatbot-msg bot" style={{ display:'flex', gap:4, alignItems:'center' }}>
              <span style={{ width:6, height:6, borderRadius:'50%', background:'var(--text-faint)', animation:'bounce 1s infinite 0s' }}/>
              <span style={{ width:6, height:6, borderRadius:'50%', background:'var(--text-faint)', animation:'bounce 1s infinite 0.15s' }}/>
              <span style={{ width:6, height:6, borderRadius:'50%', background:'var(--text-faint)', animation:'bounce 1s infinite 0.3s' }}/>
              <style>{`@keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-6px)}}`}</style>
            </div>
          )}
          <div ref={messagesEndRef}/>
        </div>

        <div className="chatbot-input-row">
          <input
            className="form-input"
            style={{ height:40, borderRadius:'var(--r-full)', fontSize:'var(--fs-sm)' }}
            type="text"
            placeholder="Írj üzenetet..."
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={thinking}
          />
          <button
            className="btn btn-primary btn-sm"
            style={{ height:40, width:40, padding:0, borderRadius:'var(--r-full)', flexShrink:0 }}
            onClick={handleSend}
            disabled={thinking || !inputVal.trim()}
            aria-label="Küldés"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
              <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
          </button>
        </div>
      </div>

      {/* FAB */}
      <button
        className="chatbot-fab"
        onClick={() => setOpen(v => !v)}
        aria-label={open ? 'Chat bezárása' : 'Chat megnyitása'}
      >
        {open ? (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        ) : (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
            <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
          </svg>
        )}
      </button>
    </>
  );
}

function getBotResponse(text) {
  const t = text.toLowerCase();
  if (t.includes('szállít') || t.includes('kiszállít'))
    return 'Szállítás 1–3 munkanapon belül történik az ország egész területére. 80.000 Ft felett ingyenes!';
  if (t.includes('garancia'))
    return 'Minden kerékpárra 2 év gyártói garanciát vállalunk. Probléma esetén mi intézzük a javítást.';
  if (t.includes('beüzemel') || t.includes('összeszere'))
    return 'Igen! Minden kerékpárt személyesen kiszállítunk, összeszerelink és bemutatjuk a működését.';
  if (t.includes('visszaküld') || t.includes('visszavesz'))
    return '14 napos visszaküldési joggal élhetsz. Vedd fel velünk a kapcsolatot az info@cruisershop.hu e-mail címen.';
  if (t.includes('ár') || t.includes('fizet') || t.includes('stripe'))
    return 'Biztonságos online fizetés Stripe-on keresztül. Elfogadunk bankkártyát és egyéb online fizetési módokat.';
  if (t.includes('e-bike') || t.includes('elektromos'))
    return 'Több elektromos kerékpár modell is elérhető nálunk, Z-Tech márkától. Nézd meg a "Z-Tech e-bike" kategóriát!';
  return 'Köszönöm a kérdésed! Részletesebb információért kérlek hívj minket: +36 30 123 4567, vagy írj az info@cruisershop.hu e-mail címre.';
}
