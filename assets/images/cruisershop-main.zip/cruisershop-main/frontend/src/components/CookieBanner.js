import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const COOKIE_KEY = 'cruiser_cookie_consent';

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [prefs, setPrefs] = useState({ analytics: false, marketing: false });

  useEffect(() => {
    const stored = localStorage.getItem(COOKIE_KEY);
    if (!stored) setVisible(true);
  }, []);

  const save = (all) => {
    const consent = { necessary: true, analytics: all || prefs.analytics, marketing: all || prefs.marketing, date: new Date().toISOString() };
    localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-label="Cookie beállítások">
      <div style={{ flex: 1, minWidth: 200 }}>
        <p style={{ fontWeight: 600, marginBottom: 6, color: 'white', fontSize: 'var(--fs-sm)' }}>
          🍪 Sütiket (cookie-kat) használunk
        </p>
        <p style={{ fontSize: 'var(--fs-xs)', color: 'rgba(255,255,255,0.7)', lineHeight: 1.6, margin: 0 }}>
          A webshop működéséhez szükséges sütik mindig aktívak. Elemzési és marketing sütikhez kérjük a hozzájárulásodat.{' '}
          <Link to="/adatvedelem" style={{ color: 'var(--peach)' }}>Adatvédelmi tájékoztató</Link>
        </p>

        {showDetails && (
          <div style={{ marginTop: 'var(--sp-3)', display: 'flex', flexDirection: 'column', gap: 'var(--sp-2)' }}>
            {[
              { key: 'necessary', label: 'Szükséges sütik', desc: 'Mindig aktív – a webshop működéséhez elengedhetetlen.', always: true },
              { key: 'analytics', label: 'Elemzési sütik', desc: 'Segít megérteni, hogyan használják a látogatók az oldalt.' },
              { key: 'marketing', label: 'Marketing sütik', desc: 'Személyre szabott hirdetésekhez szükséges.' },
            ].map(item => (
              <label key={item.key} style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--sp-3)', cursor: item.always ? 'default' : 'pointer' }}>
                <input
                  type="checkbox"
                  checked={item.always || prefs[item.key]}
                  disabled={item.always}
                  onChange={e => !item.always && setPrefs(p => ({ ...p, [item.key]: e.target.checked }))}
                  style={{ marginTop: 2, accentColor: 'var(--peach)', width: 16, height: 16, flexShrink: 0 }}
                />
                <div>
                  <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 600, color: 'white' }}>{item.label}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)' }}>{item.desc}</div>
                </div>
              </label>
            ))}
          </div>
        )}

        <button
          onClick={() => setShowDetails(v => !v)}
          style={{ background: 'none', border: 'none', color: 'var(--peach)', fontSize: 'var(--fs-xs)', cursor: 'pointer', padding: '4px 0', marginTop: 'var(--sp-2)', fontFamily: 'var(--font-body)' }}
        >
          {showDetails ? '▲ Kevesebb' : '▼ Részletes beállítások'}
        </button>
      </div>

      <div className="cookie-banner__actions">
        {showDetails && (
          <button className="btn btn-sm" style={{ background: 'rgba(255,255,255,0.12)', color: 'white' }} onClick={() => save(false)}>
            Kiválasztottak mentése
          </button>
        )}
        <button className="btn btn-sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white' }} onClick={() => save(false)}>
          Csak szükséges
        </button>
        <button className="btn btn-sm btn-primary" onClick={() => save(true)}>
          Összes elfogadása
        </button>
      </div>
    </div>
  );
}
