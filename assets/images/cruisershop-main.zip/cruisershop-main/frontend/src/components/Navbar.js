import React, { useState, useEffect, useContext, useRef, useCallback } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { CartContext } from '../context/CartContext';

/* ── Profil dropdown ────────────────────────────────────── */
function ProfileDropdown({ user, onLogout, onClose }) {
  const navigate = useNavigate();

  const initials = user.name
    ? user.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
    : user.email[0].toUpperCase();

  const menuItems = [
    {
      icon: (
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
      ),
      label: 'Profilom',
      to: '/fiokom',
    },
    {
      icon: (
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/>
          <line x1="16" y1="17" x2="8" y2="17"/>
        </svg>
      ),
      label: 'Rendeléseim',
      to: '/rendeleiseim',
    },
    {
      icon: (
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
          <path d="M1 1h4l2.68 13.39a2 2 0 001.98 1.61h9.68a2 2 0 001.98-1.71L23 6H6"/>
        </svg>
      ),
      label: 'Kosaram',
      to: '/kosar',
    },
  ];

  if (user.role === 'admin') {
    menuItems.push({
      icon: (
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M12 2L2 7l10 5 10-5-10-5z"/>
          <path d="M2 17l10 5 10-5"/>
          <path d="M2 12l10 5 10-5"/>
        </svg>
      ),
      label: 'Admin panel',
      to: '/admin',
      highlight: true,
    });
  }

  return (
    <div style={{
      position: 'absolute',
      top: 'calc(100% + 10px)',
      right: 0,
      width: 240,
      background: 'var(--white)',
      borderRadius: 'var(--r-xl)',
      border: '1px solid var(--border)',
      boxShadow: '0 8px 32px rgba(0,0,0,0.13)',
      zIndex: 1000,
      overflow: 'hidden',
      animation: 'dropdownFadeIn 0.15s ease',
    }}>
      {/* Header – névjegykártya */}
      <div style={{
        padding: 'var(--sp-4)',
        borderBottom: '1px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--sp-3)',
        background: 'var(--gray-50)',
      }}>
        <div style={{
          width: 40, height: 40, borderRadius: 'var(--r-full)',
          background: 'var(--coral)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--white)',
          fontFamily: 'var(--font-display)',
          fontWeight: 700,
          fontSize: 'var(--fs-sm)',
          flexShrink: 0,
          letterSpacing: '0.02em',
        }}>
          {initials}
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{
            fontWeight: 600,
            fontSize: 'var(--fs-sm)',
            color: 'var(--text)',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
            {user.name || 'Felhasználó'}
          </div>
          <div style={{
            fontSize: 'var(--fs-xs)',
            color: 'var(--text-muted)',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
            {user.email}
          </div>
        </div>
      </div>

      {/* Menu items */}
      <div style={{ padding: '6px 0' }}>
        {menuItems.map(item => (
          <button
            key={item.to}
            onClick={() => { navigate(item.to); onClose(); }}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              gap: 'var(--sp-3)',
              padding: '9px var(--sp-4)',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'var(--font-body)',
              fontSize: 'var(--fs-sm)',
              fontWeight: item.highlight ? 600 : 500,
              color: item.highlight ? 'var(--peach-hover)' : 'var(--text-2)',
              textAlign: 'left',
              transition: 'background 0.12s',
            }}
            onMouseEnter={e => e.currentTarget.style.background = item.highlight ? 'var(--peach-light)' : 'var(--gray-50)'}
            onMouseLeave={e => e.currentTarget.style.background = 'none'}
          >
            <span style={{ color: item.highlight ? 'var(--peach-hover)' : 'var(--text-muted)', flexShrink: 0 }}>
              {item.icon}
            </span>
            {item.label}
          </button>
        ))}
      </div>

      {/* Kijelentkezés */}
      <div style={{ borderTop: '1px solid var(--border)', padding: '6px 0' }}>
        <button
          onClick={() => { onLogout(); onClose(); }}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            gap: 'var(--sp-3)',
            padding: '9px var(--sp-4)',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--fs-sm)',
            fontWeight: 500,
            color: 'var(--error)',
            textAlign: 'left',
            transition: 'background 0.12s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'var(--error-bg)'}
          onMouseLeave={e => e.currentTarget.style.background = 'none'}
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
            <polyline points="16 17 21 12 16 7"/>
            <line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
          Kijelentkezés
        </button>
      </div>
    </div>
  );
}

/* ── Navbar ─────────────────────────────────────────────── */
export default function Navbar() {
  const { user, logout }   = useContext(AuthContext);
  const { cartCount }      = useContext(CartContext);
  const navigate           = useNavigate();
  const [scrolled, setScrolled]       = useState(false);
  const [menuOpen, setMenuOpen]       = useState(false);
  const [search, setSearch]           = useState('');
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef                    = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  // Kattintás a dropdownon kívülre → bezárjuk
  useEffect(() => {
    if (!profileOpen) return;
    const handler = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [profileOpen]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/kerekparok?search=${encodeURIComponent(search.trim())}`);
      setSearch('');
      setMenuOpen(false);
    }
  };

  const handleLogout = useCallback(async () => {
    await logout();
    navigate('/');
    setMenuOpen(false);
  }, [logout, navigate]);

  const isAdmin = user?.role === 'admin';

  const navLinks = [
    { to: '/', label: 'Kezdőlap', end: true },
    { to: '/kerekparok', label: 'Kerékpárok' },
    { to: '/rolunk', label: 'Vélemények' },
    { to: '/szolgaltatasaink', label: 'Szolgáltatások' },
    { to: '/kapcsolat', label: 'Kapcsolat' },
  ];

  return (
    <>
      <style>{`
        @keyframes dropdownFadeIn {
          from { opacity: 0; transform: translateY(-6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .navbar__link--admin {
          color: var(--peach-hover) !important;
          background: var(--peach-light) !important;
        }
        .navbar__link--admin:hover { background: #fde8c7 !important; }
        .navbar__link--admin.active {
          color: var(--peach-hover) !important;
          background: #fde8c7 !important;
        }
      `}</style>

      <header className={`navbar${scrolled ? ' scrolled' : ''}`}>
        <div className="navbar__inner">
          {/* Logo */}
          <Link to="/" className="navbar__logo" onClick={() => setMenuOpen(false)}>
            <img src="/logo.png" alt="The Cruiser Shop" />
          </Link>

          {/* Desktop Nav */}
          <nav className="navbar__nav">
            {navLinks.map(l => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.end}
                className={({ isActive }) => `navbar__link${isActive ? ' active' : ''}`}
              >
                {l.label}
              </NavLink>
            ))}
            {isAdmin && (
              <NavLink
                to="/admin"
                className={({ isActive }) => `navbar__link navbar__link--admin${isActive ? ' active' : ''}`}
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                  style={{ marginRight: 5, verticalAlign: 'middle' }}>
                  <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                  <path d="M2 17l10 5 10-5"/>
                  <path d="M2 12l10 5 10-5"/>
                </svg>
                Admin
              </NavLink>
            )}
          </nav>

          {/* Search */}
          <div className="navbar__search-wrap">
            <form onSubmit={handleSearch} style={{ position: 'relative' }}>
              <span className="navbar__search-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                </svg>
              </span>
              <input
                className="navbar__search"
                type="text"
                placeholder="Kerékpár keresése..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </form>
          </div>

          {/* Actions */}
          <div className="navbar__actions">
            {/* Kosár */}
            <Link to="/kosar" className="navbar__icon-btn" aria-label="Kosár">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                <path d="M1 1h4l2.68 13.39a2 2 0 001.98 1.61h9.68a2 2 0 001.98-1.71L23 6H6"/>
              </svg>
              {cartCount > 0 && (
                <span className="navbar__cart-count">{cartCount > 9 ? '9+' : cartCount}</span>
              )}
            </Link>

            {/* Profil */}
            {user ? (
              <div ref={profileRef} style={{ position: 'relative' }}>
                <button
                  className="navbar__icon-btn"
                  onClick={() => setProfileOpen(v => !v)}
                  aria-label="Profil menü"
                  aria-expanded={profileOpen}
                  style={{
                    background: profileOpen ? 'var(--coral-light)' : undefined,
                    color: profileOpen ? 'var(--coral)' : undefined,
                  }}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                </button>
                {profileOpen && (
                  <ProfileDropdown
                    user={user}
                    onLogout={handleLogout}
                    onClose={() => setProfileOpen(false)}
                  />
                )}
              </div>
            ) : (
              <Link to="/bejelentkezes" className="btn btn-primary btn-sm" style={{ marginLeft: 4 }}>
                Bejelentkezés
              </Link>
            )}

            {/* Mobile hamburger */}
            <button
              className="navbar__icon-btn navbar__mobile-btn"
              onClick={() => setMenuOpen(v => !v)}
              aria-label={menuOpen ? 'Menü bezárása' : 'Menü megnyitása'}
            >
              {menuOpen ? (
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              ) : (
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
                </svg>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div className={`mobile-menu${menuOpen ? ' open' : ''}`} role="dialog" aria-label="Navigációs menü">
        <form onSubmit={handleSearch} style={{ position: 'relative', marginBottom: 8 }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
          </span>
          <input
            className="form-input"
            style={{ paddingLeft: 42, borderRadius: 'var(--r-full)' }}
            type="text"
            placeholder="Kerékpár keresése..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </form>

        <div style={{ height: 1, background: 'var(--border)', margin: '8px 0 16px' }} />

        {navLinks.map(l => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.end}
            className={({ isActive }) => `mobile-menu__link${isActive ? ' active' : ''}`}
            onClick={() => setMenuOpen(false)}
          >
            {l.label}
          </NavLink>
        ))}

        {isAdmin && (
          <NavLink
            to="/admin"
            className={({ isActive }) => `mobile-menu__link${isActive ? ' active' : ''}`}
            onClick={() => setMenuOpen(false)}
            style={{ color: 'var(--peach-hover)' }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M12 2L2 7l10 5 10-5-10-5z"/>
              <path d="M2 17l10 5 10-5"/>
              <path d="M2 12l10 5 10-5"/>
            </svg>
            Admin panel
          </NavLink>
        )}

        <div style={{ height: 1, background: 'var(--border)', margin: '8px 0' }} />

        {user ? (
          <>
            {/* User info mobilon */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 'var(--sp-3)',
              padding: '12px 20px',
              background: 'var(--gray-50)',
              borderRadius: 'var(--r-md)',
              margin: '0 0 var(--sp-2)',
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: 'var(--r-full)',
                background: 'var(--coral)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'white', fontWeight: 700, fontSize: 'var(--fs-sm)', flexShrink: 0,
              }}>
                {user.name ? user.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase() : user.email[0].toUpperCase()}
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 'var(--fs-sm)', color: 'var(--text)' }}>
                  {user.name || 'Felhasználó'}
                </div>
                <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>{user.email}</div>
              </div>
            </div>

            <Link to="/fiokom" className="mobile-menu__link" onClick={() => setMenuOpen(false)}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
              </svg>
              Profilom
            </Link>

            <Link to="/rendeleiseim" className="mobile-menu__link" onClick={() => setMenuOpen(false)}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>
              </svg>
              Rendeléseim
            </Link>

            <button
              className="mobile-menu__link"
              style={{ width: '100%', textAlign: 'left', color: 'var(--error)' }}
              onClick={handleLogout}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              Kijelentkezés
            </button>
          </>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }}>
            <Link to="/bejelentkezes" className="btn btn-primary btn-full" onClick={() => setMenuOpen(false)}>
              Bejelentkezés
            </Link>
            <Link to="/regisztracio" className="btn btn-outline btn-full" onClick={() => setMenuOpen(false)}>
              Regisztráció
            </Link>
          </div>
        )}
      </div>
    </>
  );
}
