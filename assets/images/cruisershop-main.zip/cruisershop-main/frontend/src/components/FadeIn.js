import React, { useRef, useEffect, useState } from 'react';

export default function FadeIn({
  children,
  direction = 'up',  // 'up' | 'left' | 'right' | 'scale'
  delay = 0,
  style = {},
  className = '',
  threshold = 0.12,
}) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);

  const animClass = {
    up:    'anim-fade-up',
    left:  'anim-fade-left',
    right: 'anim-fade-right',
    scale: 'anim-fade-scale',
  }[direction] || 'anim-fade-up';

  return (
    <div
      ref={ref}
      className={`${className} ${visible ? animClass : ''}`}
      style={{
        opacity: visible ? undefined : 0,
        animationDelay: visible ? `${delay}s` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
}
