import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const COMPARE_KEY = 'cruiser_compare';

export function useCompare() {
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem(COMPARE_KEY)) || []; }
    catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem(COMPARE_KEY, JSON.stringify(items));
  }, [items]);

  const addToCompare = (product) => {
    setItems(prev => {
      if (prev.find(p => p.id === product.id)) return prev;
      if (prev.length >= 4) return prev;
      return [...prev, {
        id: product.id, slug: product.slug, name: product.name,
        price: product.price, image_url: product.image_url,
        spec_motor_w: product.spec_motor_w, spec_max_speed: product.spec_max_speed,
        spec_range_km: product.spec_range_km, spec_battery_ah: product.spec_battery_ah,
      }];
    });
  };

  const removeFromCompare = (id) => setItems(prev => prev.filter(p => p.id !== id));
  const clearCompare = () => setItems([]);
  const isInCompare  = (id) => items.some(p => p.id === id);

  return { items, addToCompare, removeFromCompare, clearCompare, isInCompare };
}

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style:'currency', currency:'HUF', maximumFractionDigits:0 }).format(n);
}

export default function CompareBar({ items, onRemove, onClear }) {
  if (!items || items.length === 0) return null;

  return (
    <div className={`compare-bar${items.length > 0 ? ' visible' : ''}`}>
      {/* Label */}
      <div style={{ color:'rgba(255,255,255,0.5)', fontSize:'var(--fs-xs)', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', flexShrink:0 }}>
        Összehasonlítás ({items.length}/4)
      </div>

      {/* Items */}
      <div style={{ display:'flex', gap:'var(--sp-3)', flex:1, flexWrap:'wrap', alignItems:'center' }}>
        {items.map(item => (
          <div key={item.id} style={{
            display:'flex', alignItems:'center', gap:'var(--sp-2)',
            background:'rgba(255,255,255,0.09)', borderRadius:'var(--r-full)',
            padding:'6px 10px 6px 6px',
          }}>
            {item.image_url && (
              <img src={item.image_url} alt={item.name}
                style={{ width:28, height:28, borderRadius:'50%', objectFit:'cover', flexShrink:0 }}/>
            )}
            <span style={{ fontSize:'var(--fs-xs)', color:'rgba(255,255,255,0.85)', fontWeight:500, maxWidth:120, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
              {item.name}
            </span>
            <button
              onClick={() => onRemove(item.id)}
              style={{ color:'rgba(255,255,255,0.4)', padding:2, transition:'color var(--t-fast)', flexShrink:0 }}
              onMouseEnter={e => e.currentTarget.style.color='rgba(255,255,255,0.9)'}
              onMouseLeave={e => e.currentTarget.style.color='rgba(255,255,255,0.4)'}
              aria-label={`${item.name} eltávolítása`}
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        ))}

        {/* Placeholder slots */}
        {Array.from({ length: 4 - items.length }).map((_, i) => (
          <div key={`empty-${i}`} style={{
            width:28, height:28, borderRadius:'50%',
            border:'1.5px dashed rgba(255,255,255,0.2)',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="2.5">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div style={{ display:'flex', gap:'var(--sp-2)', flexShrink:0 }}>
        {items.length >= 2 && (
          <Link to="/osszehasonlitas" className="btn btn-white btn-sm">
            Összehasonlítás
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </Link>
        )}
        <button
          onClick={onClear}
          className="btn btn-sm"
          style={{ background:'rgba(255,255,255,0.08)', color:'rgba(255,255,255,0.6)', borderRadius:'var(--r-full)' }}
        >
          Törlés
        </button>
      </div>
    </div>
  );
}
