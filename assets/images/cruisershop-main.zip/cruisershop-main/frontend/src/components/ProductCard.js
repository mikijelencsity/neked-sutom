import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import { WishlistContext } from '../context/WishListContext';

function formatPrice(price) {
  return new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(price);
}

const CATEGORY_LABELS = {
  elektromos: 'Elektromos kerékpár', tura: 'Túrakerékpár',
  varosi: 'Városi kerékpár', gyermek: 'Gyermekkerékpár',
};

const ImgPlaceholder = () => (
  <div style={{
    width: '100%', height: '100%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg, var(--coral-light) 0%, var(--peach-light) 100%)',
  }}>
    <svg width="56" height="56" viewBox="0 0 64 64" fill="none" opacity="0.25">
      <circle cx="16" cy="44" r="12" stroke="var(--coral)" strokeWidth="3"/>
      <circle cx="48" cy="44" r="12" stroke="var(--coral)" strokeWidth="3"/>
      <path d="M16 44 L28 20 L36 28 L42 20 L48 44" stroke="var(--coral)" strokeWidth="3" fill="none" strokeLinejoin="round"/>
    </svg>
  </div>
);

export default function ProductCard({ product, onCompare, compareList = [] }) {
  const { addToCart }            = useContext(CartContext);
  const { toggle, isWishlisted } = useContext(WishlistContext);
  const [added, setAdded]        = useState(false);
  const [imgError, setImgError]  = useState(false);

  const inCompare  = compareList.some(p => p.id === product.id);
  const wishlisted = isWishlisted(product.id);
  const showImg    = product.image_url && !imgError;

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
  };

  const handleWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggle(product);
  };

  const handleCompare = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (onCompare) onCompare(product);
  };

  const isOutOfStock = product.stock === 0;
  const catLabel     = CATEGORY_LABELS[product.category] || product.category;

  return (
    <Link to={`/kerekparok/${product.slug}`} className="product-card" style={{ display: 'block' }}>
      <div className="product-card__img-wrap">
        {showImg ? (
          <img
            className="product-card__img"
            src={product.image_url}
            alt={product.name}
            loading="lazy"
            onError={() => setImgError(true)}
          />
        ) : (
          <ImgPlaceholder />
        )}

        <div className="product-card__badges">
          {isOutOfStock && <span className="badge badge-error">Elfogyott</span>}
          {!isOutOfStock && product.stock <= 3 && product.stock > 0 && (
            <span className="badge badge-peach">Utolsó {product.stock} db</span>
          )}
        </div>

        <div className="product-card__actions">
          <button
            className={`product-card__action-btn${wishlisted ? ' active' : ''}`}
            onClick={handleWishlist}
            aria-label={wishlisted ? 'Eltávolítás a kívánságlistáról' : 'Kívánságlistához'}
            title={wishlisted ? 'Eltávolítás' : 'Kívánságlistához'}
          >
            <svg width="16" height="16" viewBox="0 0 24 24"
              fill={wishlisted ? 'currentColor' : 'none'}
              stroke="currentColor" strokeWidth="2">
              <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
            </svg>
          </button>
          {onCompare && (
            <button
              className={`product-card__action-btn${inCompare ? ' active' : ''}`}
              onClick={handleCompare}
              aria-label="Összehasonlításhoz"
              title="Összehasonlítás"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/>
                <polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/>
              </svg>
            </button>
          )}
        </div>
      </div>

      <div className="product-card__body">
        {catLabel && <p className="product-card__cat">{catLabel}</p>}
        <h3 className="product-card__name">{product.name}</h3>

        <div className="product-card__price-row">
          <div>
            <div className="product-card__price">{formatPrice(product.price)}</div>
          </div>
          {!isOutOfStock && (
            <button
              className={`product-card__add${added ? ' added' : ''}`}
              onClick={handleAddToCart}
              aria-label="Kosárba"
              title="Kosárba"
            >
              {added ? (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                  <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
              )}
            </button>
          )}
        </div>
      </div>
    </Link>
  );
}