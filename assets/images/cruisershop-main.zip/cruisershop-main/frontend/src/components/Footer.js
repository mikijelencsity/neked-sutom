import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer__grid">
          {/* Brand */}
          <div>
            <div className="footer__logo">
              <img src="/logo.png" alt="The Cruiser Shop" />
            </div>
            <p className="footer__desc">
              Prémium kerékpárok és elektromos bringák széles választéka. 
              Személyes beüzemelés, garancia és szakértő tanácsadás.
            </p>
            <div className="footer__social" style={{ marginTop: 20 }}>
              <a href="https://facebook.com" target="_blank" rel="noreferrer" className="footer__social-btn" aria-label="Facebook">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/>
                </svg>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="footer__social-btn" aria-label="Instagram">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                  <circle cx="12" cy="12" r="4"/>
                  <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                </svg>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer" className="footer__social-btn" aria-label="YouTube">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.97C18.88 4 12 4 12 4s-6.88 0-8.59.45A2.78 2.78 0 001.46 6.42 29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.45a2.78 2.78 0 001.95-1.95A29 29 0 0023 12a29 29 0 00-.46-5.58z"/>
                  <polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="currentColor" stroke="none"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Shop */}
          <div>
            <p className="footer__head">Webshop</p>
            <nav className="footer__links">
              <Link to="/kerekparok" className="footer__link">Összes kerékpár</Link>
              <Link to="/kerekparok?category=elektromos" className="footer__link">Elektromos kerékpár</Link>
              <Link to="/kerekparok?category=tura" className="footer__link">Túrakerékpár</Link>
              <Link to="/kerekparok?category=varosi" className="footer__link">Városi kerékpár</Link>
              <Link to="/kerekparok?category=gyermek" className="footer__link">Gyermekkerékpár</Link>
            </nav>
          </div>

          {/* Account */}
          <div>
            <p className="footer__head">Fiók</p>
            <nav className="footer__links">
              <Link to="/bejelentkezes" className="footer__link">Bejelentkezés</Link>
              <Link to="/regisztracio" className="footer__link">Regisztráció</Link>
              <Link to="/rendeleiseim" className="footer__link">Rendeléseim</Link>
              <Link to="/kosar" className="footer__link">Kosár</Link>
            </nav>
          </div>

          {/* Info */}
          <div>
            <p className="footer__head">Információ</p>
            <nav className="footer__links">
              <a href="mailto:info@cruisershop.hu" className="footer__link">info@cruisershop.hu</a>
              <a href="tel:+36301234567" className="footer__link">+36 30 123 4567</a>
              <span className="footer__link" style={{ cursor: 'default' }}>H–P: 9:00 – 18:00</span>
              <span className="footer__link" style={{ cursor: 'default' }}>Szombat: 10:00 – 14:00</span>
            </nav>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="footer__bottom">
          <span>© {year} The Cruiser Shop. Minden jog fenntartva.</span>
          <div style={{ display: 'flex', gap: 24 }}>
            <Link to="/adatvedelem" className="footer__link">Adatvédelmi tájékoztató</Link>
            <Link to="/aszf" className="footer__link">ÁSZF</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}