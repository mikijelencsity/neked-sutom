import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { AuthContext } from './AuthContext';
import api from '../utils/api';

export const WishlistContext = createContext();

export function WishlistProvider({ children }) {
  const { user } = useContext(AuthContext);
  const [wishlistIds, setWishlistIds] = useState(new Set());
  const [loaded, setLoaded] = useState(false);

  // Betöltés: bejelentkezett usernél API, vendégnél localStorage
  const loadWishlist = useCallback(async () => {
    if (!user) {
      try {
        const stored = localStorage.getItem('wishlist_ids');
        setWishlistIds(new Set(stored ? JSON.parse(stored) : []));
      } catch {
        setWishlistIds(new Set());
      }
      setLoaded(true);
      return;
    }
    try {
      const r = await api('/api/wishlist/ids');
      if (r.ok) {
        const ids = await r.json();
        setWishlistIds(new Set(ids));
      }
    } catch {
      setWishlistIds(new Set());
    }
    setLoaded(true);
  }, [user]);

  useEffect(() => {
    setLoaded(false);
    loadWishlist();
  }, [loadWishlist]);

  const toggle = async (product) => {
    const pid = product.id || product.product_id;
    const isIn = wishlistIds.has(pid);

    // Optimisztikus UI frissítés
    setWishlistIds(prev => {
      const next = new Set(prev);
      isIn ? next.delete(pid) : next.add(pid);
      return next;
    });

    if (!user) {
      // Csak localStorage
      setWishlistIds(prev => {
        localStorage.setItem('wishlist_ids', JSON.stringify([...prev]));
        return prev;
      });
      return;
    }

    try {
      if (isIn) {
        await api(`/api/wishlist/${pid}`, { method: 'DELETE' });
      } else {
        await api('/api/wishlist', {
          method: 'POST',
          body: JSON.stringify({ product_id: pid }),
        });
      }
    } catch {
      // Visszaállítás hiba esetén
      setWishlistIds(prev => {
        const next = new Set(prev);
        isIn ? next.add(pid) : next.delete(pid);
        return next;
      });
    }
  };

  const isWishlisted = (productId) => wishlistIds.has(productId);

  return (
    <WishlistContext.Provider value={{ wishlistIds, toggle, isWishlisted, loaded, reload: loadWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
}