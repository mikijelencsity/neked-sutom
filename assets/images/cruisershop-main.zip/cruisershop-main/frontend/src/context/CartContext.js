import React, { createContext, useState, useEffect, useCallback } from 'react';

export const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('cruiser_cart') || '[]');
    } catch {
      return [];
    }
  });

  /* localStorage szinkron */
  useEffect(() => {
    localStorage.setItem('cruiser_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const cartCount = cartItems.reduce((s, i) => s + i.quantity, 0);
  const cartTotal = cartItems.reduce((s, i) => s + i.price * i.quantity, 0);

  const addToCart = useCallback((product, quantity = 1) => {
    setCartItems(prev => {
      const exists = prev.find(i => i.id === product.id);
      if (exists) {
        return prev.map(i =>
          i.id === product.id
            ? { ...i, quantity: Math.min(i.quantity + quantity, product.stock || 99) }
            : i
        );
      }
      return [...prev, {
        id:        product.id,
        slug:      product.slug,
        name:      product.name,
        price:     product.price,
        image_url: product.image_url,
        stock:     product.stock,
        quantity,
      }];
    });
  }, []);

  const updateQuantity = useCallback((id, quantity) => {
    if (quantity < 1) return removeFromCart(id);
    setCartItems(prev =>
      prev.map(i => i.id === id ? { ...i, quantity } : i)
    );
  }, []);

  const removeFromCart = useCallback((id) => {
    setCartItems(prev => prev.filter(i => i.id !== id));
  }, []);

  const clearCart = useCallback(() => setCartItems([]), []);

  return (
    <CartContext.Provider value={{
      cartItems, cartCount, cartTotal,
      addToCart, updateQuantity, removeFromCart, clearCart,
    }}>
      {children}
    </CartContext.Provider>
  );
}
