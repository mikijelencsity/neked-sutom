import React, { createContext, useState, useEffect, useCallback } from 'react';
import api, { setAccessToken, clearAccessToken } from '../utils/api';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // Azonnal localStorage-ból töltjük be — nem lesz villogás
  const [user, setUser] = useState(() => {
    try {
      const s = localStorage.getItem('cruiser_user');
      return s ? JSON.parse(s) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // api.js már kezeli a 401→refresh logikát automatikusan
    // Ha refresh is meghal, akkor 401 jön vissza → töröljük a user-t
    api('/api/auth/me')
      .then(r => {
        if (r.ok) return r.json();
        if (r.status === 401) {
          // api.js már megpróbálta a refresh-t, nem sikerült → logout
          setUser(null);
          localStorage.removeItem('cruiser_user');
          clearAccessToken();
        }
        // Egyéb hiba (500, network) → ne bántsuk a localStorage-t
        return null;
      })
      .then(data => {
        if (data) {
          // /me visszaadja: uuid, email, name, phone, role, is_verified, created_at
          const userData = {
            id: data.uuid,
            email: data.email,
            name: data.name,
            role: data.role,
          };
          setUser(userData);
          localStorage.setItem('cruiser_user', JSON.stringify(userData));
        }
      })
      .catch(() => {
        // Hálózati hiba → megtartjuk ami van localStorage-ban
      })
      .finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (email, password) => {
    const r = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.message || 'Sikertelen bejelentkezés');
    
    // Access token mentése
    if (data.accessToken) {
      setAccessToken(data.accessToken);
    }
    
    setUser(data.user);
    localStorage.setItem('cruiser_user', JSON.stringify(data.user));
    return data.user;
  }, []);

  const register = useCallback(async (payload) => {
    const r = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.message || 'Sikertelen regisztráció');
    return data;
  }, []);

  const logout = useCallback(async () => {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch (_) {}
    setUser(null);
    localStorage.removeItem('cruiser_user');
    clearAccessToken();
  }, []);

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}