export { ResetPasswordPage as default } from './AllPages';
