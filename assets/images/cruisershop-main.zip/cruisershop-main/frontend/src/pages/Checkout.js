import React, { useState, useContext, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import { AuthContext } from '../context/AuthContext';
import api from '../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style:'currency', currency:'HUF', maximumFractionDigits:0 }).format(n);
}

const Field = React.memo(function Field({ label, name, type = 'text', placeholder = '', half = false, value, onChange, error }) {
  return (
    <div className="form-group" style={{ gridColumn: half ? 'span 1' : 'span 2' }}>
      <label className="form-label">{label}</label>
      <input
        className={`form-input${error ? ' error' : ''}`}
        type={type}
        value={value}
        onChange={e => onChange(name, e.target.value)}
        placeholder={placeholder}
        autoComplete={name}
      />
      {error && <p className="form-error">{error}</p>}
    </div>
  );
});

export default function Checkout() {
  const { cartItems, cartTotal, clearCart } = useContext(CartContext);
  const { user }  = useContext(AuthContext);
  const navigate  = useNavigate();

  const [form, setForm] = useState({
    full_name: user?.name  || '',
    email:     user?.email || '',
    phone:     '',
    street:    '',
    city:      '',
    zip:       '',
    country:   'Magyarország',
    note:      '',
  });
  const [errors,    setErrors]    = useState({});
  const [loading,   setLoading]   = useState(false);
  const [serverErr, setServerErr] = useState('');
  const [step,      setStep]      = useState(1);

  const handleChange = useCallback((k, v) => {
    setForm(f => ({ ...f, [k]: v }));
    setErrors(e => ({ ...e, [k]: '' }));
  }, []);

  if (cartItems.length === 0) return (
    <main className="page" style={{ display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ textAlign:'center' }}>
        <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-2xl)', fontWeight:700, marginBottom:'var(--sp-4)' }}>
          A kosár üres
        </h2>
        <Link to="/kerekparok" className="btn btn-primary">Termékek böngészése</Link>
      </div>
    </main>
  );

  const validate = () => {
    const e = {};
    if (!form.full_name.trim()) e.full_name = 'Kötelező mező';
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Érvényes e-mail szükséges';
    if (!form.street.trim()) e.street = 'Kötelező mező';
    if (!form.city.trim())   e.city   = 'Kötelező mező';
    if (!form.zip.trim())    e.zip    = 'Kötelező mező';
    return e;
  };

  const handleContinue = () => {
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async () => {
    setLoading(true);
    setServerErr('');
    try {
      // FIX: Backend shipping objektumot vár, nem flat mezőket
      const r = await api('/api/orders/checkout', {
        method: 'POST',
        body: JSON.stringify({
          shipping: {
            name:    form.full_name,
            street:  form.street,
            city:    form.city,
            zip:     form.zip,
            country: form.country,
            phone:   form.phone || null,
          },
          guest_email: user ? null : form.email,
          note: form.note || null,
          items: cartItems.map(i => ({ product_id: i.id, quantity: i.quantity })),
        }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || data.error || 'Hiba történt a rendelés leadásakor');
      if (data.url) {
        clearCart();
        window.location.href = data.url;
      } else {
        throw new Error('Nem kaptunk fizetési linket a szervertől');
      }
    } catch (err) {
      setServerErr(err.message);
      setStep(2);
    } finally {
      setLoading(false);
    }
  };

  const shipping = cartTotal >= 80000 ? 0 : 4990;
  const total    = cartTotal + shipping;

  return (
    <main className="page">
      <div style={{ background:'var(--white)', borderBottom:'1px solid var(--border)', padding:'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          <div className="breadcrumb" style={{ marginBottom:'var(--sp-3)' }}>
            <Link to="/">Kezdőlap</Link>
            <span className="breadcrumb__sep">›</span>
            <Link to="/kosar">Kosár</Link>
            <span className="breadcrumb__sep">›</span>
            <span style={{ color:'var(--text)', fontWeight:500 }}>Megrendelés</span>
          </div>
          <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,4vw,2.2rem)', fontWeight:700, letterSpacing:'-0.02em' }}>
            Megrendelés
          </h1>

          {/* Progress */}
          <div style={{ display:'flex', gap:'var(--sp-2)', marginTop:'var(--sp-4)', alignItems:'center' }}>
            {[{n:1,l:'Szállítási adatok'},{n:2,l:'Áttekintés és fizetés'}].map((s,i) => (
              <React.Fragment key={s.n}>
                <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-2)' }}>
                  <div style={{
                    width:28, height:28, borderRadius:'var(--r-full)',
                    background: step >= s.n ? 'var(--coral)' : 'var(--gray-100)',
                    color: step >= s.n ? 'white' : 'var(--text-muted)',
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:'var(--fs-xs)', fontWeight:700,
                    transition:'all var(--t-base)',
                  }}>
                    {step > s.n ? (
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    ) : s.n}
                  </div>
                  <span style={{ fontSize:'var(--fs-sm)', fontWeight: step === s.n ? 600 : 400, color: step === s.n ? 'var(--text)' : 'var(--text-muted)' }}>
                    {s.l}
                  </span>
                </div>
                {i < 1 && <div style={{ flex:1, height:1, background:'var(--border)', maxWidth:80 }}/>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      <div className="container" style={{ padding:'var(--sp-8) var(--container-pad) var(--sp-16)' }}>
        <div className="cart-layout">
          {/* Form / Review */}
          <div>
            {step === 1 ? (
              <div style={{ background:'var(--white)', borderRadius:'var(--r-xl)', border:'1px solid var(--border)', padding:'var(--sp-7)' }}>
                <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-xl)', fontWeight:700, marginBottom:'var(--sp-6)' }}>
                  Szállítási adatok
                </h2>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--sp-4)' }}>
                  <Field label="Teljes név"    name="full_name" placeholder="Kovács Péter"        value={form.full_name} onChange={handleChange} error={errors.full_name} />
                  <Field label="E-mail cím"    name="email"     type="email" placeholder="pelda@email.hu" value={form.email} onChange={handleChange} error={errors.email} />
                  <Field label="Telefon"       name="phone"     type="tel"   placeholder="+36 30 123 4567" value={form.phone} onChange={handleChange} error={errors.phone} />
                  <div />
                  <Field label="Utca, házszám" name="street"    placeholder="Kossuth u. 12."       value={form.street} onChange={handleChange} error={errors.street} />
                  <Field label="Város"         name="city"      placeholder="Budapest"  half       value={form.city}   onChange={handleChange} error={errors.city} />
                  <Field label="Irányítószám"  name="zip"       placeholder="1051"      half       value={form.zip}    onChange={handleChange} error={errors.zip} />
                  <div className="form-group" style={{ gridColumn:'span 2' }}>
                    <label className="form-label">Megjegyzés (opcionális)</label>
                    <textarea
                      className="form-input form-textarea"
                      value={form.note}
                      onChange={e => handleChange('note', e.target.value)}
                      placeholder="Pl. csengő neve, kapukód..."
                    />
                  </div>
                </div>
                <button className="btn btn-primary btn-lg" style={{ marginTop:'var(--sp-6)' }} onClick={handleContinue}>
                  Folytatás
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </button>
              </div>
            ) : (
              <div style={{ background:'var(--white)', borderRadius:'var(--r-xl)', border:'1px solid var(--border)', padding:'var(--sp-7)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'var(--sp-5)' }}>
                  <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-xl)', fontWeight:700 }}>Szállítási adatok</h2>
                  <button className="btn btn-ghost btn-sm" onClick={() => setStep(1)}>Módosítás</button>
                </div>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--sp-3)', fontSize:'var(--fs-sm)', color:'var(--text-muted)' }}>
                  {[
                    ['Név',    form.full_name],
                    ['E-mail', form.email],
                    ['Telefon',form.phone || '–'],
                    ['Cím',    `${form.zip} ${form.city}, ${form.street}`],
                  ].map(([k,v]) => (
                    <div key={k}>
                      <span style={{ fontWeight:600, color:'var(--text-2)' }}>{k}: </span>
                      <span>{v}</span>
                    </div>
                  ))}
                </div>

                <div style={{ marginTop:'var(--sp-6)', paddingTop:'var(--sp-5)', borderTop:'1px solid var(--border)' }}>
                  <h3 style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-lg)', fontWeight:700, marginBottom:'var(--sp-4)' }}>Rendelt termékek</h3>
                  {cartItems.map(item => (
                    <div key={item.id} style={{ display:'flex', gap:'var(--sp-3)', alignItems:'center', padding:'var(--sp-3) 0', borderBottom:'1px solid var(--border)' }}>
                      <img src={item.image_url || 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=100'} alt={item.name}
                        style={{ width:60, height:48, borderRadius:'var(--r-sm)', objectFit:'cover', background:'var(--bg)' }} />
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontWeight:600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{item.name}</div>
                        <div style={{ fontSize:'var(--fs-sm)', color:'var(--text-muted)' }}>{item.quantity} × {formatPrice(item.price)}</div>
                      </div>
                      <div style={{ fontFamily:'var(--font-display)', fontWeight:700, color:'var(--coral)' }}>
                        {formatPrice(item.price * item.quantity)}
                      </div>
                    </div>
                  ))}
                </div>

                {serverErr && (
                  <div style={{ background:'var(--error-bg)', borderRadius:'var(--r-md)', padding:'var(--sp-4)', marginTop:'var(--sp-5)', color:'var(--error)', fontSize:'var(--fs-sm)', fontWeight:500 }}>
                    ⚠️ {serverErr}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="summary-card">
            <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-xl)', fontWeight:700, marginBottom:'var(--sp-5)' }}>Összesítő</h2>
            <div className="summary-row">
              <span style={{ color:'var(--text-muted)', fontSize:'var(--fs-sm)' }}>Részösszeg</span>
              <span style={{ fontWeight:600 }}>{formatPrice(cartTotal)}</span>
            </div>
            <div className="summary-row">
              <span style={{ color:'var(--text-muted)', fontSize:'var(--fs-sm)' }}>Szállítás</span>
              {shipping === 0 ? <span className="badge badge-success">Ingyenes</span> : <span style={{ fontWeight:600 }}>{formatPrice(shipping)}</span>}
            </div>
            <div className="summary-row">
              <span style={{ fontWeight:700, fontSize:'var(--fs-md)' }}>Összesen</span>
              <span className="summary-total">{formatPrice(total)}</span>
            </div>

            {step === 2 && (
              <button
                className="btn btn-primary btn-full btn-lg"
                style={{ marginTop:'var(--sp-5)' }}
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? (
                  <span className="spinner" style={{ width:20, height:20, borderWidth:2, borderColor:'rgba(255,255,255,0.3)', borderTopColor:'#fff' }}/>
                ) : (
                  <>
                    Fizetés (Stripe)
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                  </>
                )}
              </button>
            )}

            <div style={{ marginTop:'var(--sp-5)', paddingTop:'var(--sp-5)', borderTop:'1px solid var(--border)' }}>
              {[['🔒','Biztonságos Stripe fizetés'],['🚚','Szállítás 1–3 munkanapon belül'],['🔧','Személyes beüzemelés']].map(([ic,tx],i) => (
                <div key={i} style={{ display:'flex', gap:'var(--sp-2)', padding:'var(--sp-1) 0', fontSize:'var(--fs-xs)', color:'var(--text-muted)' }}>
                  <span>{ic}</span><span>{tx}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}