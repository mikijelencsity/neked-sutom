import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import { useCompare } from '../components/CompareBar';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style:'currency', currency:'HUF', maximumFractionDigits:0 }).format(n);
}

const SPECS = [
  { key: 'price',               label: 'Ár',            fmt: (v) => v ? formatPrice(v) : '—', lowerBetter: true },
  { key: 'spec_motor_w',        label: 'Motor',          fmt: (v) => v ? `${v} W` : '—' },
  { key: 'spec_battery_ah',     label: 'Akkumulátor',    fmt: (v) => v ? `${v} Ah` : '—' },
  { key: 'spec_max_speed',      label: 'Max sebesség',   fmt: (v) => v ? `${v} km/h` : '—' },
  { key: 'spec_range_km',       label: 'Hatótávolság',   fmt: (v) => v ? `~${v} km` : '—' },
  { key: 'spec_weight_kg',      label: 'Önsúly',         fmt: (v) => v ? `${v} kg` : '—', lowerBetter: true },
  { key: 'spec_max_load_kg',    label: 'Max terhelés',   fmt: (v) => v ? `${v} kg` : '—' },
  { key: 'spec_charge_hours',   label: 'Töltési idő',    fmt: (v) => v ? `${v} óra` : '—', lowerBetter: true },
  { key: 'spec_wheel_size',     label: 'Kerékméret',     fmt: (v) => v || '—' },
  { key: 'spec_brake_front',    label: 'Első fék',       fmt: (v) => v || '—' },
  { key: 'spec_brake_rear',     label: 'Hátsó fék',      fmt: (v) => v || '—' },
  { key: 'spec_gears',          label: 'Váltó',          fmt: (v) => v || '—' },
  { key: 'spec_pedal',          label: 'Pedálos',        fmt: (v) => v != null ? (v ? 'Igen' : 'Nem') : '—' },
  { key: 'spec_throttle',       label: 'Gázkar',         fmt: (v) => v != null ? (v ? 'Van' : 'Nincs') : '—' },
  { key: 'spec_license_required',label:'Jogosítvány',    fmt: (v) => v ? 'Szükséges' : 'Nem szükséges' },
];

export default function Compare() {
  const { items: compareItems, removeFromCompare, clearCompare } = useCompare();
  const { addToCart } = useContext(CartContext);
  const navigate      = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(false);

  useEffect(() => {
    if (compareItems.length === 0) { setProducts([]); return; }
    setLoading(true);
    Promise.all(
      compareItems.map(item => api(`/api/products/${item.slug || item.id}`).then(r => r.ok ? r.json() : null))
    )
      .then(res => setProducts(res.filter(Boolean)))
      .finally(() => setLoading(false));
  }, [compareItems.length]);

  const getBest = (key, lowerBetter) => {
    const nums = products.map(p => p[key]).filter(v => typeof v === 'number');
    if (!nums.length) return null;
    return lowerBetter ? Math.min(...nums) : Math.max(...nums);
  };

  return (
    <main className="page">
      <div style={{ background:'var(--white)', borderBottom:'1px solid var(--border)', padding:'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          <div className="breadcrumb" style={{ marginBottom:'var(--sp-3)' }}>
            <Link to="/">Kezdőlap</Link>
            <span className="breadcrumb__sep">›</span>
            <span style={{ color:'var(--text)', fontWeight:500 }}>Összehasonlítás</span>
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,4vw,2.2rem)', fontWeight:700, letterSpacing:'-0.02em' }}>
              Összehasonlítás
            </h1>
            {compareItems.length > 0 && (
              <button className="btn btn-ghost btn-sm" onClick={clearCompare}>Törlés</button>
            )}
          </div>
        </div>
      </div>

      <div className="container" style={{ padding:'var(--sp-8) var(--container-pad) var(--sp-16)' }}>
        {compareItems.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state__icon">⚖️</div>
            <h2 className="empty-state__title">Nincs összehasonlítandó termék</h2>
            <p style={{ marginBottom:'var(--sp-6)' }}>
              A termékek kártyáján kattints az összehasonlítás ikonra hogy ide kerüljenek.
            </p>
            <Link to="/kerekparok" className="btn btn-primary">Kerékpárok böngészése</Link>
          </div>
        ) : compareItems.length < 2 ? (
          <div style={{ textAlign:'center', padding:'var(--sp-16)' }}>
            <p style={{ fontSize:'var(--fs-md)', color:'var(--text-muted)', marginBottom:'var(--sp-5)' }}>
              Adj hozzá legalább egy másik terméket az összehasonlításhoz.
            </p>
            <Link to="/kerekparok" className="btn btn-outline">Termékek böngészése</Link>
          </div>
        ) : loading ? (
          <div style={{ display:'flex', justifyContent:'center', padding:'var(--sp-16)' }}>
            <span className="spinner" style={{ width:40, height:40, borderWidth:3 }}/>
          </div>
        ) : (
          <FadeIn>
            <div style={{ overflowX:'auto', borderRadius:'var(--r-xl)', border:'1px solid var(--border)' }}>
              <table style={{ width:'100%', borderCollapse:'collapse', minWidth: products.length * 200 + 180 }}>
                {/* Product headers */}
                <thead>
                  <tr style={{ background:'var(--white)' }}>
                    <th style={{ width:170, padding:'var(--sp-5)', textAlign:'left', borderBottom:'1px solid var(--border)', borderRight:'1px solid var(--border)' }}>
                      <span style={{ fontSize:'var(--fs-xs)', fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em' }}>
                        Jellemző
                      </span>
                    </th>
                    {products.map(p => (
                      <th key={p.id} style={{ padding:'var(--sp-5)', textAlign:'center', borderBottom:'1px solid var(--border)', borderRight:'1px solid var(--border)' }}>
                        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:'var(--sp-3)' }}>
                          <img src={p.image_url || 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=200'} alt={p.name}
                            style={{ width:80, height:64, borderRadius:'var(--r-md)', objectFit:'cover' }}/>
                          <Link to={`/kerekparok/${p.slug}`} style={{ fontFamily:'var(--font-display)', fontWeight:600, fontSize:'var(--fs-sm)', color:'var(--text)', textAlign:'center', lineHeight:1.3, ':hover':{color:'var(--coral)'} }}>
                            {p.name}
                          </Link>
                          <div style={{ display:'flex', flexDirection:'column', gap:6, width:'100%' }}>
                            <button
                              className="btn btn-primary btn-sm btn-full"
                              onClick={() => { addToCart(p); }}
                            >
                              Kosárba
                            </button>
                            <button
                              className="btn btn-ghost btn-sm btn-full"
                              style={{ fontSize:'var(--fs-xs)', color:'var(--error)' }}
                              onClick={() => removeFromCompare(p.id)}
                            >
                              Eltávolítás
                            </button>
                          </div>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {SPECS.map((spec, ri) => {
                    const best = getBest(spec.key, spec.lowerBetter);
                    return (
                      <tr key={spec.key} style={{ background: ri % 2 === 0 ? 'var(--white)' : 'var(--bg)' }}>
                        <td style={{ padding:'var(--sp-4) var(--sp-5)', borderBottom:'1px solid var(--border)', borderRight:'1px solid var(--border)', fontWeight:600, fontSize:'var(--fs-sm)', color:'var(--text-2)' }}>
                          {spec.label}
                        </td>
                        {products.map(p => {
                          const val = p[spec.key];
                          const isBest = typeof val === 'number' && val === best;
                          return (
                            <td key={p.id} style={{
                              padding:'var(--sp-4) var(--sp-5)',
                              textAlign:'center',
                              borderBottom:'1px solid var(--border)',
                              borderRight:'1px solid var(--border)',
                              fontSize:'var(--fs-sm)',
                              color: isBest ? 'var(--success)' : (spec.key === 'price' ? 'var(--coral)' : 'var(--text)'),
                              fontWeight: spec.key === 'price' ? 700 : (isBest ? 600 : 400),
                              background: isBest ? 'var(--success-bg)' : 'transparent',
                              fontFamily: spec.key === 'price' ? 'var(--font-display)' : 'inherit',
                            }}>
                              {spec.fmt(val, p)}
                              {isBest && typeof val === 'number' && (
                                <svg style={{ marginLeft:4, verticalAlign:'middle' }} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2.5">
                                  <polyline points="20 6 9 17 4 12"/>
                                </svg>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </FadeIn>
        )}
      </div>
    </main>
  );
}
