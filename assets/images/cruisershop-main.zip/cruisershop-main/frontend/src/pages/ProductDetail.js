import React, { useState, useEffect, useContext } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style:'currency', currency:'HUF', maximumFractionDigits:0 }).format(n);
}

const CAT_LABELS = {
  varosi:'Városi', fatbike:'Fatbike', kisrobogo:'Kisrobogó', ztech:'Z-Tech e-bike', alkatresz:'Alkatrész',
};

export default function ProductDetail() {
  const { slug }      = useParams();
  const navigate      = useNavigate();
  const { addToCart } = useContext(CartContext);

  const [product, setProduct]   = useState(null);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [qty, setQty]           = useState(1);
  const [activeImg, setActiveImg] = useState(0);
  const [adding, setAdding]     = useState(false);
  const [added, setAdded]       = useState(false);
  const [wishlisted, setWishlisted] = useState(false);

  useEffect(() => {
    setLoading(true);
    api(`/api/products/${slug}`)
      .then(r => { if (!r.ok) throw new Error('Nem található'); return r.json(); })
      .then(d => { setProduct(d); setLoading(false); })
      .catch(e => { setError(e.message); setLoading(false); });
  }, [slug]);

  const handleAddToCart = () => {
    if (!product || adding) return;
    setAdding(true);
    addToCart(product, qty);
    setAdded(true);
    setTimeout(() => { setAdding(false); setAdded(false); }, 2000);
  };

  const images = product
    ? [product.image_url, product.image2_url, product.image3_url, product.image4_url].filter(Boolean)
    : [];

  if (loading) return (
    <main className="page">
      <div className="container" style={{ paddingTop: 60 }}>
        <div className="pd-layout">
          <div>
            <div className="skeleton pd-main-img" />
            <div className="pd-thumb-grid" style={{ marginTop: 12 }}>
              {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ aspectRatio:'1', borderRadius:'var(--r-md)' }}/>)}
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="skeleton" style={{ height:14, width:'30%' }}/>
            <div className="skeleton" style={{ height:40, width:'80%' }}/>
            <div className="skeleton" style={{ height:32, width:'40%' }}/>
            <div className="skeleton" style={{ height:80 }}/>
          </div>
        </div>
      </div>
    </main>
  );

  if (error || !product) return (
    <main className="page">
      <div className="container" style={{ paddingTop: 80 }}>
        <div className="empty-state">
          <div className="empty-state__icon">😕</div>
          <h2 className="empty-state__title">A termék nem található</h2>
          <p style={{ marginBottom:'var(--sp-6)' }}>Ez a kerékpár már nem elérhető.</p>
          <button className="btn btn-primary" onClick={() => navigate('/kerekparok')}>Vissza a kínálathoz</button>
        </div>
      </div>
    </main>
  );

  const isOutOfStock = product.stock === 0;

  return (
    <main className="page">
      {/* Breadcrumb bar */}
      <div style={{ background:'var(--white)', borderBottom:'1px solid var(--border)', padding:'var(--sp-4) 0' }}>
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Kezdőlap</Link>
            <span className="breadcrumb__sep">›</span>
            <Link to="/kerekparok">Kerékpárok</Link>
            {product.category && (
              <>
                <span className="breadcrumb__sep">›</span>
                <Link to={`/kerekparok?category=${product.category}`}>{CAT_LABELS[product.category] || product.category}</Link>
              </>
            )}
            <span className="breadcrumb__sep">›</span>
            <span style={{ color:'var(--text)', fontWeight:500, maxWidth:200, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{product.name}</span>
          </div>
        </div>
      </div>

      <div className="container" style={{ padding:'var(--sp-10) var(--container-pad) var(--sp-16)' }}>
        <div className="pd-layout">
          {/* Left: images */}
          <FadeIn direction="left">
            <div>
              {/* Main image */}
              <div className="pd-main-img" style={{ boxShadow:'var(--shadow-md)' }}>
                {images.length > 0 ? (
                  <img src={images[activeImg]} alt={product.name} />
                ) : (
                  <div style={{ width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center', background:'linear-gradient(135deg,var(--coral-light),var(--peach-light))' }}>
                    <svg width="80" height="80" viewBox="0 0 64 64" fill="none" opacity="0.3">
                      <circle cx="16" cy="44" r="12" stroke="var(--coral)" strokeWidth="3"/>
                      <circle cx="48" cy="44" r="12" stroke="var(--coral)" strokeWidth="3"/>
                      <path d="M16 44L28 20L36 28L42 20L48 44" stroke="var(--coral)" strokeWidth="3" fill="none" strokeLinejoin="round"/>
                    </svg>
                  </div>
                )}
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="pd-thumb-grid">
                  {images.map((img, i) => (
                    <div
                      key={i}
                      className={`pd-thumb${activeImg === i ? ' active' : ''}`}
                      onClick={() => setActiveImg(i)}
                    >
                      <img src={img} alt={`${product.name} ${i+1}`} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </FadeIn>

          {/* Right: info */}
          <FadeIn direction="right">
            <div style={{ display:'flex', flexDirection:'column', gap:'var(--sp-5)' }}>
              {/* Category + Stock */}
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                {product.category && (
                  <Link to={`/kerekparok?category=${product.category}`}>
                    <span className="badge badge-peach">{CAT_LABELS[product.category] || product.category}</span>
                  </Link>
                )}
                {isOutOfStock ? (
                  <span className="badge badge-error">Elfogyott</span>
                ) : product.stock <= 3 ? (
                  <span className="badge badge-peach">Utolsó {product.stock} db</span>
                ) : (
                  <span className="badge badge-success">Raktáron</span>
                )}
              </div>

              {/* Name */}
              <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,3vw,2.2rem)', fontWeight:700, color:'var(--text)', lineHeight:1.15, letterSpacing:'-0.02em' }}>
                {product.name}
              </h1>

              {/* Price */}
              <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-3)' }}>
                <span style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-3xl)', fontWeight:700, color:'var(--coral)' }}>
                  {formatPrice(product.price)}
                </span>
              </div>

              {/* Description */}
              {product.description && (
                <p style={{ fontSize:'var(--fs-md)', color:'var(--text-muted)', lineHeight:1.75 }}>
                  {product.description}
                </p>
              )}

              {/* Divider */}
              <div className="divider" style={{ margin:'var(--sp-2) 0' }}/>

              {/* Quantity + Add to cart */}
              {!isOutOfStock && (
                <div style={{ display:'flex', gap:'var(--sp-3)', alignItems:'center' }}>
                  {/* Qty */}
                  <div className="qty-control">
                    <button className="qty-btn" onClick={() => setQty(q => Math.max(1, q-1))} aria-label="Csökkentés">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="5" y1="12" x2="19" y2="12"/>
                      </svg>
                    </button>
                    <span className="qty-val">{qty}</span>
                    <button className="qty-btn" onClick={() => setQty(q => Math.min(product.stock || 99, q+1))} aria-label="Növelés">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                      </svg>
                    </button>
                  </div>

                  {/* Add to cart */}
                  <button
                    className={`btn btn-primary btn-lg`}
                    style={{ flex:1 }}
                    onClick={handleAddToCart}
                    disabled={adding}
                  >
                    {added ? (
                      <>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                          <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        Hozzáadva!
                      </>
                    ) : adding ? (
                      <span className="spinner" style={{ width:20, height:20, borderWidth:2, borderColor:'rgba(255,255,255,0.3)', borderTopColor:'#fff' }}/>
                    ) : (
                      <>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                          <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                          <path d="M1 1h4l2.68 13.39a2 2 0 001.98 1.61h9.68a2 2 0 001.98-1.71L23 6H6"/>
                        </svg>
                        Kosárba teszem
                      </>
                    )}
                  </button>

                  {/* Wishlist */}
                  <button
                    className={`btn btn-ghost`}
                    style={{ width:52, height:52, padding:0, flexShrink:0, color: wishlisted ? 'var(--coral)' : 'var(--text-muted)', background: wishlisted ? 'var(--coral-light)' : 'var(--gray-50)' }}
                    onClick={() => setWishlisted(v => !v)}
                    aria-label="Kedvencekhez"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill={wishlisted ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.8">
                      <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
                    </svg>
                  </button>
                </div>
              )}

              {isOutOfStock && (
                <div style={{ background:'var(--error-bg)', borderRadius:'var(--r-md)', padding:'var(--sp-4)', color:'var(--error)', fontWeight:600, fontSize:'var(--fs-sm)' }}>
                  Ez a termék jelenleg nem elérhető.
                </div>
              )}

              {/* Features */}
              <div style={{ background:'var(--bg)', borderRadius:'var(--r-xl)', padding:'var(--sp-5)', marginTop:'var(--sp-2)' }}>
                {[
                  { icon:'🚚', text:'Szállítás 1–3 munkanapon belül' },
                  { icon:'🔧', text:'Személyes beüzemelés a helyszínen' },
                  { icon:'🛡️', text:'2 év gyártói garancia' },
                  { icon:'↩️', text:'14 napos visszaküldési jog' },
                ].map((f,i) => (
                  <div key={i} style={{ display:'flex', alignItems:'center', gap:'var(--sp-3)', padding:'var(--sp-2) 0', borderTop: i>0 ? '1px solid var(--border)' : 'none' }}>
                    <span style={{ fontSize:18 }}>{f.icon}</span>
                    <span style={{ fontSize:'var(--fs-sm)', color:'var(--text-2)' }}>{f.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </main>
  );
}
