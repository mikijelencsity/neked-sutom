import React from 'react';
import { Link } from 'react-router-dom';

function LegalLayout({ title, children }) {
  return (
    <main className="page" style={{ background: 'var(--bg)' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: 'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          <div style={{ maxWidth: 800, margin: '0 auto' }}>
            <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', marginBottom: 'var(--sp-4)' }}>
              ← Vissza a főoldalra
            </Link>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700 }}>{title}</h1>
          </div>
        </div>
      </div>
      <div className="container" style={{ padding: 'var(--sp-10) var(--container-pad) var(--sp-16)' }}>
        <div style={{ maxWidth: 800, margin: '0 auto', background: 'var(--white)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'clamp(var(--sp-6), 5vw, var(--sp-12))', lineHeight: 1.8 }}>
          {children}
        </div>
      </div>
    </main>
  );
}

const H2 = ({ children }) => <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-xl)', fontWeight: 700, marginTop: 'var(--sp-8)', marginBottom: 'var(--sp-4)', paddingTop: 'var(--sp-4)', borderTop: '1px solid var(--border)' }}>{children}</h2>;
const H3 = ({ children }) => <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-lg)', fontWeight: 600, marginTop: 'var(--sp-5)', marginBottom: 'var(--sp-2)' }}>{children}</h3>;
const P  = ({ children }) => <p style={{ color: 'var(--text-2)', marginBottom: 'var(--sp-3)', fontSize: 'var(--fs-sm)' }}>{children}</p>;
const UL = ({ children }) => <ul style={{ paddingLeft: 'var(--sp-6)', marginBottom: 'var(--sp-3)', display: 'flex', flexDirection: 'column', gap: 'var(--sp-1)' }}>{children}</ul>;
const LI = ({ children }) => <li style={{ color: 'var(--text-2)', fontSize: 'var(--fs-sm)', listStyleType: 'disc' }}>{children}</li>;

/* ─── ÁSZF ──────────────────────────────────────────────── */
export function ASZFPage() {
  return (
    <LegalLayout title="Általános Szerződési Feltételek (ÁSZF)">
      <P style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-xs)' }}>Hatályos: 2025. január 1-jétől</P>

      <H2>1. Az üzemeltető adatai</H2>
      <P>Cégnév: Cruiser Shop Kft.<br />Székhely: 6500 Baja, Kerékpár utca 1.<br />Adószám: 12345678-2-03<br />E-mail: info@cruisershop.hu<br />Telefonszám: +36 30 123 4567</P>

      <H2>2. Az ÁSZF hatálya és elfogadása</H2>
      <P>A jelen ÁSZF tartalmazza a Cruiser Shop webáruházban (a továbbiakban: Webáruház) elérhető szolgáltatások igénybevételének feltételeit. A Webáruházban történő vásárlással a Vásárló elfogadja az ÁSZF rendelkezéseit.</P>

      <H2>3. A termékek és árak</H2>
      <P>A Webáruházban feltüntetett árak forintban (Ft) értendők, és tartalmazzák az általános forgalmi adót (27% ÁFA). A Webáruház fenntartja az árak változtatásának jogát. A megrendeléskor visszaigazolt ár a vásárló számára kötelező érvényű.</P>
      <UL>
        <LI>Az árak az ÁFÁ-t tartalmazzák.</LI>
        <LI>A szállítási díj az árban nem szerepel, az a pénztár oldalon kerül feltüntetésre.</LI>
        <LI>Nyilvánvaló árhiba esetén a Webáruház nem köteles az érintett terméket az áron értékesíteni.</LI>
      </UL>

      <H2>4. A vásárlás menete</H2>
      <H3>4.1 Megrendelés leadása</H3>
      <P>A megrendelés a „Megrendelés leadása" gomb megnyomásával véglegesíthető. A megrendelés leadásával a Vásárló kötelező érvényű ajánlatot tesz a kiválasztott termékek megvásárlására.</P>
      <H3>4.2 Visszaigazolás</H3>
      <P>A Webáruház a megrendelés beérkezését automatikus e-mail visszaigazolással nyugtázza. Ez a visszaigazolás nem minősül szerződéskötésnek — a szerződés akkor jön létre, amikor a Cruiser Shop a megrendelést kifejezetten elfogadja.</P>

      <H2>5. Fizetési módok</H2>
      <UL>
        <LI><strong>Bankkártya (Stripe)</strong> — biztonságos online fizetés</LI>
        <LI><strong>Utánvét</strong> — kézbesítéskor fizet készpénzben</LI>
      </UL>

      <H2>6. Szállítás</H2>
      <P>A szállítás magyarországi címekre történik. A várható szállítási idő 3–7 munkanap. A szállítási díj rendelésenként kerül meghatározásra.</P>

      <H2>7. Elállási jog (14 napos visszaküldés)</H2>
      <P>A Vásárló a termék kézhezvételétől számított 14 napon belül indoklás nélkül elállhat a szerződéstől, és visszaküldheti a terméket. Az elállási szándékát köteles írásban jelezni az info@cruisershop.hu e-mail-címen. A visszaküldés költsége a Vásárlót terheli.</P>

      <H2>8. Garancia és jótállás</H2>
      <P>Az egyes termékekre vonatkozó jótállási feltételeket a gyártó határozza meg. A fogyasztói szerződés keretében értékesített termékekre a Polgári Törvénykönyv és a 151/2003. (IX. 22.) Korm. rendelet rendelkezései az irányadók.</P>

      <H2>9. Adatvédelem</H2>
      <P>A személyes adatok kezeléséről szóló tájékoztatót az <Link to="/adatvedelem" style={{ color: 'var(--coral)' }}>Adatvédelmi Tájékoztató</Link> tartalmazza.</P>

      <H2>10. Panaszkezelés</H2>
      <P>Panasz esetén kérjük, először vegye fel velünk a kapcsolatot az info@cruisershop.hu e-mail-címen. Ha panasza nem rendeződik, az Európai Unió online vitarendezési platformját is igénybe veheti: <a href="https://ec.europa.eu/odr" target="_blank" rel="noreferrer" style={{ color: 'var(--coral)' }}>https://ec.europa.eu/odr</a>.</P>

      <H2>11. Irányadó jog</H2>
      <P>A jelen ÁSZF-re a magyar jog az irányadó, különös tekintettel a Polgári Törvénykönyvről szóló 2013. évi V. törvényre és az elektronikus kereskedelmi szolgáltatásokról szóló 2001. évi CVIII. törvényre.</P>
    </LegalLayout>
  );
}

/* ─── Adatvédelem ───────────────────────────────────────── */
export function AdatvedelemPage() {
  return (
    <LegalLayout title="Adatvédelmi Tájékoztató">
      <P style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-xs)' }}>Hatályos: 2025. január 1-jétől | GDPR-kompatibilis</P>

      <H2>1. Az adatkezelő</H2>
      <P>Cégnév: Cruiser Shop Kft.<br />Székhely: 6500 Baja, Kerékpár utca 1.<br />E-mail: info@cruisershop.hu<br />Adatvédelmi kapcsolat: adatvedelem@cruisershop.hu</P>

      <H2>2. Milyen adatokat kezelünk?</H2>
      <H3>Regisztrációkor</H3>
      <UL>
        <LI>Teljes név</LI>
        <LI>E-mail cím</LI>
        <LI>Telefonszám (opcionális)</LI>
        <LI>Titkosított jelszó</LI>
      </UL>
      <H3>Rendeléskor</H3>
      <UL>
        <LI>Szállítási cím (név, utca, város, irányítószám, ország)</LI>
        <LI>Telefonszám</LI>
        <LI>Megrendelt termékek és összegek</LI>
        <LI>Fizetési azonosítók (Stripe — bankkártyaadatokat mi nem tárolunk)</LI>
      </UL>
      <H3>Automatikusan gyűjtött adatok</H3>
      <UL>
        <LI>IP-cím (anonimizálva, 30 nap után törlés)</LI>
        <LI>Böngésző típusa, látogatás időpontja</LI>
        <LI>Cookie-adatok (ld. lent)</LI>
      </UL>

      <H2>3. Az adatkezelés célja és jogalapja</H2>
      <UL>
        <LI><strong>Szerződés teljesítése</strong> — rendelés feldolgozása, szállítás (GDPR 6. cikk (1) b)</LI>
        <LI><strong>Jogos érdek</strong> — visszaélések megelőzése, biztonság (GDPR 6. cikk (1) f)</LI>
        <LI><strong>Jogi kötelezettség</strong> — számviteli megőrzési kötelezettség (GDPR 6. cikk (1) c)</LI>
        <LI><strong>Hozzájárulás</strong> — marketing e-mailek, elemzési sütik (GDPR 6. cikk (1) a)</LI>
      </UL>

      <H2>4. Cookie (süti) szabályzat</H2>
      <H3>Szükséges sütik</H3>
      <P>A webshop működéséhez elengedhetetlenek: munkamenet-kezelés, kosár állapota, biztonsági token. Hozzájárulás nélkül is aktívak.</P>
      <H3>Elemzési sütik</H3>
      <P>Weboldalhasználati statisztikák gyűjtéséhez (pl. Google Analytics). Csak hozzájárulással aktívak. Adatok anonimizáltak, az EU-n belül kerülnek feldolgozásra.</P>
      <H3>Marketing sütik</H3>
      <P>Személyre szabott hirdetések megjelenítéséhez. Csak hozzájárulással aktívak.</P>
      <P>A sütik beállításait bármikor módosíthatod a cookie-beállítások megnyitásával vagy a böngésző beállításaiban.</P>

      <H2>5. Adattovábbítás</H2>
      <UL>
        <LI><strong>Stripe Inc.</strong> — fizetésfeldolgozás (USA, EU–US Data Privacy Framework)</LI>
        <LI><strong>Szállítópartner</strong> — szállítási cím a futárszolgálatnak</LI>
        <LI><strong>E-mail szolgáltató</strong> — tranzakciós e-mailek küldése</LI>
      </UL>
      <P>Adatokat harmadik félnek marketing célból nem adunk át.</P>

      <H2>6. Adatok megőrzési ideje</H2>
      <UL>
        <LI>Fiókadatok: a fiók törléséig</LI>
        <LI>Rendelési adatok: 8 év (számviteli kötelezettség)</LI>
        <LI>Marketing hozzájárulás visszavonásáig: azonnal törlés</LI>
      </UL>

      <H2>7. Az érintett jogai (GDPR)</H2>
      <UL>
        <LI><strong>Hozzáférés joga</strong> — kérheted a rólad tárolt adatokat</LI>
        <LI><strong>Helyesbítés joga</strong> — kérheted a helytelen adatok javítását</LI>
        <LI><strong>Törlés joga</strong> — kérheted adataid törlését (bizonyos esetekben)</LI>
        <LI><strong>Adathordozhatóság joga</strong> — adataidat géppel olvasható formátumban kérheted</LI>
        <LI><strong>Tiltakozás joga</strong> — tiltakozhatsz az adatkezelés ellen</LI>
      </UL>
      <P>Kérelmedet az adatvedelem@cruisershop.hu e-mail-címre küldheted. 30 napon belül válaszolunk.</P>

      <H2>8. Panasz</H2>
      <P>Ha úgy véled, hogy adatkezelésünk megsérti jogaidat, panaszt tehetsz a Nemzeti Adatvédelmi és Információszabadság Hatóságnál (NAIH): <a href="https://naih.hu" target="_blank" rel="noreferrer" style={{ color: 'var(--coral)' }}>naih.hu</a></P>
    </LegalLayout>
  );
}
