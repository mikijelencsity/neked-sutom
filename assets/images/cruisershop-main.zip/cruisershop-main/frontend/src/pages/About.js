import React from 'react';
import FadeIn from '../components/FadeIn';

const REVIEWS_ALL = [
  { name: 'csaba19870221', city: 'Elégedett ügyfél', stars: 5, text: 'Korrekt eladó és gyors kiszolgálás. Sajnos az ünnepek közbeszóltak, így két hét volt, mire megkaptam a kerékpárvillát, amire szükségem volt. Ettől függetlenül minden rendben zajlott. Az eladó nem csak eladó, hanem ért is hozzá. Mindenkinek ajánlom a boltot!' },
  { name: 'Hajdó Márió', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon segítőkész volt a szerelő, minden rendben zajlott a javítással. Csak ajánlani tudom!' },
  { name: 'Barkóczi Bernadett', city: 'Baja', stars: 5, text: 'Nagyon kedves és segítőkész szolgáltató! Alig egy órája érkeztünk pár napos szabadságra Bajára, amikor észrevettük, hogy az otthonról hozott bicikli defektes. Felkerestük az üzletet, és elvállalták a javítást. Mindössze egy óra múlva már mehettünk is érte. A tulajdonos nagyon kedvesen sok programtippet is adott nekünk. Csak ajánlani tudom!' },
  { name: 'Kurcz Péter', city: 'Elégedett ügyfél', stars: 5, text: 'Második biciklit vásároltuk itt. A srác nagyon korrekt, előre nem kér egy fillért sem, az árak jóval a netes árak alatt vannak. 600 db van raktáron, szó szerint meg is mutatta nekünk őket. Nagyon elégedettek vagyunk!' },
  { name: 'Kovács Ádám', city: 'Baja', stars: 5, text: 'Nem drága, a tulajdonos rendes és segítőkész. Ha szervizelni kell a bringát, rugalmas és gyors, sokszor még aznap kész a munkával. Nagy választék van jó minőségű új biciklikből. Ajánlom!' },
  { name: 'Berta Tímea', city: 'Elégedett ügyfél', stars: 5, text: 'Profi és hozzáértő kiszolgálás. Türelmes, kedves és barátságos eladó. Csodás biciklit tudtam nála vásárolni. Csak ajánlani tudom!' },
  { name: 'Mendler Gabriella', city: 'Elégedett ügyfél', stars: 5, text: 'Meglepően széles választék, készséges és hozzáértő kiszolgálás.' },
  { name: 'Kovacs Péter', city: 'Baja', stars: 5, text: 'Baja legjobb kerékpárboltja! Udvarias kiszolgálás, jó árak, hatalmas bringaválaszték és tökéletes szerviz. Ajánlom!' },
  { name: 'Kamenik Attila', city: 'Elégedett ügyfél', stars: 5, text: 'Barátságos kiszolgálás, elfogadható árak, minőségi árucikkek.' },
  { name: 'Novok Richárd', city: 'Elégedett ügyfél', stars: 5, text: 'Profi szakértelem, hatalmas választék, olcsó árak, kedves és segítőkész kiszolgálás.' },
  { name: 'Robert Bozso', city: 'Elégedett ügyfél', stars: 5, text: 'Többször vásároltam náluk, nagyon meg vagyok elégedve. Ez egy jó kerékpárüzlet, mindenkinek ajánlom!' },
  { name: 'Groll Mária', city: 'Elégedett ügyfél', stars: 5, text: 'Gyors, pontos, precíz és nagyon udvarias kiszolgálás.' },
  { name: 'Takács Tibor', city: 'Elégedett ügyfél', stars: 5, text: 'Segítőkész és gyors kiszolgálás.' },
  { name: 'Durand Marie-lyse', city: 'Baja', stars: 5, text: 'Szerintem Baján az egyik legjobb üzlet! Mindenkinek aki megbízható boltot és kerékpárt keres csak ajánlani tudom!!!' },
  { name: 'Huszti Gergely', city: 'Elégedett ügyfél', stars: 5, text: 'A feleségemnek itt vettem meg a kerékpárját. Imádja! Szuper üzlet, jó fej tulajdonossal, remek munkaerővel!' },
  { name: 'Antonné Marcsi', city: 'Elégedett ügyfél', stars: 5, text: 'Egy üzlet ahol nem úgy néznek rád, hogy minek jöttél! Figyelmes, segítőkész, megold mindent! Leginkább az első szempont, első a VÁSÁRLÓ!' },
  { name: 'Nagy Mária', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon szeretek ide járni. Udvariasak, segítőkészek. Mindent megoldanak!!!!!' },
  { name: 'Vujevity Mónika', city: 'Elégedett ügyfél', stars: 5, text: 'Csak ajánlani tudom! Csodás az új paripám.' },
  { name: 'Selymesi Ira Mihality', city: 'Baja', stars: 5, text: 'Rengeteg szép kerékpár és praktikus, mert szerviz is itt van.' },
  { name: 'Kollár Mária', city: 'Elégedett ügyfél', stars: 5, text: 'Gyors, megbízható, kedves emberek!!!' },
  { name: 'Bíbok Zoltán', city: 'Elégedett ügyfél', stars: 5, text: 'Kiváló.' },
  { name: 'Péterfay Krisztina', city: 'Elégedett ügyfél', stars: 5, text: 'Gyors, precíz, szakszerű kiszolgálás.' },
  { name: 'Somi Évi Eve', city: 'Elégedett ügyfél', stars: 5, text: '5 csillag – tökéletes!' },
  { name: 'Német Richárd', city: 'Elégedett ügyfél', stars: 5, text: 'Minden a legjobb volt!' },
  { name: 'Száraz Éva', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon elégedett vagyok!' },
  { name: 'Gáspár Judit', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon tetszik!!!' },
  { name: 'Gombkötőné Rim Anita', city: 'Elégedett ügyfél', stars: 5, text: 'A legjobb!' },
  { name: 'Veres Péterné Ágnes', city: 'Elégedett ügyfél', stars: 5, text: 'Nagy választék és kedvesek a kiszolgálók!' },
  { name: 'Urbán Katalin', city: 'Elégedett ügyfél', stars: 5, text: 'Mindent megtalálsz amit keresel!' },
  { name: 'Mándity Margit', city: 'Elégedett ügyfél', stars: 5, text: 'Minden szupi szuper!' },
  { name: 'Ilyés Lászlóné', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon jó kerékpárok, megbízható üzlet!' },
  { name: 'Faragóné Annamária', city: 'Elégedett ügyfél', stars: 5, text: 'Egyszerűen nagyszerű!' },
  { name: 'Marsovszki Zoltán', city: 'Elégedett ügyfél', stars: 5, text: 'Igazi jó fej, imádja a munkáját!!' },
  { name: 'Zsibrek Timea', city: 'Elégedett ügyfél', stars: 5, text: 'Tökéletes kiszolgálás, ajánlom mindenkinek!' },
  { name: 'g2 hop', city: 'Elégedett ügyfél', stars: 5, text: 'Segítőkész és rendes kiszolgálás.' },
  { name: 'Juhász Emőke Simonné', city: 'Elégedett ügyfél', stars: 5, text: 'Megfelelő kiszolgálás.' },
  { name: 'Papp Zsolt', city: 'Elégedett ügyfél', stars: 5, text: 'Kiváló!' },
  { name: 'Simon József', city: 'Elégedett ügyfél', stars: 5, text: 'Jó a kiszolgálás.' },
  { name: 'Yoda Szévald', city: 'Elégedett ügyfél', stars: 5, text: 'Szép kerékpárokat árulnak.' },
];

export default function About() {
  return (
    <main className="page">

      {/* ── TRUST HEADLINE + REVIEWS ──────────────────────── */}
      <section style={{ background:'var(--gray-900)', overflow:'hidden', position:'relative' }}>

        {/* háttér dekor */}
        <div style={{ position:'absolute', top:-200, left:-200, width:600, height:600, borderRadius:'50%', background:'radial-gradient(circle, rgba(200,92,72,0.12) 0%, transparent 70%)', pointerEvents:'none' }} />
        <div style={{ position:'absolute', bottom:-100, right:-100, width:400, height:400, borderRadius:'50%', background:'radial-gradient(circle, rgba(232,164,85,0.08) 0%, transparent 70%)', pointerEvents:'none' }} />

        {/* ── TRUST HEADLINE blokk ── */}
        <div style={{
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          padding: 'var(--sp-20) 0 var(--sp-16)',
          position: 'relative', zIndex: 1,
        }}>
          <div className="container">
            <FadeIn direction="up">
              <div style={{ maxWidth: 820 }}>

                {/* eyebrow sor */}
                <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-4)', marginBottom:'var(--sp-8)' }}>
                  <div style={{ display:'inline-flex', alignItems:'center', gap:8, background:'rgba(200,92,72,0.15)', border:'1px solid rgba(200,92,72,0.3)', borderRadius:'var(--r-full)', padding:'6px 18px' }}>
                    <span style={{ width:7, height:7, borderRadius:'50%', background:'var(--coral)', boxShadow:'0 0 8px var(--coral)', animation:'pulse 2s infinite' }} />
                    <span style={{ fontSize:'var(--fs-xs)', fontWeight:700, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--coral)' }}>Valódi vélemények</span>
                  </div>
                  {/* 5 csillag sor */}
                  <div style={{ display:'flex', gap:4 }}>
                    {[1,2,3,4,5].map(i => (
                      <svg key={i} width="18" height="18" viewBox="0 0 24 24" fill="var(--peach)" stroke="none">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                      </svg>
                    ))}
                  </div>
                  <span style={{ fontSize:'var(--fs-sm)', color:'rgba(255,255,255,0.35)', fontWeight:500 }}>5.0 · Google</span>
                </div>

                {/* főcím */}
                <h2 style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(2.4rem, 5.5vw, 4.2rem)',
                  fontWeight: 900,
                  color: 'white',
                  lineHeight: 1.06,
                  letterSpacing: '-0.025em',
                  marginBottom: 'var(--sp-6)',
                }}>
                  A bizalom<br />
                  <span style={{
                    background: 'linear-gradient(90deg, var(--coral) 0%, var(--peach) 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                  }}>megkérdőjelezhetetlen.</span>
                </h2>

                {/* alcím */}
                <p style={{
                  fontSize: 'clamp(var(--fs-md), 2vw, var(--fs-lg))',
                  color: 'rgba(255,255,255,0.45)',
                  lineHeight: 1.75,
                  maxWidth: 580,
                }}>
                  Több mint 5000 elégedett vásárló, egyetlen hangos üzenet —&nbsp;
                  <em style={{ color:'rgba(255,255,255,0.7)', fontStyle:'normal' }}>nem az ár, nem a választék, hanem az ember számít.</em>
                  {' '}Nálunk mindig te vagy az első.
                </p>

              </div>
            </FadeIn>
          </div>
        </div>

        {/* ── MASONRY REVIEWS ── */}
        <div className="container" style={{ position:'relative', zIndex:1, paddingTop:'var(--sp-16)', paddingBottom:'var(--sp-20)' }}>
          <div style={{ columns:'3 300px', gap:'var(--sp-5)' }}>
            {REVIEWS_ALL.map((r, i) => (
              <FadeIn key={r.name + i} direction="up" delay={(i % 6) * 0.07}>
                <div
                  style={{
                    breakInside: 'avoid',
                    marginBottom: 'var(--sp-5)',
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.07)',
                    borderRadius: 'var(--r-xl)',
                    padding: 'var(--sp-6)',
                    transition: 'background 0.2s, border-color 0.2s',
                    cursor: 'default',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background='rgba(200,92,72,0.07)'; e.currentTarget.style.borderColor='rgba(200,92,72,0.22)'; }}
                  onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,0.03)'; e.currentTarget.style.borderColor='rgba(255,255,255,0.07)'; }}
                >
                  {/* csillagok */}
                  <div style={{ display:'flex', gap:3, marginBottom:'var(--sp-3)' }}>
                    {Array.from({ length: r.stars }).map((_, j) => (
                      <svg key={j} width="13" height="13" viewBox="0 0 24 24" fill="var(--peach)" stroke="none">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                      </svg>
                    ))}
                  </div>

                  {/* szöveg */}
                  <p style={{ fontSize:'var(--fs-sm)', color:'rgba(255,255,255,0.62)', lineHeight:1.78, fontStyle:'italic', marginBottom:'var(--sp-4)' }}>
                    „{r.text}"
                  </p>

                  {/* avatar + név */}
                  <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-3)' }}>
                    <div style={{
                      width:34, height:34, borderRadius:'50%',
                      background:'rgba(200,92,72,0.18)',
                      color:'var(--coral)',
                      display:'flex', alignItems:'center', justifyContent:'center',
                      fontWeight:700, fontSize:'var(--fs-sm)', flexShrink:0,
                    }}>
                      {r.name[0].toUpperCase()}
                    </div>
                    <div>
                      <div style={{ fontWeight:600, color:'white', fontSize:'var(--fs-sm)' }}>{r.name}</div>
                      {r.city && <div style={{ fontSize:'var(--fs-xs)', color:'rgba(255,255,255,0.28)' }}>{r.city}</div>}
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>

        <style>{`
          @keyframes pulse {
            0%, 100% { opacity:1; box-shadow:0 0 8px var(--coral); }
            50%       { opacity:0.5; box-shadow:0 0 16px var(--coral); }
          }
        `}</style>
      </section>

    </main>
  );
}