export { ForgotPasswordPage as default } from './AllPages';
