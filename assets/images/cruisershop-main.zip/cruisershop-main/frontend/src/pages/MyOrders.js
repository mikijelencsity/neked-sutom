export { MyOrdersPage as default } from './AllPages';
