import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

const CATEGORIES = [
  { slug: '',          label: 'Összes' },
  { slug: 'elektromos', label: 'Elektromos kerékpár' },
  { slug: 'tura',       label: 'Túrakerékpár' },
  { slug: 'varosi',     label: 'Városi kerékpár' },
  { slug: 'gyermek',    label: 'Gyermekkerékpár' },
];

const SORT_OPTIONS = [
  { value: '',           label: 'Alapértelmezett' },
  { value: 'price_asc',  label: 'Ár: alacsony → magas' },
  { value: 'price_desc', label: 'Ár: magas → alacsony' },
  { value: 'name_asc',   label: 'Név (A–Z)' },
];

export default function Shop() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(true);
  const [inputVal, setInputVal] = useState(searchParams.get('search') || '');
  const [search, setSearch]     = useState(searchParams.get('search') || '');
  const [drawerOpen, setDrawerOpen] = useState(false);

  const category = searchParams.get('category') || '';
  const sort     = searchParams.get('sort')     || '';
  const page     = parseInt(searchParams.get('page') || '1', 10);
  const limit    = 9;

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (category) params.set('category', category);
      if (search)   params.set('search', search);
      if (sort)     params.set('sort', sort);
      params.set('page', page);
      params.set('limit', limit);
      const r    = await api('/api/products?' + params);
      const data = await r.json();
      setProducts(data.products || data || []);
      setTotal(data.total || 0);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, [category, search, sort, page]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'smooth' }); }, [page]);
  useEffect(() => {
    document.body.style.overflow = drawerOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [drawerOpen]);

  const setParam = (key, value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value); else next.delete(key);
    if (key !== 'page') next.delete('page');
    setSearchParams(next);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setSearch(inputVal);
    setParam('search', inputVal);
  };

  const clearAll = () => {
    setSearchParams({});
    setSearch('');
    setInputVal('');
    setDrawerOpen(false);
  };

  const totalPages   = Math.ceil(total / limit);
  const hasFilters   = !!(category || search || sort);
  const currentLabel = CATEGORIES.find(c => c.slug === category)?.label || 'Összes';

  const Sidebar = () => (
    <>
      {/* Categories */}
      <p className="filter-section-title">Kategória</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-1)', marginBottom: 'var(--sp-5)' }}>
        {CATEGORIES.map(c => (
          <button
            key={c.slug}
            onClick={() => { setParam('category', c.slug); setDrawerOpen(false); }}
            style={{
              padding: '9px 14px',
              borderRadius: 'var(--r-md)',
              fontSize: 'var(--fs-sm)',
              fontWeight: c.slug === category ? 600 : 400,
              color: c.slug === category ? 'var(--coral)' : 'var(--text-muted)',
              background: c.slug === category ? 'var(--coral-light)' : 'transparent',
              border: 'none',
              cursor: 'pointer',
              textAlign: 'left',
              transition: 'all var(--t-fast)',
            }}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="filter-divider" />

      {/* Sort */}
      <p className="filter-section-title">Rendezés</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-1)' }}>
        {SORT_OPTIONS.map(o => (
          <button
            key={o.value}
            onClick={() => { setParam('sort', o.value); setDrawerOpen(false); }}
            style={{
              padding: '9px 14px',
              borderRadius: 'var(--r-md)',
              fontSize: 'var(--fs-sm)',
              fontWeight: o.value === sort ? 600 : 400,
              color: o.value === sort ? 'var(--coral)' : 'var(--text-muted)',
              background: o.value === sort ? 'var(--coral-light)' : 'transparent',
              border: 'none',
              cursor: 'pointer',
              textAlign: 'left',
              transition: 'all var(--t-fast)',
            }}
          >
            {o.label}
          </button>
        ))}
      </div>

      {hasFilters && (
        <>
          <div className="filter-divider" />
          <button className="btn btn-ghost btn-full" onClick={clearAll}>
            Szűrők törlése
          </button>
        </>
      )}
    </>
  );

  return (
    <main className="page">
      {/* Page header */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: 'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          {/* Breadcrumb */}
          <div className="breadcrumb" style={{ marginBottom: 'var(--sp-4)' }}>
            <a href="/">Kezdőlap</a>
            <span className="breadcrumb__sep">›</span>
            <span style={{ color: 'var(--text)', fontWeight: 500 }}>Kerékpárok</span>
            {category && (
              <>
                <span className="breadcrumb__sep">›</span>
                <span style={{ color: 'var(--coral)', fontWeight: 500 }}>{currentLabel}</span>
              </>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
            <div>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.4rem)', fontWeight: 700, color: 'var(--text)', letterSpacing: '-0.02em' }}>
                {category ? currentLabel : 'Összes kerékpár'}
              </h1>
              {!loading && (
                <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', marginTop: 4 }}>
                  {total} termék
                </p>
              )}
            </div>

            {/* Mobile filter button + search */}
            <div style={{ display: 'flex', gap: 'var(--sp-3)', alignItems: 'center' }}>
              <form onSubmit={handleSearch} style={{ position: 'relative', display: 'flex', gap: 8 }}>
                <input
                  className="form-input"
                  style={{ height: 42, borderRadius: 'var(--r-full)', paddingLeft: 40, width: '220px' }}
                  type="text"
                  placeholder="Kerékpár neve..."
                  value={inputVal}
                  onChange={e => setInputVal(e.target.value)}
                />
                <span style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                  </svg>
                </span>
                <button type="submit" className="btn btn-primary btn-sm">Keresés</button>
              </form>

              {/* Mobile filter */}
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => setDrawerOpen(true)}
                style={{ display: 'none' }}
                id="mobile-filter-btn"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/>
                </svg>
                Szűrés
              </button>
            </div>
          </div>

          {/* Active filter chips */}
          {hasFilters && (
            <div style={{ display: 'flex', gap: 'var(--sp-2)', marginTop: 'var(--sp-4)', flexWrap: 'wrap', alignItems: 'center' }}>
              <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', fontWeight: 500 }}>Szűrők:</span>
              {category && (
                <button className="badge badge-coral" onClick={() => setParam('category', '')} style={{ cursor: 'pointer' }}>
                  {currentLabel} ×
                </button>
              )}
              {search && (
                <button className="badge badge-coral" onClick={() => { setSearch(''); setInputVal(''); setParam('search', ''); }} style={{ cursor: 'pointer' }}>
                  "{search}" ×
                </button>
              )}
              {sort && (
                <button className="badge badge-gray" onClick={() => setParam('sort', '')} style={{ cursor: 'pointer' }}>
                  {SORT_OPTIONS.find(o => o.value === sort)?.label} ×
                </button>
              )}
              <button onClick={clearAll} style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', fontWeight: 500, textDecoration: 'underline', background: 'none', border: 'none', cursor: 'pointer' }}>
                Törlés
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main content */}
      <div className="container" style={{ padding: 'var(--sp-8) var(--container-pad)' }}>
        <div className="shop-layout">
          {/* Desktop sidebar */}
          <aside className="shop-sidebar">
            <Sidebar />
          </aside>

          {/* Product grid */}
          <div>
            {loading ? (
              <div className="product-grid">
                {Array.from({ length: 9 }).map((_, i) => (
                  <div key={i} style={{ borderRadius: 'var(--r-xl)', overflow: 'hidden', border: '1px solid var(--border)' }}>
                    <div className="skeleton" style={{ height: 220 }} />
                    <div style={{ padding: 20 }}>
                      <div className="skeleton" style={{ height: 12, width: '40%', marginBottom: 10 }} />
                      <div className="skeleton" style={{ height: 20, marginBottom: 6 }} />
                      <div className="skeleton" style={{ height: 16, width: '60%' }} />
                    </div>
                  </div>
                ))}
              </div>
            ) : products.length > 0 ? (
              <>
                <div className="product-grid">
                  {products.map((p, i) => (
                    <FadeIn key={p.id} direction="up" delay={i * 0.05} threshold={0.05}>
                      <ProductCard product={p} />
                    </FadeIn>
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="pagination">
                    <button
                      className="page-btn"
                      disabled={page <= 1}
                      onClick={() => setParam('page', page - 1)}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <path d="M15 18l-6-6 6-6"/>
                      </svg>
                    </button>
                    {Array.from({ length: totalPages }, (_, i) => i + 1)
                      .filter(pg => Math.abs(pg - page) <= 2)
                      .map(pg => (
                        <button
                          key={pg}
                          className={`page-btn${pg === page ? ' active' : ''}`}
                          onClick={() => setParam('page', pg)}
                        >
                          {pg}
                        </button>
                      ))}
                    <button
                      className="page-btn"
                      disabled={page >= totalPages}
                      onClick={() => setParam('page', page + 1)}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <path d="M9 18l6-6-6-6"/>
                      </svg>
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="empty-state">
                <div className="empty-state__icon">🔍</div>
                <h3 className="empty-state__title">Nincs találat</h3>
                <p style={{ marginBottom: 'var(--sp-6)' }}>
                  {search ? `Nem találtunk terméket erre: "${search}"` : 'Próbálj más szűrőt'}
                </p>
                <button className="btn btn-primary" onClick={clearAll}>Szűrők törlése</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      {drawerOpen && (
        <>
          <div
            style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 600 }}
            onClick={() => setDrawerOpen(false)}
          />
          <div style={{
            position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 601,
            background: 'var(--white)', borderRadius: 'var(--r-2xl) var(--r-2xl) 0 0',
            padding: 'var(--sp-6)',
            maxHeight: '85vh', overflowY: 'auto',
            boxShadow: 'var(--shadow-xl)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 'var(--sp-5)' }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-xl)', fontWeight: 700 }}>Szűrők</span>
              <button onClick={() => setDrawerOpen(false)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>
            <Sidebar />
          </div>
        </>
      )}
    </main>
  );
}