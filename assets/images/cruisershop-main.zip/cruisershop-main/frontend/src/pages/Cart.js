import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import { AuthContext } from '../context/AuthContext';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style:'currency', currency:'HUF', maximumFractionDigits:0 }).format(n);
}

export default function Cart() {
  const { cartItems, cartTotal, cartCount, updateQuantity, removeFromCart, clearCart } = useContext(CartContext);
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  const shipping = cartTotal >= 80000 ? 0 : 4990;
  const total    = cartTotal + shipping;

  if (cartCount === 0) return (
    <main className="page">
      <div className="container" style={{ paddingTop: 80 }}>
        <div className="empty-state">
          <div className="empty-state__icon">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="var(--coral-mid)" strokeWidth="1.5" style={{ margin:'0 auto' }}>
              <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
              <path d="M1 1h4l2.68 13.39a2 2 0 001.98 1.61h9.68a2 2 0 001.98-1.71L23 6H6"/>
            </svg>
          </div>
          <h2 className="empty-state__title" style={{ marginTop:'var(--sp-4)' }}>A kosarad üres</h2>
          <p style={{ marginBottom:'var(--sp-7)' }}>Nézd meg kerékpárkínálatunkat és találd meg az álom bringát!</p>
          <Link to="/kerekparok" className="btn btn-primary btn-lg">Kerékpárok böngészése</Link>
        </div>
      </div>
    </main>
  );

  return (
    <main className="page">
      <div style={{ background:'var(--white)', borderBottom:'1px solid var(--border)', padding:'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          <div className="breadcrumb" style={{ marginBottom:'var(--sp-3)' }}>
            <Link to="/">Kezdőlap</Link>
            <span className="breadcrumb__sep">›</span>
            <span style={{ color:'var(--text)', fontWeight:500 }}>Kosár</span>
          </div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,4vw,2.2rem)', fontWeight:700, color:'var(--text)', letterSpacing:'-0.02em' }}>
              Kosár ({cartCount} termék)
            </h1>
            <button
              onClick={clearCart}
              style={{ fontSize:'var(--fs-sm)', color:'var(--text-muted)', fontWeight:500, display:'flex', alignItems:'center', gap:6, transition:'color var(--t-fast)' }}
              onMouseEnter={e => e.currentTarget.style.color='var(--error)'}
              onMouseLeave={e => e.currentTarget.style.color='var(--text-muted)'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
              </svg>
              Kosár ürítése
            </button>
          </div>
        </div>
      </div>

      <div className="container" style={{ padding:'var(--sp-8) var(--container-pad) var(--sp-16)' }}>
        <div className="cart-layout">
          {/* Items */}
          <div>
            <div style={{ background:'var(--white)', borderRadius:'var(--r-xl)', border:'1px solid var(--border)', padding:'0 var(--sp-6)' }}>
              {cartItems.map(item => (
                <div key={item.id} className="cart-item">
                  <img
                    className="cart-item__img"
                    src={item.image_url || 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=200'}
                    alt={item.name}
                  />
                  <div className="cart-item__info">
                    <div className="cart-item__name">{item.name}</div>
                    <div className="cart-item__price">{formatPrice(item.price)}</div>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-3)' }}>
                    <div className="qty-control">
                      <button className="qty-btn" onClick={() => updateQuantity(item.id, item.quantity - 1)}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      </button>
                      <span className="qty-val">{item.quantity}</span>
                      <button className="qty-btn" onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      </button>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      style={{ width:32, height:32, display:'flex', alignItems:'center', justifyContent:'center', borderRadius:'var(--r-full)', color:'var(--text-muted)', transition:'all var(--t-fast)', flexShrink:0 }}
                      onMouseEnter={e => { e.currentTarget.style.background='var(--error-bg)'; e.currentTarget.style.color='var(--error)'; }}
                      onMouseLeave={e => { e.currentTarget.style.background=''; e.currentTarget.style.color='var(--text-muted)'; }}
                      aria-label="Törlés"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <Link to="/kerekparok" style={{ display:'inline-flex', alignItems:'center', gap:'var(--sp-2)', marginTop:'var(--sp-5)', fontSize:'var(--fs-sm)', color:'var(--text-muted)', fontWeight:500, transition:'color var(--t-fast)' }}
              onMouseEnter={e => e.currentTarget.style.color='var(--coral)'}
              onMouseLeave={e => e.currentTarget.style.color='var(--text-muted)'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
              Vásárlás folytatása
            </Link>
          </div>

          {/* Summary */}
          <div className="summary-card">
            <h2 style={{ fontFamily:'var(--font-display)', fontSize:'var(--fs-xl)', fontWeight:700, marginBottom:'var(--sp-5)' }}>Összesítő</h2>

            <div className="summary-row">
              <span style={{ color:'var(--text-muted)', fontSize:'var(--fs-sm)' }}>Részösszeg ({cartCount} db)</span>
              <span style={{ fontWeight:600 }}>{formatPrice(cartTotal)}</span>
            </div>
            <div className="summary-row">
              <span style={{ color:'var(--text-muted)', fontSize:'var(--fs-sm)' }}>Szállítás</span>
              {shipping === 0 ? (
                <span className="badge badge-success">Ingyenes</span>
              ) : (
                <span style={{ fontWeight:600 }}>{formatPrice(shipping)}</span>
              )}
            </div>
            {shipping > 0 && (
              <p style={{ fontSize:'var(--fs-xs)', color:'var(--text-muted)', marginTop:'var(--sp-2)' }}>
                Ingyenes szállítás {formatPrice(80000)} felett
              </p>
            )}
            <div className="summary-row" style={{ paddingTop:'var(--sp-4)' }}>
              <span style={{ fontWeight:700, fontSize:'var(--fs-md)' }}>Összesen</span>
              <span className="summary-total">{formatPrice(total)}</span>
            </div>

            <div style={{ marginTop:'var(--sp-5)', display:'flex', flexDirection:'column', gap:'var(--sp-3)' }}>
              {user ? (
                <button className="btn btn-primary btn-full btn-lg" onClick={() => navigate('/rendeles')}>
                  Megrendelés
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </button>
              ) : (
                <>
                  <button className="btn btn-primary btn-full btn-lg" onClick={() => navigate('/bejelentkezes')}>
                    Bejelentkezés a vásárláshoz
                  </button>
                  <p style={{ fontSize:'var(--fs-xs)', textAlign:'center', color:'var(--text-muted)' }}>
                    Még nincs fiókod?{' '}
                    <Link to="/regisztracio" style={{ color:'var(--coral)', fontWeight:600 }}>Regisztrálj ingyen</Link>
                  </p>
                </>
              )}
            </div>

            {/* Reassurance */}
            <div style={{ marginTop:'var(--sp-5)', paddingTop:'var(--sp-5)', borderTop:'1px solid var(--border)' }}>
              {[
                { icon:'🔒', text:'Biztonságos fizetés' },
                { icon:'🚚', text:'Gyors, megbízható szállítás' },
                { icon:'↩️', text:'14 napos visszaküldés' },
              ].map((f,i) => (
                <div key={i} style={{ display:'flex', alignItems:'center', gap:'var(--sp-2)', padding:'var(--sp-1) 0', fontSize:'var(--fs-xs)', color:'var(--text-muted)' }}>
                  <span>{f.icon}</span>{f.text}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
