import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import FadeIn from '../components/FadeIn';

const SERVICES = [
  {
    id: 'szerviz',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/>
      </svg>
    ),
    title: 'Teljes szervizelés',
    subtitle: 'Gyors és szakszerű javítás',
    desc: 'Szervizünk gyors és szakszerű megoldást kínál minden kerékpár és roller javítására. Legyen szó fék- vagy váltóbeállításról, lánccseréről, csapágyjavításról vagy nagyobb karbantartásról, nálunk biztos kezekben van a járműved.',
    items: [
      'Fék- és váltóbeállítás',
      'Lánc- és kerékcsere',
      'Defektjavítás',
      'Csapágyjavítás és -csere',
      'Szezonális átvizsgálás',
      'Elektromos kerékpár karbantartás',
    ],
    color: 'var(--coral)',
    bg: 'var(--coral-light)',
  },
  {
    id: 'ertekesites',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
        <line x1="3" y1="6" x2="21" y2="6"/>
        <path d="M16 10a4 4 0 01-8 0"/>
      </svg>
    ),
    title: 'Kerékpárok értékesítése',
    subtitle: 'Széles választék, személyes tanácsadás',
    desc: 'Kerékpárboltunkban mindenki megtalálja a számára ideális bringát – a városi közlekedéstől a hosszabb túrákig. Válogass széles választékunkból: városi, túra, gyermek és elektromos kerékpárok, valamint robogók várnak rád. Segítünk a választásban.',
    items: [
      'Városi kerékpárok',
      'Túrakerékpárok',
      'Elektromos kerékpárok',
      'Gyerekkerékpárok',
      'ZTECH e-bike modellek',
      'Rollerek és robogók',
    ],
    color: 'var(--peach-hover)',
    bg: 'var(--peach-light)',
  },
  {
    id: 'alkatresz',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <circle cx="12" cy="12" r="3"/>
        <path d="M19.07 4.93a10 10 0 010 14.14M4.93 4.93a10 10 0 000 14.14"/>
        <path d="M12 2v2M12 20v2M2 12h2M20 12h2"/>
      </svg>
    ),
    title: 'Alkatrészek és kiegészítők',
    subtitle: 'Minden, ami a kerékpározáshoz kell',
    desc: 'Széles választékban kínálunk kerékpáralkatrészeket és kiegészítőket. Minden, ami kényelmessé és biztonságossá teszi a kerékpározást – megtalálható nálunk.',
    items: [
      'Sisak és védőfelszerelés',
      'Kerékpár világítás',
      'Zárak és biztonsági eszközök',
      'Táskák és csomagtartók',
      'Bringás ruházat',
      'Kosár, kulacstartó, nyeregpárna',
    ],
    color: '#3A7BD5',
    bg: '#EBF2FF',
  },
  {
    id: 'ebike',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <ellipse cx="12" cy="17" rx="9" ry="3"/>
        <path d="M12 14v3"/>
        <path d="M7 7l5-5 5 5"/>
        <path d="M12 2v12"/>
        <circle cx="12" cy="12" r="1" fill="currentColor"/>
      </svg>
    ),
    title: 'E-bike specialista',
    subtitle: 'Elektromos kerékpár és roller szerviz',
    desc: 'Természetesen fogadunk elektromos kerékpárokat és rollereket szervizre. Akkumulátor-karbantartás, motorbeállítás és általános átvizsgálás is elérhető nálunk. A ZTECH márka hivatalos partnerei vagyunk.',
    items: [
      'Akkumulátor-karbantartás',
      'Motorbeállítás és diagnosztika',
      'ZTECH termékek szervize',
      'E-bike átvizsgálás',
      'Szoftverfrissítés',
      'Töltőrendszer ellenőrzés',
    ],
    color: '#2D9E6B',
    bg: '#E6F7EF',
  },
];

const FAQ = [
  {
    q: 'Milyen méretű kerékpárt válasszak?',
    a: 'A megfelelő méret függ a testmagasságodtól és a bringázás céljától. Általában 150–165 cm között a 26"-os, 165–180 cm között a 28"-as, 180 cm felett pedig nagyobb vázméret az ideális. Ha bizonytalan vagy, segítünk személyesen kiválasztani és beállítani.',
  },
  {
    q: 'Milyen szervizszolgáltatásokat kínáltok?',
    a: 'Vállalunk teljes körű szervizt: fék- és váltóbeállítást, lánc- és kerékcserét, defektjavítást, elektromos bringák karbantartását, valamint szezonális átvizsgálást.',
  },
  {
    q: 'Fogadtok elektromos kerékpárokat és rollereket szervizre?',
    a: 'Természetesen! Akkumulátor-karbantartás, motorbeállítás és általános átvizsgálás is elérhető nálunk.',
  },
  {
    q: 'Van garancia az új kerékpárokra?',
    a: 'Igen, minden új kerékpárra gyári garancia jár. Emellett biztosítjuk a garanciális szervizelést és az alkatrészek utánpótlását.',
  },
  {
    q: 'Milyen kiegészítőket találok nálatok?',
    a: 'Sisak, világítás, lakat, kulacstartó, csomagtartó, kosár, nyeregpárna és sok más hasznos tartozék, amivel kényelmesebbé és biztonságosabbá teheted a kerékpározást.',
  },
];

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-lg)',
      overflow: 'hidden',
      background: 'var(--white)',
      transition: 'box-shadow 0.2s',
      boxShadow: open ? 'var(--shadow-md)' : 'var(--shadow-xs)',
    }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center',
          justifyContent: 'space-between', gap: 'var(--sp-4)',
          padding: 'var(--sp-5) var(--sp-6)',
          textAlign: 'left', background: 'none',
          fontFamily: 'var(--font-body)', fontWeight: 600,
          fontSize: 'var(--fs-base)', color: 'var(--text)',
          cursor: 'pointer',
        }}
      >
        {q}
        <span style={{
          flexShrink: 0, width: 28, height: 28,
          borderRadius: 'var(--r-full)',
          background: open ? 'var(--coral)' : 'var(--gray-100)',
          color: open ? 'var(--white)' : 'var(--text-muted)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 0.2s',
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
            style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </span>
      </button>
      {open && (
        <div style={{
          padding: '0 var(--sp-6) var(--sp-5)',
          color: 'var(--text-muted)',
          lineHeight: 1.7,
          fontSize: 'var(--fs-sm)',
          borderTop: '1px solid var(--border)',
          paddingTop: 'var(--sp-4)',
        }}>
          {a}
        </div>
      )}
    </div>
  );
}

export default function Services() {
  return (
    <main className="page">

      {/* ── HERO ─────────────────────────────────────────── */}
      <section style={{
        background: 'linear-gradient(135deg, #1C1C1E 0%, #2C2C2E 100%)',
        padding: 'var(--sp-20) 0',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -100, right: -100,
          width: 500, height: 500, borderRadius: '50%',
          background: 'rgba(232,164,85,0.07)', pointerEvents: 'none',
        }} />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <FadeIn direction="up">
            <div style={{ maxWidth: 640 }}>
              <span className="badge badge-peach" style={{ marginBottom: 'var(--sp-4)', display: 'inline-flex' }}>
                Amit kínálunk
              </span>
              <h1 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(var(--fs-4xl), 5vw, var(--fs-6xl))',
                color: 'var(--white)', lineHeight: 1.1,
                marginBottom: 'var(--sp-6)',
              }}>
                Szolgáltatásaink
              </h1>
              <p style={{
                fontSize: 'var(--fs-lg)',
                color: 'rgba(255,255,255,0.65)',
                lineHeight: 1.7, maxWidth: 520,
                marginBottom: 'var(--sp-8)',
              }}>
                Teljes körű kerékpáros kiszolgálás Baján – értékesítéstől a szervizizg, alkatrészektől az e-bike specialista szolgáltatásig.
              </p>
              <div style={{ display: 'flex', gap: 'var(--sp-4)', flexWrap: 'wrap' }}>
                <Link to="/kapcsolat" className="btn btn-primary btn-lg">Időpontot foglalok</Link>
                <Link to="/kerekparok" className="btn btn-white btn-lg">Kerékpárok böngészése</Link>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── SERVICES GRID ────────────────────────────────── */}
      <section className="section">
        <div className="container">
          <FadeIn direction="up">
            <div style={{ textAlign: 'center', maxWidth: 560, margin: '0 auto var(--sp-16)' }}>
              <h2 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(var(--fs-3xl), 3.5vw, var(--fs-4xl))',
                lineHeight: 1.2, marginBottom: 'var(--sp-4)',
              }}>
                Miben segíthetünk?
              </h2>
              <p style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-md)', lineHeight: 1.7 }}>
                Üzletemben mindent megtalálsz, ami a kerékpározáshoz szükséges.
              </p>
            </div>
          </FadeIn>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-8)' }}>
            {SERVICES.map((s, i) => (
              <FadeIn key={s.id} direction={i % 2 === 0 ? 'left' : 'right'} delay={0.05}>
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                  gap: 'var(--sp-10)',
                  alignItems: 'center',
                  background: 'var(--white)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--r-2xl)',
                  padding: 'var(--sp-10)',
                  boxShadow: 'var(--shadow-sm)',
                  flexDirection: i % 2 !== 0 ? 'row-reverse' : 'row',
                }}>
                  <div>
                    <div style={{
                      display: 'inline-flex', alignItems: 'center', gap: 'var(--sp-3)',
                      marginBottom: 'var(--sp-5)',
                    }}>
                      <div style={{
                        width: 68, height: 68,
                        borderRadius: 'var(--r-xl)',
                        background: s.bg,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: s.color, flexShrink: 0,
                      }}>
                        {s.icon}
                      </div>
                      <div>
                        <div style={{ fontSize: 'var(--fs-xs)', color: s.color, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
                          {s.subtitle}
                        </div>
                        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-2xl)', lineHeight: 1.2 }}>
                          {s.title}
                        </h3>
                      </div>
                    </div>
                    <p style={{ color: 'var(--text-muted)', lineHeight: 1.8, fontSize: 'var(--fs-md)', marginBottom: 'var(--sp-6)' }}>
                      {s.desc}
                    </p>
                    <Link to="/kapcsolat" className="btn btn-outline btn-sm">
                      Érdeklődöm
                    </Link>
                  </div>

                  <div style={{
                    background: 'var(--gray-50)',
                    borderRadius: 'var(--r-xl)',
                    padding: 'var(--sp-6)',
                  }}>
                    <div style={{ fontSize: 'var(--fs-sm)', fontWeight: 600, color: 'var(--text-2)', marginBottom: 'var(--sp-4)' }}>
                      Beletartozik:
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
                      {s.items.map(item => (
                        <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)' }}>
                          <div style={{
                            width: 22, height: 22, borderRadius: 'var(--r-full)',
                            background: s.bg, flexShrink: 0,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={s.color} strokeWidth="3">
                              <polyline points="20 6 9 17 4 12"/>
                            </svg>
                          </div>
                          <span style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-2)' }}>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────── */}
      <section className="section" style={{ background: 'var(--gray-50)' }}>
        <div className="container" style={{ maxWidth: 760, margin: '0 auto' }}>
          <FadeIn direction="up">
            <div style={{ textAlign: 'center', marginBottom: 'var(--sp-12)' }}>
              <span className="badge badge-coral" style={{ marginBottom: 'var(--sp-4)', display: 'inline-flex' }}>
                Gyori kérdések
              </span>
              <h2 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(var(--fs-3xl), 3.5vw, var(--fs-4xl))',
                lineHeight: 1.2,
              }}>
                Gyakori kérdések
              </h2>
              <p style={{ color: 'var(--text-muted)', marginTop: 'var(--sp-4)', fontSize: 'var(--fs-md)' }}>
                Összegyűjtöttük a leggyakoribb kérdéseket, hogy gyorsan megtaláld a választ.
              </p>
            </div>
          </FadeIn>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
            {FAQ.map((f, i) => (
              <FadeIn key={i} direction="up" delay={i * 0.06}>
                <FaqItem q={f.q} a={f.a} />
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────── */}
      <section className="section">
        <div className="container">
          <FadeIn direction="up">
            <div style={{
              background: 'linear-gradient(135deg, var(--gray-900) 0%, #2C2C2E 100%)',
              borderRadius: 'var(--r-2xl)',
              padding: 'clamp(var(--sp-10), 6vw, var(--sp-20))',
              textAlign: 'center',
              position: 'relative', overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute', top: -80, right: -80,
                width: 280, height: 280, borderRadius: '50%',
                background: 'rgba(200,92,72,0.1)', pointerEvents: 'none',
              }} />
              <h2 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(var(--fs-3xl), 4vw, var(--fs-5xl))',
                color: 'var(--white)',
                marginBottom: 'var(--sp-4)',
                position: 'relative', zIndex: 1,
              }}>
                Kérdésed van? Hívj minket!
              </h2>
              <p style={{
                color: 'rgba(255,255,255,0.65)',
                fontSize: 'var(--fs-lg)',
                marginBottom: 'var(--sp-8)',
                position: 'relative', zIndex: 1,
              }}>
                +36 70 210 7706 &nbsp;·&nbsp; +36 70 584 4414
              </p>
              <div style={{ display: 'flex', gap: 'var(--sp-4)', justifyContent: 'center', flexWrap: 'wrap', position: 'relative', zIndex: 1 }}>
                <a href="tel:+36702107706" className="btn btn-primary btn-lg">Felhívom az üzletet</a>
                <Link to="/kapcsolat" className="btn btn-lg" style={{
                  background: 'rgba(255,255,255,0.1)',
                  color: 'var(--white)',
                  border: '1.5px solid rgba(255,255,255,0.3)',
                }}>
                  Kapcsolati oldal
                </Link>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

    </main>
  );
}
