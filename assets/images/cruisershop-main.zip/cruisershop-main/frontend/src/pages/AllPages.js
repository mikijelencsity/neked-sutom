import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(n);
}
const Eye    = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
const EyeOff = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>;

function AuthPage({ title, subtitle, children, wide }) {
  return (
    <div className="auth-page">
      <FadeIn direction="scale">
        <div className="auth-card" style={wide ? { maxWidth: 600 } : {}}>
          <div className="auth-logo"><img src="/logo.png" alt="The Cruiser Shop" /></div>
          <h1 className="auth-title">{title}</h1>
          {subtitle && <p className="auth-sub">{subtitle}</p>}
          {children}
        </div>
      </FadeIn>
    </div>
  );
}

/* ─── LOGIN ─────────────────────────────────────────────── */
export function LoginPage() {
  const { login }   = useContext(AuthContext);
  const navigate    = useNavigate();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const [showPwd, setShowPwd]   = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      const user = await login(email, password);
      navigate(user.role === 'admin' ? '/admin' : '/');
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  };

  return (
    <AuthPage title="Bejelentkezés" subtitle="Üdvözlünk vissza a Cruiser Shopban!">
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
        <div className="form-group">
          <label className="form-label">E-mail cím</label>
          <input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="pelda@email.hu" required autoComplete="email" />
        </div>
        <div className="form-group">
          <label className="form-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
            Jelszó
            <Link to="/elfelejtett-jelszo" style={{ fontSize: 'var(--fs-xs)', color: 'var(--coral)', fontWeight: 600 }}>Elfelejtett?</Link>
          </label>
          <div style={{ position: 'relative' }}>
            <input className="form-input" type={showPwd ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required autoComplete="current-password" style={{ paddingRight: 48 }} />
            <button type="button" onClick={() => setShowPwd(v => !v)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', padding: 4 }}>
              {showPwd ? <EyeOff /> : <Eye />}
            </button>
          </div>
        </div>
        {error && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--error)', fontWeight: 500, background: 'var(--error-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)' }}>{error}</p>}
        <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading} style={{ marginTop: 'var(--sp-2)' }}>
          {loading ? <span className="spinner" style={{ width: 20, height: 20, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : 'Bejelentkezés'}
        </button>
        <p style={{ textAlign: 'center', fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>
          Még nincs fiókod?{' '}<Link to="/regisztracio" style={{ color: 'var(--coral)', fontWeight: 600 }}>Regisztrálj</Link>
        </p>
      </form>
    </AuthPage>
  );
}

/* ─── REGISTER ──────────────────────────────────────────── */
export function RegisterPage() {
  const { register } = useContext(AuthContext);
  const navigate     = useNavigate();
  const [form, setForm]       = useState({ name: '', email: '', password: '', password2: '', phone: '' });
  const [errors, setErrors]   = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: '' })); };

  const validate = () => {
    const e = {};
    if (!form.name.trim() || form.name.trim().length < 2) e.name = 'Legalább 2 karakter';
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Érvényes e-mail szükséges';
    if (!form.password || form.password.length < 8) e.password = 'Minimum 8 karakter';
    else if (!/[A-Z]/.test(form.password)) e.password = 'Kell legalább egy nagybetű';
    else if (!/[0-9]/.test(form.password)) e.password = 'Kell legalább egy szám';
    if (form.password !== form.password2) e.password2 = 'A jelszavak nem egyeznek';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    try {
      await register({ name: form.name, email: form.email, password: form.password, phone: form.phone });
      setSuccess(true);
    } catch (err) { setErrors({ submit: err.message }); } finally { setLoading(false); }
  };

  if (success) return (
    <AuthPage title="Majdnem kész!" subtitle="Ellenőrizd az e-mail postaládád és aktiváld a fiókodat.">
      <div style={{ textAlign: 'center', paddingTop: 'var(--sp-4)' }}>
        <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--success-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto var(--sp-4)' }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', marginBottom: 'var(--sp-6)', lineHeight: 1.7 }}>
          Küldtünk egy megerősítő e-mailt. Kattints a linkre az aktiváláshoz.
        </p>
        <Link to="/bejelentkezes" className="btn btn-primary btn-full">Bejelentkezés</Link>
      </div>
    </AuthPage>
  );

  return (
    <AuthPage title="Regisztráció" subtitle="Hozz létre egy fiókot a Cruiser Shopban." wide>
      <form onSubmit={handleSubmit}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
          <div className="form-group">
            <label className="form-label">Teljes név *</label>
            <input className={`form-input${errors.name ? ' error' : ''}`} value={form.name} onChange={e => set('name', e.target.value)} placeholder="Kovács Péter" />
            {errors.name && <p className="form-error">{errors.name}</p>}
          </div>
          <div className="form-group">
            <label className="form-label">Telefonszám</label>
            <input className="form-input" type="tel" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+36 30 123 4567" />
          </div>
          <div className="form-group" style={{ gridColumn: '1/-1' }}>
            <label className="form-label">E-mail cím *</label>
            <input className={`form-input${errors.email ? ' error' : ''}`} type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="pelda@email.hu" />
            {errors.email && <p className="form-error">{errors.email}</p>}
          </div>
          <div className="form-group">
            <label className="form-label">Jelszó *</label>
            <div style={{ position: 'relative' }}>
              <input className={`form-input${errors.password ? ' error' : ''}`} type={showPwd ? 'text' : 'password'} value={form.password} onChange={e => set('password', e.target.value)} placeholder="Min. 8 kar." style={{ paddingRight: 48 }} />
              <button type="button" onClick={() => setShowPwd(v => !v)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', padding: 4 }}>
                {showPwd ? <EyeOff /> : <Eye />}
              </button>
            </div>
            {errors.password && <p className="form-error">{errors.password}</p>}
          </div>
          <div className="form-group">
            <label className="form-label">Jelszó megerősítése *</label>
            <input className={`form-input${errors.password2 ? ' error' : ''}`} type="password" value={form.password2} onChange={e => set('password2', e.target.value)} placeholder="••••••••" />
            {errors.password2 && <p className="form-error">{errors.password2}</p>}
          </div>
        </div>
        <p style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: 'var(--sp-3)', lineHeight: 1.6 }}>
          A regisztrációval elfogadod az{' '}
          <Link to="/aszf" style={{ color: 'var(--coral)' }}>Általános Szerződési Feltételeket</Link>{' '}és az{' '}
          <Link to="/adatvedelem" style={{ color: 'var(--coral)' }}>Adatvédelmi Tájékoztatót</Link>.
        </p>
        {errors.submit && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--error)', background: 'var(--error-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500, marginTop: 'var(--sp-3)' }}>{errors.submit}</p>}
        <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading} style={{ marginTop: 'var(--sp-5)' }}>
          {loading ? <span className="spinner" style={{ width: 20, height: 20, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : 'Regisztráció'}
        </button>
        <p style={{ textAlign: 'center', fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', marginTop: 'var(--sp-4)' }}>
          Már van fiókod?{' '}<Link to="/bejelentkezes" style={{ color: 'var(--coral)', fontWeight: 600 }}>Bejelentkezés</Link>
        </p>
      </form>
    </AuthPage>
  );
}

/* ─── FORGOT PASSWORD ───────────────────────────────────── */
export function ForgotPasswordPage() {
  const [email, setEmail]     = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent]       = useState(false);
  const [error, setError]     = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const r = await api('/api/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || 'Hiba történt');
      setSent(true);
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  };

  if (sent) return (
    <AuthPage title="E-mail elküldve" subtitle={`Jelszó-visszaállítási linket küldtünk: ${email}`}>
      <Link to="/bejelentkezes" className="btn btn-primary btn-full">Vissza a bejelentkezéshez</Link>
    </AuthPage>
  );

  return (
    <AuthPage title="Jelszó visszaállítás" subtitle="Add meg az e-mail címed és küldünk egy visszaállítási linket.">
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
        <div className="form-group">
          <label className="form-label">E-mail cím</label>
          <input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="pelda@email.hu" required autoComplete="email" />
        </div>
        {error && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--error)', background: 'var(--error-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500 }}>{error}</p>}
        <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 20, height: 20, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : 'Link küldése'}
        </button>
        <p style={{ textAlign: 'center', fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>
          <Link to="/bejelentkezes" style={{ color: 'var(--coral)', fontWeight: 600 }}>← Vissza a bejelentkezéshez</Link>
        </p>
      </form>
    </AuthPage>
  );
}

/* ─── RESET PASSWORD ────────────────────────────────────── */
export function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const navigate       = useNavigate();
  const token          = searchParams.get('token');
  const [password, setPassword]   = useState('');
  const [password2, setPassword2] = useState('');
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (password !== password2) { setError('A jelszavak nem egyeznek'); return; }
    if (password.length < 8)    { setError('Minimum 8 karakter szükséges'); return; }
    setLoading(true);
    try {
      const r = await api('/api/auth/reset-password', { method: 'POST', body: JSON.stringify({ token, password }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || 'Hiba történt');
      navigate('/bejelentkezes');
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  };

  return (
    <AuthPage title="Új jelszó" subtitle="Add meg az új jelszavadat.">
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
        <div className="form-group">
          <label className="form-label">Új jelszó</label>
          <input className="form-input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Min. 8 karakter" required />
        </div>
        <div className="form-group">
          <label className="form-label">Jelszó megerősítése</label>
          <input className="form-input" type="password" value={password2} onChange={e => setPassword2(e.target.value)} placeholder="••••••••" required />
        </div>
        {error && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--error)', background: 'var(--error-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500 }}>{error}</p>}
        <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 20, height: 20, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : 'Jelszó mentése'}
        </button>
      </form>
    </AuthPage>
  );
}

/* ─── VERIFY EMAIL ──────────────────────────────────────── */
export function VerifyEmailPage() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    if (!token) { setStatus('error'); return; }
    api(`/api/auth/verify-email?token=${token}`)
      .then(r => setStatus(r.ok ? 'success' : 'error'))
      .catch(() => setStatus('error'));
  }, [token]);

  if (status === 'loading') return <AuthPage title="Ellenőrzés..." subtitle="Kérjük várj..."><div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-8)' }}><span className="spinner" style={{ width: 36, height: 36, borderWidth: 3 }} /></div></AuthPage>;
  if (status === 'success') return (
    <AuthPage title="Megerősítve!" subtitle="Az e-mail cím sikeresen meg lett erősítve.">
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--success-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto var(--sp-5)' }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <Link to="/bejelentkezes" className="btn btn-primary btn-full">Bejelentkezés</Link>
      </div>
    </AuthPage>
  );
  return (
    <AuthPage title="Hiba" subtitle="Az ellenőrzési link érvénytelen vagy lejárt.">
      <Link to="/bejelentkezes" className="btn btn-outline btn-full">Vissza a bejelentkezéshez</Link>
    </AuthPage>
  );
}

/* ─── MY ORDERS ─────────────────────────────────────────── */
export function MyOrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/api/orders/my')
      .then(r => r.json())
      .then(d => { setOrders(Array.isArray(d) ? d : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const statusMap = {
    pending:    { label: 'Feldolgozás alatt', cls: 'badge-peach' },
    paid:       { label: 'Fizetve',           cls: 'badge-success' },
    processing: { label: 'Feldolgozás alatt', cls: 'badge-peach' },
    shipped:    { label: 'Kiszállítás alatt', cls: 'badge-coral' },
    delivered:  { label: 'Megérkezett',       cls: 'badge-success' },
    cancelled:  { label: 'Törölve',           cls: 'badge-error' },
    refunded:   { label: 'Visszafizetve',     cls: 'badge-gray' },
  };

  return (
    <main className="page">
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: 'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700 }}>Rendeléseim</h1>
        </div>
      </div>
      <div className="container" style={{ padding: 'var(--sp-8) var(--container-pad) var(--sp-16)', maxWidth: 860 }}>
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-16)' }}><span className="spinner" style={{ width: 36, height: 36, borderWidth: 3 }} /></div>
        ) : orders.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state__icon">📦</div>
            <h2 className="empty-state__title">Még nincs rendelésed</h2>
            <p style={{ marginBottom: 'var(--sp-6)' }}>Fedezd fel kerékpárkínálatunkat!</p>
            <Link to="/kerekparok" className="btn btn-primary">Böngészés</Link>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
            {orders.map(order => {
              const s = statusMap[order.status] || { label: order.status, cls: 'badge-gray' };
              return (
                <div key={order.uuid} style={{ background: 'var(--white)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'var(--sp-6)', boxShadow: 'var(--shadow-xs)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 'var(--sp-4)', flexWrap: 'wrap', gap: 'var(--sp-3)' }}>
                    <div>
                      <div style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--coral)', marginBottom: 4 }}>
                        #{order.uuid?.slice(0, 8).toUpperCase()}
                      </div>
                      <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>
                        {new Date(order.created_at).toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' })}
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
                      <span className={`badge ${s.cls}`}>{s.label}</span>
                      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--fs-xl)', color: 'var(--text)' }}>
                        {formatPrice(order.total_amount)}
                      </span>
                    </div>
                  </div>

                  {order.items?.length > 0 && (
                    <div style={{ borderTop: '1px solid var(--border)', paddingTop: 'var(--sp-4)', display: 'flex', flexDirection: 'column', gap: 'var(--sp-2)' }}>
                      {order.items.map((item, i) => (
                        <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-sm)' }}>
                          <span style={{ color: 'var(--text-muted)' }}>{item.quantity}× {item.product_name}</span>
                          <span style={{ fontWeight: 600 }}>{formatPrice(item.subtotal)}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {order.shipping_city && (
                    <div style={{ marginTop: 'var(--sp-3)', paddingTop: 'var(--sp-3)', borderTop: '1px dashed var(--border)', fontSize: 'var(--fs-xs)', color: 'var(--text-faint)', display: 'flex', gap: 6, alignItems: 'center' }}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                      {order.shipping_zip} {order.shipping_city}, {order.shipping_street}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </main>
  );
}

/* ─── ORDER SUCCESS ─────────────────────────────────────── */
export function OrderSuccessPage() {
  return (
    <main className="page" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '80vh' }}>
      <FadeIn direction="scale">
        <div style={{ maxWidth: 480, margin: '0 auto', textAlign: 'center', padding: 'var(--sp-8)' }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'var(--success-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto var(--sp-6)' }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-3xl)', fontWeight: 700, marginBottom: 'var(--sp-3)' }}>
            Rendelés sikeresen leadva!
          </h1>
          <p style={{ fontSize: 'var(--fs-md)', color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 'var(--sp-8)' }}>
            Köszönjük a rendelésed! Hamarosan e-mailben visszaigazolunk.
          </p>
          <div style={{ display: 'flex', gap: 'var(--sp-3)', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/rendeleiseim" className="btn btn-primary">Rendeléseim</Link>
            <Link to="/" className="btn btn-ghost">Főoldalra</Link>
          </div>
        </div>
      </FadeIn>
    </main>
  );
}
