import React, { useState } from 'react';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

const CONTACT_INFO = [
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
        <circle cx="12" cy="10" r="3"/>
      </svg>
    ),
    title: 'Cím',
    lines: ['6500 Baja', 'Czirfusz Ferenc u. 41'],
    link: 'https://maps.google.com/?q=Baja,+Czirfusz+Ferenc+u.+41',
    linkLabel: 'Megmutat a térképen',
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012.18 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.06 6.06l1.27-.65a2 2 0 012.11.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
      </svg>
    ),
    title: 'Telefonszám',
    lines: ['+36 70 210 7706', '+36 70 584 4414'],
    link: 'tel:+36702107706',
    linkLabel: 'Felhív',
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <circle cx="12" cy="12" r="10"/>
        <polyline points="12 6 12 12 16 14"/>
      </svg>
    ),
    title: 'Nyitvatartás',
    lines: ['Hétfő–Péntek: 8:00–12:00, 13:00–17:00', 'Szombat: 8:00–12:00'],
    link: null,
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/>
      </svg>
    ),
    title: 'Facebook',
    lines: ['Kerékpárszakűzlet és Szerviz Baja'],
    link: 'https://www.facebook.com/p/Ker%C3%A9kp%C3%A1rszak%C3%BCzlet-%C3%A9s-Szerviz-Baja-100064352425586/',
    linkLabel: 'Facebook oldal megnyitása',
  },
];

function InputField({ label, error, ...props }) {
  return (
    <div className="form-group">
      <label className="form-label">{label}</label>
      <input className={`form-input${error ? ' error' : ''}`} {...props} />
      {error && <span className="form-error">{error}</span>}
    </div>
  );
}

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | success | error

  const set = (field) => (e) => setForm(f => ({ ...f, [field]: e.target.value }));

  const validate = () => {
    const e = {};
    if (!form.name.trim())    e.name    = 'A név megadása kötelező';
    if (!form.email.trim())   e.email   = 'Az e-mail megadása kötelező';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Érvénytelen e-mail cím';
    if (!form.message.trim()) e.message = 'Az üzenet megadása kötelező';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setStatus('sending');

    try {
      const r = await api('/api/contact', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      if (r.ok) {
        setStatus('success');
        setForm({ name: '', email: '', phone: '', subject: '', message: '' });
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  return (
    <main className="page">

      {/* ── HERO ─────────────────────────────────────────── */}
      <section style={{
        background: 'linear-gradient(135deg, var(--gray-900) 0%, #2C2C2E 100%)',
        padding: 'var(--sp-20) 0',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -100, right: -100,
          width: 460, height: 460, borderRadius: '50%',
          background: 'rgba(200,92,72,0.08)', pointerEvents: 'none',
        }} />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <FadeIn direction="up">
            <div style={{ maxWidth: 600 }}>
              <span className="badge badge-coral" style={{ marginBottom: 'var(--sp-4)', display: 'inline-flex' }}>
                Elérhetőségek
              </span>
              <h1 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(var(--fs-4xl), 5vw, var(--fs-6xl))',
                color: 'var(--white)', lineHeight: 1.1,
                marginBottom: 'var(--sp-6)',
              }}>
                Vedd fel velünk<br />
                <span style={{ color: 'var(--coral)' }}>a kapcsolatot</span>
              </h1>
              <p style={{
                fontSize: 'var(--fs-lg)',
                color: 'rgba(255,255,255,0.65)',
                lineHeight: 1.7, maxWidth: 480,
              }}>
                Kérdésed van? Időpontot foglalnál szervizre? Esetleg tanácsot kérnél kerékpárvásárláshoz? Keress minket bátran!
              </p>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── MAIN CONTENT ─────────────────────────────────── */}
      <section className="section">
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: 'var(--sp-12)',
            alignItems: 'start',
          }}>

            {/* ── LEFT: Contact info ── */}
            <FadeIn direction="left">
              <div>
                <h2 style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'var(--fs-3xl)',
                  marginBottom: 'var(--sp-3)',
                }}>
                  Cruiser Shop Baja
                </h2>
                <p style={{
                  color: 'var(--text-muted)',
                  lineHeight: 1.7,
                  marginBottom: 'var(--sp-8)',
                  fontSize: 'var(--fs-md)',
                }}>
                  Kerékpár szaküzlet és szerviz Baján. Hétfőtől péntekig, és szombaton is várjuk ügyfeleinket.
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-5)' }}>
                  {CONTACT_INFO.map(info => (
                    <div key={info.title} style={{
                      display: 'flex', gap: 'var(--sp-4)', alignItems: 'flex-start',
                      padding: 'var(--sp-5)',
                      background: 'var(--white)',
                      border: '1px solid var(--border)',
                      borderRadius: 'var(--r-xl)',
                      boxShadow: 'var(--shadow-xs)',
                    }}>
                      <div style={{
                        width: 48, height: 48, flexShrink: 0,
                        borderRadius: 'var(--r-lg)',
                        background: 'var(--coral-light)',
                        color: 'var(--coral)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        {info.icon}
                      </div>
                      <div>
                        <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>
                          {info.title}
                        </div>
                        {info.lines.map(line => (
                          <div key={line} style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-2)', lineHeight: 1.6, fontWeight: 500 }}>
                            {line}
                          </div>
                        ))}
                        {info.link && (
                          <a
                            href={info.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{
                              display: 'inline-flex', alignItems: 'center', gap: 4,
                              marginTop: 6,
                              fontSize: 'var(--fs-xs)',
                              color: 'var(--coral)',
                              fontWeight: 600,
                              textDecoration: 'none',
                            }}
                          >
                            {info.linkLabel}
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                              <path d="M7 17L17 7M7 7h10v10"/>
                            </svg>
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </FadeIn>

            {/* ── RIGHT: Contact form ── */}
            <FadeIn direction="right" delay={0.1}>
              <div style={{
                background: 'var(--white)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--r-2xl)',
                padding: 'clamp(var(--sp-6), 4vw, var(--sp-10))',
                boxShadow: 'var(--shadow-md)',
              }}>
                <h3 style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'var(--fs-2xl)',
                  marginBottom: 'var(--sp-2)',
                }}>
                  Írj nekünk
                </h3>
                <p style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-sm)', marginBottom: 'var(--sp-6)' }}>
                  Általában 24 órán belül válaszolunk.
                </p>

                {status === 'success' ? (
                  <div style={{
                    textAlign: 'center',
                    padding: 'var(--sp-12) var(--sp-6)',
                  }}>
                    <div style={{
                      width: 64, height: 64, borderRadius: 'var(--r-full)',
                      background: 'var(--success-bg)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      margin: '0 auto var(--sp-4)',
                      color: '#1A7A38',
                    }}>
                      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    </div>
                    <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-2xl)', marginBottom: 'var(--sp-3)' }}>
                      Üzenet elküldve!
                    </h4>
                    <p style={{ color: 'var(--text-muted)', lineHeight: 1.6 }}>
                      Köszönjük megkeresésedet! Hamarosan felvesszük veled a kapcsolatot.
                    </p>
                    <button
                      className="btn btn-outline btn-sm"
                      style={{ marginTop: 'var(--sp-6)' }}
                      onClick={() => setStatus('idle')}
                    >
                      Új üzenet küldése
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
                      <InputField
                        label="Neved *"
                        type="text"
                        placeholder="Kovács János"
                        value={form.name}
                        onChange={set('name')}
                        error={errors.name}
                      />
                      <InputField
                        label="E-mail cím *"
                        type="email"
                        placeholder="pelda@email.hu"
                        value={form.email}
                        onChange={set('email')}
                        error={errors.email}
                      />
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
                      <InputField
                        label="Telefonszám"
                        type="tel"
                        placeholder="+36 70 123 4567"
                        value={form.phone}
                        onChange={set('phone')}
                      />
                      <div className="form-group">
                        <label className="form-label">Tárgy</label>
                        <select
                          className="form-input form-select"
                          value={form.subject}
                          onChange={set('subject')}
                        >
                          <option value="">Válassz témát...</option>
                          <option value="szerviz">Szerviz időpont</option>
                          <option value="vasarlas">Kerékpárvásárlás</option>
                          <option value="kerekpar">Kerékpár típus kérdés</option>
                          <option value="ebike">E-bike kérdés</option>
                          <option value="egyeb">Egyéb</option>
                        </select>
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Üzenet *</label>
                      <textarea
                        className={`form-input form-textarea${errors.message ? ' error' : ''}`}
                        placeholder="Írd le kérdésedet vagy kérésedet..."
                        rows={5}
                        value={form.message}
                        onChange={set('message')}
                      />
                      {errors.message && <span className="form-error">{errors.message}</span>}
                    </div>

                    {status === 'error' && (
                      <div style={{
                        padding: 'var(--sp-4)',
                        background: 'var(--error-bg)',
                        borderRadius: 'var(--r-md)',
                        color: 'var(--error)',
                        fontSize: 'var(--fs-sm)',
                      }}>
                        Hiba történt az üzenet küldésekor. Kérjük próbálj újra, vagy hívj minket közvetlenül!
                      </div>
                    )}

                    <button
                      type="submit"
                      className="btn btn-primary btn-lg"
                      disabled={status === 'sending'}
                      style={{ marginTop: 'var(--sp-2)' }}
                    >
                      {status === 'sending' ? (
                        <>
                          <span className="spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />
                          Küldés...
                        </>
                      ) : (
                        <>
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                          </svg>
                          Üzenet küldése
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </FadeIn>

          </div>
        </div>
      </section>

      {/* ── MAP ──────────────────────────────────────────── */}
      <section className="section-sm" style={{ paddingTop: 0 }}>
        <div className="container">
          <FadeIn direction="up">
            <div style={{
              borderRadius: 'var(--r-2xl)',
              overflow: 'hidden',
              boxShadow: 'var(--shadow-lg)',
              border: '1px solid var(--border)',
              height: 400,
            }}>
              <iframe
                title="Cruiser Shop Baja térkép"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2748.0!2d18.9553!3d46.1842!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDbCsDExJzAzLjEiTiAxOMKwNTcnMTkuMSJF!5e0!3m2!1shu!2shu!4v1234567890!5m2!1shu!2shu&q=Baja,+Czirfusz+Ferenc+u.+41"
                width="100%"
                height="100%"
                style={{ border: 0, display: 'block' }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <div style={{ textAlign: 'center', marginTop: 'var(--sp-4)' }}>
              <a
                href="https://maps.google.com/?q=Baja,+Czirfusz+Ferenc+u.+41"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-outline btn-sm"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>
                </svg>
                Megnyitás Google Maps-ben
              </a>
            </div>
          </FadeIn>
        </div>
      </section>

    </main>
  );
}