import React, { useState, useContext, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { WishlistContext } from '../context/WishListContext';
import { CartContext } from '../context/CartContext';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

const Eye    = () => <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
const EyeOff = () => <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>;

const HeartIcon = ({ filled }) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill={filled ? 'var(--coral)' : 'none'} stroke="var(--coral)" strokeWidth="2">
    <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
  </svg>
);

const TABS = [
  { id: 'adatok',      label: 'Adataim',        icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> },
  { id: 'jelszo',      label: 'Jelszó',          icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg> },
  { id: 'rendelesek',  label: 'Rendeléseim',     icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> },
  { id: 'wishlist',    label: 'Kívánságlista',   icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg> },
];

/* ── ProfileDataTab ─────────────────────────────────────── */
function ProfileDataTab({ user, onUpdate }) {
  const [form, setForm]     = useState({ name: user.name || '', phone: user.phone || '' });
  const [status, setStatus] = useState('idle');
  const [error, setError]   = useState('');
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) { setError('A név megadása kötelező.'); return; }
    setError(''); setStatus('saving');
    try {
      const r = await api('/api/auth/me', { method: 'PATCH', body: JSON.stringify({ name: form.name, phone: form.phone }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || 'Hiba');
      onUpdate({ ...user, name: form.name, phone: form.phone });
      setStatus('success');
      setTimeout(() => setStatus('idle'), 3000);
    } catch (err) { setError(err.message); setStatus('error'); }
  };

  const initials = form.name
    ? form.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
    : user.email[0].toUpperCase();

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-6)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-5)', paddingBottom: 'var(--sp-6)', borderBottom: '1px solid var(--border)', flexWrap: 'wrap' }}>
        <div style={{ width: 68, height: 68, borderRadius: '50%', background: 'var(--coral)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--fs-2xl)', flexShrink: 0 }}>
          {initials}
        </div>
        <div>
          <div style={{ fontWeight: 700, fontSize: 'var(--fs-lg)', lineHeight: 1.2 }}>{form.name || 'Felhasználó'}</div>
          <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', marginTop: 3 }}>{user.email}</div>
          {user.role === 'admin' && <span className="badge badge-coral" style={{ marginTop: 6 }}>Admin</span>}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
        <div className="form-group">
          <label className="form-label">Teljes név</label>
          <input className="form-input" type="text" value={form.name} onChange={set('name')} placeholder="Kovács Péter" />
        </div>
        <div className="form-group">
          <label className="form-label">E-mail cím</label>
          <input className="form-input" type="email" value={user.email} disabled
            style={{ background: 'var(--gray-50)', color: 'var(--text-muted)', cursor: 'not-allowed' }} />
          <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-faint)', marginTop: 4 }}>Az e-mail cím nem módosítható.</span>
        </div>
        <div className="form-group">
          <label className="form-label">Telefonszám <span style={{ color: 'var(--text-faint)', fontWeight: 400 }}>(opcionális)</span></label>
          <input className="form-input" type="tel" value={form.phone} onChange={set('phone')} placeholder="+36 30 123 4567" />
        </div>
      </div>

      {error   && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--error)', background: 'var(--error-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500 }}>{error}</p>}
      {status === 'success' && <p style={{ fontSize: 'var(--fs-sm)', color: '#1A7A38', background: 'var(--success-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500 }}>Adatok sikeresen mentve!</p>}

      <button type="submit" className="btn btn-primary" style={{ alignSelf: 'flex-start' }} disabled={status === 'saving'}>
        {status === 'saving' ? <span className="spinner" style={{ width: 18, height: 18, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : 'Adatok mentése'}
      </button>
    </form>
  );
}

/* ── PasswordTab ────────────────────────────────────────── */
function PasswordTab() {
  const [form, setForm]       = useState({ current: '', newPwd: '', confirm: '' });
  const [status, setStatus]   = useState('idle');
  const [error, setError]     = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.newPwd.length < 8)       { setError('Az új jelszó legalább 8 karakter legyen.'); return; }
    if (!/[A-Z]/.test(form.newPwd))   { setError('Az új jelszónak tartalmazzon nagybetűt.'); return; }
    if (!/[0-9]/.test(form.newPwd))   { setError('Az új jelszónak tartalmazzon számot.'); return; }
    if (form.newPwd !== form.confirm) { setError('A jelszavak nem egyeznek.'); return; }
    setError(''); setStatus('saving');
    try {
      const r = await api('/api/auth/change-password', { method: 'POST', body: JSON.stringify({ currentPassword: form.current, newPassword: form.newPwd }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || 'Hiba');
      setStatus('success'); setForm({ current: '', newPwd: '', confirm: '' });
      setTimeout(() => setStatus('idle'), 3000);
    } catch (err) { setError(err.message); setStatus('error'); }
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
      <div className="form-group">
        <label className="form-label">Jelenlegi jelszó</label>
        <div style={{ position: 'relative' }}>
          <input className="form-input" type={showPwd ? 'text' : 'password'} value={form.current} onChange={set('current')} required style={{ paddingRight: 48 }} />
          <button type="button" onClick={() => setShowPwd(v => !v)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', padding: 4 }}>
            {showPwd ? <EyeOff /> : <Eye />}
          </button>
        </div>
      </div>
      <div className="form-group">
        <label className="form-label">Új jelszó</label>
        <input className="form-input" type="password" value={form.newPwd} onChange={set('newPwd')} placeholder="Min. 8 kar., nagybetű, szám" required />
      </div>
      <div className="form-group">
        <label className="form-label">Új jelszó megerősítése</label>
        <input className="form-input" type="password" value={form.confirm} onChange={set('confirm')} placeholder="••••••••" required />
      </div>
      {error && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--error)', background: 'var(--error-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500 }}>{error}</p>}
      {status === 'success' && <p style={{ fontSize: 'var(--fs-sm)', color: '#1A7A38', background: 'var(--success-bg)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontWeight: 500 }}>Jelszó sikeresen megváltoztatva!</p>}
      <button type="submit" className="btn btn-primary" style={{ alignSelf: 'flex-start' }} disabled={status === 'saving'}>
        {status === 'saving' ? <span className="spinner" style={{ width: 18, height: 18, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : 'Jelszó módosítása'}
      </button>
    </form>
  );
}

/* ── OrdersTab ──────────────────────────────────────────── */
function OrdersTab() {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    api('/api/orders/my').then(r => r.json())
      .then(d => { setOrders(Array.isArray(d) ? d : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const fmtPrice = n => new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(Number(n) || 0);
  const statusMap = {
    pending:    { label: 'Feldolgozás', cls: 'badge-peach',   icon: '⏳' },
    paid:       { label: 'Fizetve',     cls: 'badge-success', icon: '✅' },
    processing: { label: 'Feldolgozás', cls: 'badge-peach',   icon: '⚙️' },
    shipped:    { label: 'Kiszállítás', cls: 'badge-coral',   icon: '🚚' },
    delivered:  { label: 'Megérkezett',cls: 'badge-success',  icon: '📦' },
    cancelled:  { label: 'Törölve',    cls: 'badge-error',    icon: '❌' },
    refunded:   { label: 'Visszafiz.', cls: 'badge-gray',     icon: '↩️' },
  };

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-10)' }}>
      <span className="spinner" style={{ width: 32, height: 32 }} />
    </div>
  );
  if (!orders.length) return (
    <div style={{ textAlign: 'center', padding: 'var(--sp-10)' }}>
      <div style={{ fontSize: 48, marginBottom: 'var(--sp-4)' }}>📦</div>
      <p style={{ color: 'var(--text-muted)', marginBottom: 'var(--sp-5)' }}>Még nincsenek rendeléseid.</p>
      <Link to="/kerekparok" className="btn btn-primary">Böngészés</Link>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
      {orders.map(order => {
        const s = statusMap[order.status] || { label: order.status, cls: 'badge-gray', icon: '📋' };
        const isOpen = expanded === order.uuid;
        return (
          <div key={order.uuid} style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', overflow: 'hidden', transition: 'box-shadow var(--t-fast)' }}
            onMouseEnter={e => e.currentTarget.style.boxShadow = 'var(--shadow-sm)'}
            onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}>
            {/* Header */}
            <button
              onClick={() => setExpanded(isOpen ? null : order.uuid)}
              style={{ width: '100%', padding: 'var(--sp-5)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 'var(--sp-3)', background: 'var(--white)', cursor: 'pointer', border: 'none', textAlign: 'left' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', flexWrap: 'wrap' }}>
                <span style={{ fontSize: 18 }}>{s.icon}</span>
                <div>
                  <div style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--coral)', fontSize: 'var(--fs-sm)' }}>
                    #{order.uuid?.slice(0, 8).toUpperCase()}
                  </div>
                  <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: 2 }}>
                    {new Date(order.created_at).toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' })}
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', flexWrap: 'wrap' }}>
                <span className={`badge ${s.cls}`}>{s.label}</span>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--text)', fontSize: 'var(--fs-lg)', whiteSpace: 'nowrap' }}>
                  {fmtPrice(order.total_amount)}
                </span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth="2"
                  style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform var(--t-fast)', flexShrink: 0 }}>
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </div>
            </button>

            {/* Expanded items with images */}
            {isOpen && order.items?.length > 0 && (
              <div style={{ borderTop: '1px solid var(--border)', padding: 'var(--sp-5)', background: 'var(--gray-50)' }}>
                <p style={{ fontSize: 'var(--fs-xs)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-muted)', marginBottom: 'var(--sp-4)' }}>
                  Rendelt termékek
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
                  {order.items.map((item, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-4)', padding: 'var(--sp-3)', background: 'var(--white)', borderRadius: 'var(--r-md)', border: '1px solid var(--border)' }}>
                      {/* Termékkép */}
                      <div style={{ width: 60, height: 60, borderRadius: 'var(--r-sm)', overflow: 'hidden', flexShrink: 0, background: 'var(--gray-50)' }}>
                        {item.image_url ? (
                          <img src={item.image_url} alt={item.product_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        ) : (
                          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--coral-light)' }}>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" opacity="0.4">
                              <circle cx="6" cy="17" r="4" stroke="var(--coral)" strokeWidth="2"/>
                              <circle cx="18" cy="17" r="4" stroke="var(--coral)" strokeWidth="2"/>
                              <path d="M6 17L10 8l4 4 3-4 4 9" stroke="var(--coral)" strokeWidth="2" fill="none"/>
                            </svg>
                          </div>
                        )}
                      </div>
                      {/* Adatok */}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        {item.slug ? (
                          <Link to={`/kerekparok/${item.slug}`} style={{ fontWeight: 600, fontSize: 'var(--fs-sm)', color: 'var(--text)', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {item.product_name}
                          </Link>
                        ) : (
                          <div style={{ fontWeight: 600, fontSize: 'var(--fs-sm)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.product_name}</div>
                        )}
                        <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: 2 }}>
                          {item.quantity} db × {fmtPrice(item.price)}
                        </div>
                      </div>
                      <div style={{ fontWeight: 700, fontSize: 'var(--fs-sm)', whiteSpace: 'nowrap', color: 'var(--coral)', flexShrink: 0 }}>
                        {fmtPrice(item.subtotal)}
                      </div>
                    </div>
                  ))}
                </div>
                {/* Szállítási adatok */}
                <div style={{ marginTop: 'var(--sp-4)', paddingTop: 'var(--sp-4)', borderTop: '1px solid var(--border)', fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', lineHeight: 1.8 }}>
                  <strong style={{ color: 'var(--text)' }}>Szállítási cím:</strong><br/>
                  {order.shipping_name} — {order.shipping_zip} {order.shipping_city}, {order.shipping_street}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ── WishlistTab ────────────────────────────────────────── */
function WishlistTab() {
  const { toggle }              = useContext(WishlistContext);
  const { addToCart }           = useContext(CartContext);
  const [items, setItems]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [addedId, setAddedId]   = useState(null);

  useEffect(() => {
    api('/api/wishlist').then(r => r.json())
      .then(d => { setItems(Array.isArray(d) ? d : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const handleRemove = (item) => {
    toggle({ id: item.product_id });
    setItems(prev => prev.filter(i => i.product_id !== item.product_id));
  };

  const handleAddToCart = (item) => {
    addToCart({ id: item.product_id, name: item.name, price: item.price, image_url: item.image_url, slug: item.slug, stock: item.stock });
    setAddedId(item.product_id);
    setTimeout(() => setAddedId(null), 1600);
  };

  const fmtPrice = n => new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(Number(n) || 0);

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-10)' }}>
      <span className="spinner" style={{ width: 32, height: 32 }} />
    </div>
  );

  if (!items.length) return (
    <div style={{ textAlign: 'center', padding: 'var(--sp-10)' }}>
      <div style={{ fontSize: 52, marginBottom: 'var(--sp-4)' }}>🤍</div>
      <p style={{ color: 'var(--text-muted)', fontWeight: 500, marginBottom: 8 }}>A kívánságlistád üres.</p>
      <p style={{ color: 'var(--text-faint)', fontSize: 'var(--fs-sm)', marginBottom: 'var(--sp-5)' }}>
        Kattints a szív ikonra bármely terméknél, hogy ide kerüljön.
      </p>
      <Link to="/kerekparok" className="btn btn-primary">Böngészés</Link>
    </div>
  );

  return (
    <div>
      <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', marginBottom: 'var(--sp-5)' }}>
        <strong style={{ color: 'var(--text)' }}>{items.length} termék</strong> a kívánságlistádon
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
        {items.map(item => {
          const isAdded    = addedId === item.product_id;
          const outOfStock = item.stock === 0;
          return (
            <div key={item.product_id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-4)', padding: 'var(--sp-4)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', background: 'var(--white)', transition: 'box-shadow var(--t-fast)' }}
              onMouseEnter={e => e.currentTarget.style.boxShadow = 'var(--shadow-sm)'}
              onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}>
              {/* Kép */}
              <Link to={`/kerekparok/${item.slug}`} style={{ flexShrink: 0 }}>
                <div style={{ width: 80, height: 80, borderRadius: 'var(--r-md)', overflow: 'hidden', background: 'var(--gray-50)' }}>
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--coral-light)' }}>
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" opacity="0.4">
                        <circle cx="6" cy="17" r="4" stroke="var(--coral)" strokeWidth="2"/>
                        <circle cx="18" cy="17" r="4" stroke="var(--coral)" strokeWidth="2"/>
                        <path d="M6 17L10 8l4 4 3-4 4 9" stroke="var(--coral)" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                  )}
                </div>
              </Link>
              {/* Adatok */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <Link to={`/kerekparok/${item.slug}`} style={{ fontWeight: 600, fontSize: 'var(--fs-sm)', color: 'var(--text)', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {item.name}
                </Link>
                {item.category_name && (
                  <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: 2 }}>{item.category_name}</div>
                )}
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--fs-md)', color: 'var(--coral)', marginTop: 4 }}>
                  {fmtPrice(item.price)}
                </div>
                {outOfStock && <span className="badge badge-error" style={{ marginTop: 4 }}>Elfogyott</span>}
              </div>
              {/* Akciók */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-2)', flexShrink: 0 }}>
                {!outOfStock && (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => handleAddToCart(item)}
                    style={{ whiteSpace: 'nowrap' }}
                  >
                    {isAdded ? (
                      <>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                        Kosárban
                      </>
                    ) : (
                      <>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        Kosárba
                      </>
                    )}
                  </button>
                )}
                <button
                  className="btn btn-sm"
                  style={{ background: 'var(--error-bg)', color: 'var(--error)' }}
                  onClick={() => handleRemove(item)}
                  title="Eltávolítás"
                >
                  <HeartIcon filled />
                  Eltávolítás
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── ProfilePage ────────────────────────────────────────── */
export default function ProfilePage() {
  const { user, setUser }         = useContext(AuthContext);
  const [tab, setTab]             = useState('adatok');
  const [profile, setProfile]     = useState(user);

  const handleUpdate = (updated) => {
    setProfile(updated);
    if (setUser) setUser(updated);
  };

  return (
    <main className="page" style={{ background: 'var(--bg)' }}>
      {/* Page header */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: 'var(--sp-8) 0 var(--sp-6)' }}>
        <div className="container">
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,4vw,2.2rem)', fontWeight: 700, letterSpacing: '-0.02em' }}>
            Fiókom
          </h1>
        </div>
      </div>

      <div className="container" style={{ padding: 'var(--sp-10) var(--container-pad) var(--sp-16)' }}>
        <FadeIn>
          <div style={{ maxWidth: 860, margin: '0 auto' }}>

            {/* Mobile tabs */}
            <div className="profile-tabs-mobile" style={{ display: 'none', gap: 'var(--sp-2)', marginBottom: 'var(--sp-5)', overflowX: 'auto', paddingBottom: 4 }}>
              {TABS.map(t => (
                <button key={t.id} onClick={() => setTab(t.id)} style={{
                  display: 'flex', alignItems: 'center', gap: 'var(--sp-2)',
                  padding: '8px 16px', borderRadius: 'var(--r-full)',
                  fontFamily: 'var(--font-body)', fontSize: 'var(--fs-sm)', fontWeight: 600,
                  color: tab === t.id ? 'var(--coral)' : 'var(--text-muted)',
                  background: tab === t.id ? 'var(--coral-light)' : 'var(--white)',
                  border: `1.5px solid ${tab === t.id ? 'var(--coral)' : 'var(--border)'}`,
                  cursor: 'pointer', whiteSpace: 'nowrap', transition: 'all var(--t-fast)',
                }}>
                  {t.icon}{t.label}
                </button>
              ))}
            </div>

            {/* Desktop: sidebar + content */}
            <div className="profile-desktop-grid" style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 'var(--sp-6)', alignItems: 'start' }}>
              {/* Sidebar */}
              <div style={{ background: 'var(--white)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'var(--sp-2)', position: 'sticky', top: 'calc(var(--nav-height) + var(--sp-4))' }}>
                {TABS.map(t => (
                  <button key={t.id} onClick={() => setTab(t.id)} style={{
                    display: 'flex', alignItems: 'center', gap: 'var(--sp-3)',
                    width: '100%', padding: 'var(--sp-3) var(--sp-4)',
                    borderRadius: 'var(--r-md)', fontFamily: 'var(--font-body)',
                    fontSize: 'var(--fs-sm)', fontWeight: tab === t.id ? 600 : 500,
                    color: tab === t.id ? 'var(--coral)' : 'var(--text-muted)',
                    background: tab === t.id ? 'var(--coral-light)' : 'transparent',
                    transition: 'all var(--t-fast)', cursor: 'pointer', border: 'none', textAlign: 'left',
                  }}>
                    <span style={{ color: tab === t.id ? 'var(--coral)' : 'var(--gray-400)' }}>{t.icon}</span>
                    {t.label}
                    {t.id === 'wishlist' && (
                      <span style={{ marginLeft: 'auto', fontSize: 'var(--fs-xs)', color: 'var(--coral)', opacity: 0.7 }}>❤</span>
                    )}
                  </button>
                ))}
              </div>

              {/* Content */}
              <div style={{ background: 'var(--white)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'var(--sp-7)' }}>
                {tab === 'adatok'     && <ProfileDataTab user={profile} onUpdate={handleUpdate} />}
                {tab === 'jelszo'     && <PasswordTab />}
                {tab === 'rendelesek' && <OrdersTab />}
                {tab === 'wishlist'   && <WishlistTab />}
              </div>
            </div>
          </div>
        </FadeIn>
      </div>

      <style>{`
        .profile-tabs-mobile { display: none !important; }
        @media (max-width: 680px) {
          .profile-tabs-mobile { display: flex !important; }
          .profile-desktop-grid { grid-template-columns: 1fr !important; }
          .profile-desktop-grid > div:first-child { display: none; }
        }
      `}</style>
    </main>
  );
}