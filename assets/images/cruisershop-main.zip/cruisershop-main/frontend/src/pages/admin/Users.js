import React, { useState, useEffect, useContext } from 'react';
import { AdminLayout } from './Dashboard';
import { AuthContext } from '../../context/AuthContext';
import api from '../../utils/api';

export default function AdminUsers() {
  const { user: currentUser } = useContext(AuthContext);
  const [users,   setUsers]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');
  const [error,   setError]   = useState('');
  const [banning, setBanning] = useState(null);

  const load = () => {
    setLoading(true);
    api('/api/admin/users')
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(data => { setUsers(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => { setError('Nem sikerült betölteni a felhasználókat.'); setLoading(false); });
  };

  useEffect(() => { load(); }, []);

  const handleBan = async (uuid, currentBanned) => {
    const action = currentBanned ? 'felold' : 'tilt le';
    if (!window.confirm(`Biztosan ${action}od ezt a felhasználót?`)) return;
    setBanning(uuid);
    try {
      const r = await api(`/api/admin/users/${uuid}/ban`, {
        method: 'PATCH',
        body: JSON.stringify({ ban: !currentBanned }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || 'Hiba');
      setUsers(prev => prev.map(u => u.uuid === uuid ? { ...u, is_banned: !currentBanned ? 1 : 0 } : u));
    } catch (err) {
      alert(err.message);
    } finally {
      setBanning(null);
    }
  };

  const filtered = users.filter(u =>
    !search ||
    u.name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout title="Felhasználók">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 'var(--sp-5)', flexWrap: 'wrap', gap: 'var(--sp-3)' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-sm)' }}>
          Összesen: <strong style={{ color: 'var(--text)' }}>{users.length} felhasználó</strong>
        </p>
        <div style={{ position: 'relative' }}>
          <svg style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}
            width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            className="form-input"
            style={{ paddingLeft: 36, width: 260, height: 38 }}
            placeholder="Keresés neve, e-mail..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: 'var(--sp-12)', display: 'flex', justifyContent: 'center' }}>
            <span className="spinner" style={{ width: 28, height: 28, borderWidth: 2.5 }} />
          </div>
        ) : error ? (
          <div style={{ padding: 'var(--sp-8)', textAlign: 'center', color: 'var(--error)', fontSize: 'var(--fs-sm)' }}>{error}</div>
        ) : filtered.length === 0 ? (
          <p style={{ padding: 'var(--sp-8)', textAlign: 'center', color: 'var(--text-muted)', fontSize: 'var(--fs-sm)' }}>
            {search ? 'Nincs találat.' : 'Még nincsenek felhasználók.'}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Felhasználó</th>
                  <th>E-mail</th>
                  <th>Szerepkör</th>
                  <th>Regisztrált</th>
                  <th>Igazolt</th>
                  <th>Státusz</th>
                  <th>Tiltás</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(u => {
                  const isAdmin   = u.role === 'admin';
                  const isSelf    = u.uuid === currentUser?.id;
                  const isBanned  = !!u.is_banned;
                  const initials  = u.name
                    ? u.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
                    : u.email[0].toUpperCase();

                  return (
                    <tr key={u.uuid}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)' }}>
                          <div style={{
                            width: 36, height: 36, borderRadius: '50%',
                            background: isAdmin ? 'var(--coral)' : 'var(--gray-200)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: 'var(--fs-xs)', fontWeight: 700,
                            color: isAdmin ? 'white' : 'var(--text-muted)',
                            flexShrink: 0,
                          }}>
                            {initials}
                          </div>
                          <div>
                            <div style={{ fontWeight: 600, fontSize: 'var(--fs-sm)' }}>{u.name}</div>
                            {isSelf && <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--coral)' }}>Te</div>}
                          </div>
                        </div>
                      </td>
                      <td style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>{u.email}</td>
                      <td>
                        <span className={`badge ${isAdmin ? 'badge-coral' : 'badge-gray'}`}>
                          {isAdmin ? 'Admin' : 'Vásárló'}
                        </span>
                      </td>
                      <td style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                        {new Date(u.created_at).toLocaleDateString('hu-HU')}
                      </td>
                      <td>
                        {u.is_verified
                          ? <span className="badge badge-success">Igen</span>
                          : <span className="badge badge-error">Nem</span>}
                      </td>
                      <td>
                        {isBanned
                          ? <span className="badge badge-error">Tiltott</span>
                          : <span className="badge badge-success">Aktív</span>}
                      </td>
                      <td>
                        {isAdmin || isSelf ? (
                          <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-faint)' }}>—</span>
                        ) : (
                          <button
                            className="btn btn-sm"
                            style={{
                              background: isBanned ? 'var(--success-bg)' : 'var(--error-bg)',
                              color: isBanned ? '#1A7A38' : 'var(--error)',
                            }}
                            onClick={() => handleBan(u.uuid, isBanned)}
                            disabled={banning === u.uuid}
                          >
                            {banning === u.uuid
                              ? <span className="spinner" style={{ width: 14, height: 14, borderWidth: 2 }} />
                              : isBanned ? 'Feloldás' : 'Tiltás'}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}