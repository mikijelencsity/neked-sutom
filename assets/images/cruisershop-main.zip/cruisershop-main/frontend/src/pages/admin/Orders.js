import React, { useState, useEffect, useCallback } from 'react';
import { AdminLayout } from './Dashboard';
import api from '../../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(Number(n) || 0);
}

const STATUS_OPTIONS = [
  { value: '',           label: 'Összes' },
  { value: 'pending',    label: 'Függőben' },
  { value: 'paid',       label: 'Fizetve' },
  { value: 'processing', label: 'Feldolgozás' },
  { value: 'shipped',    label: 'Kiszállítva' },
  { value: 'delivered',  label: 'Megérkezett' },
  { value: 'cancelled',  label: 'Törölve' },
  { value: 'refunded',   label: 'Visszafizetve' },
];

const STATUS_MAP = {
  pending:    { label: 'Függőben',       bg: 'var(--peach-light)',  color: 'var(--peach-hover)' },
  paid:       { label: 'Fizetve',        bg: 'var(--success-bg)',   color: '#1A7A38' },
  processing: { label: 'Feldolgozás',    bg: '#EEF2FF',             color: '#4338CA' },
  shipped:    { label: 'Kiszállítva',    bg: 'var(--coral-light)',  color: 'var(--coral)' },
  delivered:  { label: 'Megérkezett',   bg: 'var(--success-bg)',   color: '#1A7A38' },
  cancelled:  { label: 'Törölve',       bg: 'var(--error-bg)',     color: 'var(--error)' },
  refunded:   { label: 'Visszafizetve', bg: 'var(--gray-100)',     color: 'var(--gray-600)' },
};

function StatusBadge({ status }) {
  const s = STATUS_MAP[status] || { label: status, bg: 'var(--gray-100)', color: 'var(--text-muted)' };
  return (
    <span style={{ display: 'inline-block', padding: '3px 10px', borderRadius: 'var(--r-full)', fontSize: 'var(--fs-xs)', fontWeight: 600, background: s.bg, color: s.color, whiteSpace: 'nowrap' }}>
      {s.label}
    </span>
  );
}

export default function AdminOrders() {
  const [orders,      setOrders]      = useState([]);
  const [total,       setTotal]       = useState(0);
  const [loading,     setLoading]     = useState(true);
  const [filter,      setFilter]      = useState('');
  const [page,        setPage]        = useState(1);
  const [expandedId,  setExpandedId]  = useState(null);
  const [expandedData,setExpandedData]= useState({});
  const [updatingId,  setUpdatingId]  = useState(null);
  const limit = 15;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit });
      if (filter) params.set('status', filter);
      const r    = await api(`/api/admin/orders?${params}`);
      const data = await r.json();
      setOrders(data.orders || data || []);
      setTotal(data.total || 0);
    } catch {
      setOrders([]);
    } finally {
      setLoading(false);
    }
  }, [filter, page]);

  useEffect(() => { load(); }, [load]);

  const toggleExpand = async (uuid) => {
    if (expandedId === uuid) { setExpandedId(null); return; }
    setExpandedId(uuid);
    if (!expandedData[uuid]) {
      try {
        const r = await api(`/api/admin/orders/${uuid}`);
        const d = await r.json();
        setExpandedData(prev => ({ ...prev, [uuid]: d }));
      } catch {}
    }
  };

  const handleStatusChange = async (uuid, newStatus) => {
    setUpdatingId(uuid);
    try {
      await api(`/api/admin/orders/${uuid}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: newStatus }),
      });
      load();
      if (expandedData[uuid]) {
        setExpandedData(prev => ({ ...prev, [uuid]: { ...prev[uuid], status: newStatus } }));
      }
    } finally {
      setUpdatingId(null);
    }
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <AdminLayout title="Rendelések">
      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 'var(--sp-2)', marginBottom: 'var(--sp-5)', flexWrap: 'wrap' }}>
        {STATUS_OPTIONS.map(opt => (
          <button
            key={opt.value}
            className={`filter-chip${filter === opt.value ? ' active' : ''}`}
            onClick={() => { setFilter(opt.value); setPage(1); }}
          >
            {opt.label}
          </button>
        ))}
      </div>

      <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-16)' }}>
            <span className="spinner" style={{ width: 32, height: 32, borderWidth: 3 }} />
          </div>
        ) : orders.length === 0 ? (
          <p style={{ textAlign: 'center', padding: 'var(--sp-12)', color: 'var(--text-muted)', fontSize: 'var(--fs-sm)' }}>
            Nincs rendelés.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Azonosító</th>
                  <th>Dátum</th>
                  <th>Vevő</th>
                  <th>Összeg</th>
                  <th>Státusz</th>
                  <th>Fizetés</th>
                  <th>Akció</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => {
                  const isExpanded = expandedId === order.uuid;
                  const detail = expandedData[order.uuid];
                  return (
                    <React.Fragment key={order.uuid}>
                      <tr style={{ cursor: 'pointer' }} onClick={() => toggleExpand(order.uuid)}>
                        <td>
                          <span style={{ fontFamily: 'monospace', fontWeight: 600, fontSize: 'var(--fs-xs)', color: 'var(--coral)' }}>
                            #{order.uuid?.slice(0, 8).toUpperCase()}
                          </span>
                        </td>
                        <td style={{ whiteSpace: 'nowrap', color: 'var(--text-muted)' }}>
                          {new Date(order.created_at).toLocaleDateString('hu-HU', { year: 'numeric', month: '2-digit', day: '2-digit' })}
                        </td>
                        <td>
                          <div style={{ fontWeight: 500 }}>{order.customer_name || order.shipping_name}</div>
                          <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>{order.customer_email}</div>
                        </td>
                        <td style={{ fontWeight: 700, color: 'var(--text)', whiteSpace: 'nowrap' }}>
                          {formatPrice(order.total_amount)}
                        </td>
                        <td><StatusBadge status={order.status} /></td>
                        <td style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>
                          {order.payment_method === 'stripe' ? 'Kártya' : 'Utánvét'}
                        </td>
                        <td onClick={e => e.stopPropagation()}>
                          <select
                            className="form-input"
                            style={{ height: 34, fontSize: 'var(--fs-xs)', padding: '0 var(--sp-3)', width: 150 }}
                            value={order.status}
                            disabled={updatingId === order.uuid}
                            onChange={e => handleStatusChange(order.uuid, e.target.value)}
                          >
                            {STATUS_OPTIONS.filter(o => o.value).map(o => (
                              <option key={o.value} value={o.value}>{o.label}</option>
                            ))}
                          </select>
                        </td>
                      </tr>

                      {/* Expanded detail row */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={7} style={{ padding: 0 }}>
                            <div style={{ background: 'var(--gray-50)', padding: 'var(--sp-5) var(--sp-6)', borderTop: '1px solid var(--border)' }}>
                              {!detail ? (
                                <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-4)' }}>
                                  <span className="spinner" style={{ width: 24, height: 24, borderWidth: 2 }} />
                                </div>
                              ) : (
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-6)' }} className="order-detail-grid">
                                  {/* Szállítási cím */}
                                  <div>
                                    <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-sm)', fontWeight: 700, marginBottom: 'var(--sp-3)', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                      Szállítási cím
                                    </h4>
                                    <div style={{ fontSize: 'var(--fs-sm)', lineHeight: 1.8 }}>
                                      <div style={{ fontWeight: 600 }}>{detail.shipping_name}</div>
                                      <div>{detail.shipping_street}</div>
                                      <div>{detail.shipping_zip} {detail.shipping_city}</div>
                                      <div>{detail.shipping_country}</div>
                                      {detail.shipping_phone && <div style={{ color: 'var(--text-muted)' }}>{detail.shipping_phone}</div>}
                                      {detail.customer_email && (
                                        <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>
                                          <a href={`mailto:${detail.customer_email}`} style={{ color: 'var(--coral)' }}>{detail.customer_email}</a>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                  {/* Tételek képekkel */}
                                  <div>
                                    <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-sm)', fontWeight: 700, marginBottom: 'var(--sp-3)', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                      Rendelt tételek
                                    </h4>
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-2)' }}>
                                      {(detail.items || []).map((item, i) => (
                                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                                          {/* Termékkép */}
                                          <div style={{ width: 44, height: 44, borderRadius: 'var(--r-sm)', overflow: 'hidden', flexShrink: 0, background: 'var(--white)', border: '1px solid var(--border)' }}>
                                            {item.image_url ? (
                                              <img src={item.image_url} alt={item.product_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                            ) : (
                                              <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--coral-light)' }}>
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" opacity="0.5">
                                                  <circle cx="6" cy="17" r="4" stroke="var(--coral)" strokeWidth="2"/>
                                                  <circle cx="18" cy="17" r="4" stroke="var(--coral)" strokeWidth="2"/>
                                                </svg>
                                              </div>
                                            )}
                                          </div>
                                          <span style={{ flex: 1, fontSize: 'var(--fs-sm)' }}>
                                            {item.quantity}× <strong>{item.product_name}</strong>
                                          </span>
                                          <span style={{ fontWeight: 600, whiteSpace: 'nowrap', fontSize: 'var(--fs-sm)' }}>{formatPrice(item.subtotal)}</span>
                                        </div>
                                      ))}
                                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-md)', fontWeight: 700, paddingTop: 'var(--sp-2)', color: 'var(--coral)' }}>
                                        <span>Végösszeg</span>
                                        <span>{formatPrice(detail.total_amount)}</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 'var(--sp-2)', marginTop: 'var(--sp-6)' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>← Előző</button>
          <span style={{ display: 'flex', alignItems: 'center', fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>
            {page} / {totalPages}
          </span>
          <button className="btn btn-ghost btn-sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}>Következő →</button>
        </div>
      )}

      <style>{`
        @media (max-width: 640px) {
          .order-detail-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </AdminLayout>
  );
}