import React, { useState, useEffect, useContext } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import api from '../../utils/api';

/* ─── AdminLayout ───────────────────────────────────────── */
export function AdminLayout({ children, title }) {
  const { user, logout } = useContext(AuthContext);
  const navigate         = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    {
      to: '/admin', label: 'Dashboard', end: true,
      icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
    },
    {
      to: '/admin/termekek', label: 'Termékek',
      icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>,
    },
    {
      to: '/admin/rendelesek', label: 'Rendelések',
      icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>,
    },
    {
      to: '/admin/felhasznalok', label: 'Felhasználók',
      icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>,
    },
  ];

  return (
    <div className="admin-layout">
      <aside className={`admin-sidebar${sidebarOpen ? ' open' : ''}`}>
        <Link to="/" className="admin-sidebar__logo">
          The Cruiser<span style={{ color: 'var(--peach)' }}>.</span>
          <div style={{ fontSize: 'var(--fs-xs)', color: 'rgba(255,255,255,0.3)', marginTop: 2, fontFamily: 'var(--font-body)', fontWeight: 400 }}>
            Admin felület
          </div>
        </Link>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-1)' }}>
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `admin-nav-item${isActive ? ' active' : ''}`}
              onClick={() => setSidebarOpen(false)}
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ marginTop: 'auto', paddingTop: 'var(--sp-6)' }}>
          <div style={{ padding: 'var(--sp-3)', borderTop: '1px solid rgba(255,255,255,0.08)', marginBottom: 'var(--sp-3)' }}>
            <div style={{ fontSize: 'var(--fs-xs)', color: 'rgba(255,255,255,0.4)' }}>Bejelentkezve</div>
            <div style={{ fontSize: 'var(--fs-sm)', color: 'rgba(255,255,255,0.75)', fontWeight: 500, marginTop: 2 }}>
              {user?.name || user?.email}
            </div>
          </div>
          <Link to="/" className="admin-nav-item" style={{ color: 'rgba(255,255,255,0.5)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
            Webshop
          </Link>
          <button
            className="admin-nav-item"
            style={{ width: '100%', color: 'rgba(255,107,107,0.8)' }}
            onClick={async () => { await logout(); navigate('/'); }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Kijelentkezés
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 199 }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="admin-content">
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-4)', marginBottom: 'var(--sp-7)' }}>
          <button
            id="admin-menu-btn"
            style={{ padding: 8, borderRadius: 'var(--r-sm)', color: 'var(--text-muted)', border: '1px solid var(--border)', background: 'var(--white)' }}
            onClick={() => setSidebarOpen(true)}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-2xl)', fontWeight: 700, color: 'var(--text)' }}>
            {title}
          </h1>
        </div>

        {children}
      </div>
    </div>
  );
}

/* ─── SVG Bar Chart ─────────────────────────────────────── */
function RevenueBarChart({ data }) {
  if (!data || data.length === 0) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 200, color: 'var(--text-muted)', fontSize: 'var(--fs-sm)' }}>
        Még nincs elegendő adat a grafikon megjelenítéséhez.
      </div>
    );
  }

  const chartW   = 560;
  const chartH   = 180;
  const padL     = 60;
  const padR     = 20;
  const padT     = 20;
  const padB     = 40;
  const innerW   = chartW - padL - padR;
  const innerH   = chartH - padT - padB;
  const maxVal   = Math.max(...data.map(d => Number(d.revenue)), 1);
  const barCount = data.length;
  const barW     = Math.min(40, (innerW / barCount) * 0.55);
  const gap      = innerW / barCount;

  const fmtShort = (n) => {
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000)     return `${Math.round(n / 1_000)}E`;
    return `${n}`;
  };

  const monthLabel = (ym) => {
    const [y, m] = ym.split('-');
    const names = ['Jan','Feb','Már','Ápr','Máj','Jún','Júl','Aug','Szep','Okt','Nov','Dec'];
    return names[parseInt(m, 10) - 1] || m;
  };

  // Y axis grid lines
  const gridLines = [0, 0.25, 0.5, 0.75, 1].map(r => ({
    y: padT + innerH * (1 - r),
    label: fmtShort(maxVal * r),
  }));

  return (
    <div style={{ overflowX: 'auto' }}>
      <svg viewBox={`0 0 ${chartW} ${chartH}`} style={{ width: '100%', minWidth: 300, display: 'block' }}>
        {/* Grid lines */}
        {gridLines.map((g, i) => (
          <g key={i}>
            <line x1={padL} y1={g.y} x2={chartW - padR} y2={g.y} stroke="var(--border)" strokeWidth="1" strokeDasharray={i === 0 ? 'none' : '4,4'} />
            <text x={padL - 6} y={g.y + 4} textAnchor="end" fill="var(--text-muted)" fontSize="10">{g.label}</text>
          </g>
        ))}

        {/* Bars */}
        {data.map((d, i) => {
          const rev    = Number(d.revenue);
          const barH   = (rev / maxVal) * innerH;
          const x      = padL + gap * i + (gap - barW) / 2;
          const y      = padT + innerH - barH;
          const isLast = i === data.length - 1;
          return (
            <g key={i}>
              {/* Bar */}
              <rect
                x={x} y={y} width={barW} height={Math.max(barH, 2)}
                rx="4" ry="4"
                fill={isLast ? 'var(--coral)' : 'var(--coral-mid)'}
              />
              {/* Value on top */}
              {barH > 20 && (
                <text x={x + barW / 2} y={y - 5} textAnchor="middle" fill="var(--text-muted)" fontSize="9" fontWeight="600">
                  {fmtShort(rev)}
                </text>
              )}
              {/* Month label */}
              <text x={x + barW / 2} y={chartH - 6} textAnchor="middle" fill={isLast ? 'var(--coral)' : 'var(--text-muted)'} fontSize="11" fontWeight={isLast ? '700' : '500'}>
                {monthLabel(d.month)}
              </text>
            </g>
          );
        })}

        {/* X axis */}
        <line x1={padL} y1={padT + innerH} x2={chartW - padR} y2={padT + innerH} stroke="var(--border)" strokeWidth="1" />
      </svg>
    </div>
  );
}

/* ─── Status Donut ──────────────────────────────────────── */
function StatusDonut({ data }) {
  const STATUS_MAP = {
    pending:    { label: 'Függőben',     color: '#E8A455' },
    paid:       { label: 'Fizetve',      color: '#30D158' },
    processing: { label: 'Feldolgozás',  color: '#4338CA' },
    shipped:    { label: 'Kiszállítva',  color: '#C85C48' },
    delivered:  { label: 'Megérkezett', color: '#1A7A38' },
    cancelled:  { label: 'Törölve',     color: '#FF3B30' },
    refunded:   { label: 'Visszafiz.',  color: '#AEAEB2' },
  };

  if (!data || data.length === 0) return null;

  const total = data.reduce((s, d) => s + Number(d.count), 0);
  if (total === 0) return null;

  const cx = 70, cy = 70, r = 55, strokeW = 18;
  let cumulativeAngle = -Math.PI / 2;

  const slices = data.map((d) => {
    const frac  = Number(d.count) / total;
    const angle = frac * 2 * Math.PI;
    const x1    = cx + r * Math.cos(cumulativeAngle);
    const y1    = cy + r * Math.sin(cumulativeAngle);
    cumulativeAngle += angle;
    const x2    = cx + r * Math.cos(cumulativeAngle);
    const y2    = cy + r * Math.sin(cumulativeAngle);
    const large = angle > Math.PI ? 1 : 0;
    const info  = STATUS_MAP[d.status] || { label: d.status, color: '#999' };
    return { ...d, x1, y1, x2, y2, large, ...info, frac };
  });

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-6)', flexWrap: 'wrap' }}>
      <svg viewBox="0 0 140 140" style={{ width: 140, height: 140, flexShrink: 0 }}>
        {slices.map((s, i) => (
          <path
            key={i}
            d={`M ${s.x1} ${s.y1} A ${r} ${r} 0 ${s.large} 1 ${s.x2} ${s.y2}`}
            fill="none"
            stroke={s.color}
            strokeWidth={strokeW}
          />
        ))}
        <text x={cx} y={cy - 8} textAnchor="middle" fill="var(--text)" fontSize="22" fontWeight="700">{total}</text>
        <text x={cx} y={cy + 10} textAnchor="middle" fill="var(--text-muted)" fontSize="10">rendelés</text>
      </svg>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {slices.map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 'var(--fs-xs)' }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
            <span style={{ color: 'var(--text-muted)' }}>{s.label}</span>
            <span style={{ fontWeight: 700, color: 'var(--text)', marginLeft: 'auto' }}>{s.count}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Dashboard ─────────────────────────────────────────── */
export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/api/admin/stats')
      .then(r => r.ok ? r.json() : null)
      .catch(() => null)
      .then(data => { setStats(data); setLoading(false); });
  }, []);

  const fmt = (n) => new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(n || 0);

  const statCards = [
    { label: 'Összes rendelés',  value: stats?.total_orders   ?? '—', icon: '📦', color: 'var(--coral)' },
    { label: 'Mai rendelések',   value: stats?.today_orders   ?? '—', icon: '📅', color: 'var(--peach-hover)' },
    { label: 'Összes bevétel',   value: stats?.total_revenue  != null ? fmt(stats.total_revenue) : '—', icon: '💰', color: '#30D158' },
    { label: 'Aktív termékek',   value: stats?.total_products ?? '—', icon: '🚲', color: 'var(--gray-600)' },
  ];

  const STATUS_MAP = {
    pending:    { label: 'Függőben',     bg: 'var(--peach-light)', color: 'var(--peach-hover)' },
    paid:       { label: 'Fizetve',      bg: 'var(--success-bg)',  color: '#1A7A38' },
    processing: { label: 'Feldolgozás',  bg: '#EEF2FF',            color: '#4338CA' },
    shipped:    { label: 'Kiszállítva',  bg: 'var(--coral-light)', color: 'var(--coral)' },
    delivered:  { label: 'Megérkezett', bg: 'var(--success-bg)',  color: '#1A7A38' },
    cancelled:  { label: 'Törölve',     bg: 'var(--error-bg)',    color: 'var(--error)' },
    refunded:   { label: 'Visszafizetve', bg: 'var(--gray-100)',  color: 'var(--gray-600)' },
  };

  return (
    <AdminLayout title="Dashboard">
      {/* Stat Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 'var(--sp-5)', marginBottom: 'var(--sp-8)' }}>
        {statCards.map((s, i) => (
          <div key={i} className="admin-stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>
                  {s.label}
                </p>
                {loading
                  ? <div style={{ width: 80, height: 28, borderRadius: 'var(--r-sm)', background: 'var(--gray-100)', animation: 'pulse 1.5s ease infinite' }} />
                  : <p style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-2xl)', fontWeight: 700, color: s.color }}>{s.value}</p>
                }
              </div>
              <span style={{ fontSize: 28 }}>{s.icon}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 'var(--sp-5)', marginBottom: 'var(--sp-8)' }}>
        {/* Havi bevétel */}
        <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'var(--sp-6)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--sp-5)' }}>
            <div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-lg)', fontWeight: 700 }}>Havi bevétel</h2>
              <p style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: 2 }}>Elmúlt 6 hónap</p>
            </div>
            <span style={{ fontSize: 22 }}>📈</span>
          </div>
          {loading ? (
            <div style={{ height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span className="spinner" style={{ width: 28, height: 28, borderWidth: 2.5 }} />
            </div>
          ) : (
            <RevenueBarChart data={stats?.monthly_revenue || []} />
          )}
        </div>

        {/* Rendelés státusz eloszlás */}
        <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'var(--sp-6)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--sp-5)' }}>
            <div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-lg)', fontWeight: 700 }}>Rendelés státuszok</h2>
              <p style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: 2 }}>Eloszlás</p>
            </div>
            <span style={{ fontSize: 22 }}>🥧</span>
          </div>
          {loading ? (
            <div style={{ height: 140, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span className="spinner" style={{ width: 28, height: 28, borderWidth: 2.5 }} />
            </div>
          ) : (
            <StatusDonut data={stats?.status_breakdown || []} />
          )}
        </div>
      </div>

      {/* Quick links */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 'var(--sp-4)', marginBottom: 'var(--sp-8)' }}>
        {[
          { to: '/admin/termekek',     label: 'Termékek',     icon: '🚲' },
          { to: '/admin/rendelesek',   label: 'Rendelések',   icon: '📦' },
          { to: '/admin/felhasznalok', label: 'Felhasználók', icon: '👥' },
        ].map(item => (
          <Link key={item.to} to={item.to} style={{
            display: 'flex', alignItems: 'center', gap: 'var(--sp-3)',
            padding: 'var(--sp-4) var(--sp-5)',
            background: 'var(--bg-card)', borderRadius: 'var(--r-xl)',
            border: '1px solid var(--border)', fontWeight: 600,
            color: 'var(--text)', fontSize: 'var(--fs-sm)',
            transition: 'box-shadow var(--t-fast), transform var(--t-fast)',
          }}
            onMouseEnter={e => { e.currentTarget.style.boxShadow = 'var(--shadow-md)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
            onMouseLeave={e => { e.currentTarget.style.boxShadow = ''; e.currentTarget.style.transform = ''; }}
          >
            <span style={{ fontSize: 22 }}>{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </div>

      {/* Recent Orders */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', overflow: 'hidden' }}>
        <div style={{ padding: 'var(--sp-5) var(--sp-6)', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-lg)', fontWeight: 700 }}>Legújabb rendelések</h2>
          <Link to="/admin/rendelesek" className="btn btn-ghost btn-sm">Összes →</Link>
        </div>
        {loading ? (
          <div style={{ padding: 'var(--sp-8)', display: 'flex', justifyContent: 'center' }}>
            <span className="spinner" style={{ width: 28, height: 28, borderWidth: 2.5 }} />
          </div>
        ) : stats?.recent_orders?.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Azonosító</th>
                  <th>Vevő</th>
                  <th>Összeg</th>
                  <th>Státusz</th>
                  <th>Dátum</th>
                </tr>
              </thead>
              <tbody>
                {stats.recent_orders.map(order => {
                  const s = STATUS_MAP[order.status] || { label: order.status, bg: 'var(--gray-100)', color: 'var(--text-muted)' };
                  return (
                    <tr key={order.uuid}>
                      <td>
                        <span style={{ fontFamily: 'monospace', fontWeight: 600, fontSize: 'var(--fs-xs)', color: 'var(--coral)' }}>
                          #{order.uuid?.slice(0, 8).toUpperCase()}
                        </span>
                      </td>
                      <td style={{ fontSize: 'var(--fs-sm)' }}>
                        <div style={{ fontWeight: 500 }}>{order.customer_name}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-xs)' }}>{order.user_email}</div>
                      </td>
                      <td style={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                        {new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(order.total_amount || 0)}
                      </td>
                      <td>
                        <span style={{ display: 'inline-block', padding: '3px 10px', borderRadius: 'var(--r-full)', fontSize: 'var(--fs-xs)', fontWeight: 600, background: s.bg, color: s.color }}>
                          {s.label}
                        </span>
                      </td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-sm)', whiteSpace: 'nowrap' }}>
                        {new Date(order.created_at).toLocaleDateString('hu-HU')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ textAlign: 'center', padding: 'var(--sp-10)', color: 'var(--text-muted)', fontSize: 'var(--fs-sm)' }}>
            Még nincsenek rendelések.
          </p>
        )}
      </div>
    </AdminLayout>
  );
}