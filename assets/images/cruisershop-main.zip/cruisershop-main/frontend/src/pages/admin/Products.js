import React, { useState, useEffect } from 'react';
import { AdminLayout } from './Dashboard';
import api from '../../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style: 'currency', currency: 'HUF', maximumFractionDigits: 0 }).format(Number(n) || 0);
}

const EMPTY_FORM = {
  name: '', description: '', price: '', stock: '', category_id: '',
  image_url: '', is_featured: false, is_active: true,
};

export default function AdminProducts() {
  const [products,   setProducts]   = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [modalOpen,  setModalOpen]  = useState(false);
  const [editing,    setEditing]    = useState(null); // product id
  const [form,       setForm]       = useState(EMPTY_FORM);
  const [saving,     setSaving]     = useState(false);
  const [deleting,   setDeleting]   = useState(null);
  const [error,      setError]      = useState('');
  const [search,     setSearch]     = useState('');

  const load = () => {
    setLoading(true);
    Promise.all([
      api('/api/admin/products').then(r => r.json()),
      api('/api/categories').then(r => r.json()).catch(() => []),
    ]).then(([prods, cats]) => {
      setProducts(Array.isArray(prods) ? prods : []);
      setCategories(Array.isArray(cats) ? cats : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditing(null);
    setForm({ ...EMPTY_FORM, category_id: categories[0]?.id || '' });
    setError('');
    setModalOpen(true);
  };

  const openEdit = (p) => {
    setEditing(p.id);
    setForm({
      name:        p.name || '',
      description: p.description || '',
      price:       String(Math.round(Number(p.price))),
      stock:       String(p.stock),
      category_id: p.category_id || '',
      image_url:   p.image_url || '',
      is_featured: !!p.is_featured,
      is_active:   p.is_active !== 0,
    });
    setError('');
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.name.trim())          { setError('A terméknév kötelező.'); return; }
    if (!form.price || isNaN(Number(form.price))) { setError('Érvényes ár szükséges.'); return; }
    if (!form.category_id)          { setError('Kategória kötelező.'); return; }
    setSaving(true);
    setError('');
    try {
      const payload = {
        name:        form.name.trim(),
        description: form.description.trim() || null,
        price:       Math.round(parseFloat(form.price)),
        stock:       parseInt(form.stock) || 0,
        category_id: parseInt(form.category_id),
        image_url:   form.image_url.trim() || null,
        is_featured: form.is_featured ? 1 : 0,
        is_active:   form.is_active ? 1 : 0,
      };
      const r = editing
        ? await api(`/api/admin/products/${editing}`, { method: 'PUT', body: JSON.stringify(payload) })
        : await api('/api/admin/products',            { method: 'POST', body: JSON.stringify(payload) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || 'Hiba');
      setModalOpen(false);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Biztosan archiválod ezt a terméket?')) return;
    setDeleting(id);
    try {
      await api(`/api/admin/products/${id}`, { method: 'DELETE' });
      load();
    } finally {
      setDeleting(null);
    }
  };

  const filtered = products.filter(p =>
    !search ||
    p.name?.toLowerCase().includes(search.toLowerCase()) ||
    p.category_name?.toLowerCase().includes(search.toLowerCase())
  );

  const setF = (k) => (e) => setForm(f => ({
    ...f,
    [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value,
  }));

  return (
    <AdminLayout title="Termékek">
      {/* Toolbar */}
      <div style={{ display: 'flex', gap: 'var(--sp-3)', marginBottom: 'var(--sp-5)', flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200, maxWidth: 360 }}>
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          </span>
          <input className="form-input" style={{ height: 42, paddingLeft: 38, borderRadius: 'var(--r-full)' }}
            type="text" placeholder="Keresés..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <button className="btn btn-primary" onClick={openCreate}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Új termék
        </button>
      </div>

      {/* Table */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-16)' }}>
            <span className="spinner" style={{ width: 32, height: 32, borderWidth: 3 }} />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Kép</th><th>Termék</th><th>Kategória</th><th>Ár (Ft)</th>
                  <th>Készlet</th><th>Aktív</th><th>Műveletek</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id}>
                    <td>
                      {p.image_url
                        ? <img src={p.image_url} alt={p.name} style={{ width: 52, height: 40, borderRadius: 'var(--r-sm)', objectFit: 'cover' }} />
                        : <div style={{ width: 52, height: 40, borderRadius: 'var(--r-sm)', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🚲</div>
                      }
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{p.name}</div>
                      <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>{p.slug}</div>
                    </td>
                    <td><span className="badge badge-peach">{p.category_name}</span></td>
                    <td style={{ fontWeight: 700, color: 'var(--coral)', whiteSpace: 'nowrap' }}>
                      {formatPrice(p.price)}
                    </td>
                    <td>
                      <span style={{ fontWeight: 600, color: p.stock === 0 ? 'var(--error)' : p.stock <= 3 ? 'var(--peach-hover)' : 'var(--success)' }}>
                        {p.stock} db
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${p.is_active ? 'badge-success' : 'badge-error'}`}>
                        {p.is_active ? 'Aktív' : 'Archív'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 'var(--sp-2)' }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => openEdit(p)}>
                          Szerkesztés
                        </button>
                        <button
                          className="btn btn-sm"
                          style={{ background: 'var(--error-bg)', color: 'var(--error)' }}
                          onClick={() => handleDelete(p.id)}
                          disabled={deleting === p.id}
                        >
                          {deleting === p.id ? <span className="spinner" style={{ width: 14, height: 14, borderWidth: 2 }} /> : 'Archiválás'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={7} style={{ textAlign: 'center', padding: 'var(--sp-10)', color: 'var(--text-muted)' }}>
                    {search ? 'Nincs találat.' : 'Még nincsenek termékek.'}
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setModalOpen(false); }}>
          <div className="modal-box">
            <div className="modal-header">
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-xl)', fontWeight: 700 }}>
                {editing ? 'Termék szerkesztése' : 'Új termék felvétele'}
              </h2>
              <button onClick={() => setModalOpen(false)} style={{ padding: 8, borderRadius: 'var(--r-sm)', color: 'var(--text-muted)' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="modal-body">
              {error && (
                <div style={{ background: 'var(--error-bg)', color: 'var(--error)', padding: '10px 14px', borderRadius: 'var(--r-sm)', fontSize: 'var(--fs-sm)', fontWeight: 500 }}>
                  {error}
                </div>
              )}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
                <div className="form-group" style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Terméknév *</label>
                  <input className="form-input" value={form.name} onChange={setF('name')} placeholder="pl. City Rider Pro" />
                </div>
                <div className="form-group">
                  <label className="form-label">Ár (Ft) *</label>
                  <input className="form-input" type="number" min="0" step="100" value={form.price} onChange={setF('price')} placeholder="189900" />
                </div>
                <div className="form-group">
                  <label className="form-label">Készlet (db)</label>
                  <input className="form-input" type="number" min="0" value={form.stock} onChange={setF('stock')} placeholder="10" />
                </div>
                <div className="form-group" style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Kategória *</label>
                  <select className="form-input" value={form.category_id} onChange={setF('category_id')}>
                    <option value="">— Válassz kategóriát —</option>
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group" style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Leírás</label>
                  <textarea className="form-input" rows={3} value={form.description} onChange={setF('description')} placeholder="Termék leírása..." />
                </div>
                <div className="form-group" style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Kép URL</label>
                  <input className="form-input" value={form.image_url} onChange={setF('image_url')} placeholder="https://..." />
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)' }}>
                  <input type="checkbox" id="is_featured" checked={form.is_featured} onChange={setF('is_featured')} style={{ width: 18, height: 18, accentColor: 'var(--coral)', cursor: 'pointer' }} />
                  <label htmlFor="is_featured" className="form-label" style={{ cursor: 'pointer', marginBottom: 0 }}>Kiemelt termék</label>
                </div>
                {editing && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)' }}>
                    <input type="checkbox" id="is_active" checked={form.is_active} onChange={setF('is_active')} style={{ width: 18, height: 18, accentColor: 'var(--coral)', cursor: 'pointer' }} />
                    <label htmlFor="is_active" className="form-label" style={{ cursor: 'pointer', marginBottom: 0 }}>Aktív (látható)</label>
                  </div>
                )}
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setModalOpen(false)}>Mégse</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? <span className="spinner" style={{ width: 18, height: 18, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} /> : (editing ? 'Mentés' : 'Létrehozás')}
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
