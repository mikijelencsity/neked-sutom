export { VerifyEmailPage as default } from './AllPages';
