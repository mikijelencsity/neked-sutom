export { OrderSuccessPage as default } from './AllPages';
