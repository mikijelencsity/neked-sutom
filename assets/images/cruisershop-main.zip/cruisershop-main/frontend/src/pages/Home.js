import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import FadeIn from '../components/FadeIn';
import api from '../utils/api';

function formatPrice(n) {
  return new Intl.NumberFormat('hu-HU', { style:'currency', currency:'HUF', maximumFractionDigits:0 }).format(n);
}

const CATEGORIES = [ { slug: 'elektromos', label: 'Elektromos kerékpár', count: '10+ modell', img: 'https://s13emagst.akamaized.net/products/3172/3171239/images/res_fa2386894b42209d1be93240579e0a12.jpg', color: '#C85C48' },
                     { slug: 'tura',       label: 'Túrakerékpár',        count: '8+ modell',  img: 'https://s13emagst.akamaized.net/products/24570/24569470/images/res_cf3cd8e2b557dafb892ba4b3af15f005.jpg', color: '#E8A455' },
                     { slug: 'varosi',     label: 'Városi kerékpár',     count: '12+ modell', img: 'https://velomax.hu/wp-content/uploads/1-leader-fox-park-city-e-bike-e-city-elektromos-kerekpar-bicikli-2021-shimano-bafang-tourney-shimano-36v-250w-13ah-468wh-agymotor.jpg', color: '#636366' },
                     { slug: 'gyermek',   label: 'Gyermekkerékpár',     count: '6+ modell',  img: 'https://www.lampak.hu/qplay-gyerek-kerekpar-14-miniby-3-az-1-ben-kek-img-ag0759-fd-2.jpg', color: '#3A3A3C' }, ];

const WHY = [
  {
    icon: (<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>),
    title: 'Garancia',
    desc: 'Minden kerékpárra 2 év gyártói garancia. Probléma esetén mi intézzük.',
  },
  {
    icon: (<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>),
    title: 'Gyors szállítás',
    desc: 'Raktárkészletről 1-3 munkanapon belül kiszállítunk az ország egész területére.',
  },
  {
    icon: (<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>),
    title: 'Személyes beüzemelés',
    desc: 'Minden kerékpárt szakszerűen beüzemelünk és bemutatunk neked személyesen.',
  },
  {
    icon: (<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>),
    title: 'Legjobb árak',
    desc: 'Versenytárs-árakon hozzuk el a legjobb márkák kerékpárait egyenesen hozzád.',
  },
];

// FIX 2: "Verified vásárló" → "Elégedett ügyfél"
const TESTIMONIALS = [
  { name: 'csaba19870221', city: 'Elégedett ügyfél', stars: 5, text: 'Korrekt eladó és gyors kiszolgálás. Sajnos az ünnepek közbeszóltak, így két hét volt, mire megkaptam a kerékpárvillát, amire szükségem volt. Ettől függetlenül minden rendben zajlott. Az eladó nem csak eladó, hanem ért is hozzá. Mindenkinek ajánlom a boltot!' },
  { name: 'Hajdó Márió', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon segítőkész volt a szerelő, minden rendben zajlott a javítással. Csak ajánlani tudom!' },
  { name: 'Barkóczi Bernadett', city: 'Baja', stars: 5, text: 'Nagyon kedves és segítőkész szolgáltató! Alig egy órája érkeztünk pár napos szabadságra Bajára, amikor észrevettük, hogy az otthonról hozott bicikli defektes. Felkerestük az üzletet, és elvállalták a javítást. Mindössze egy óra múlva már mehettünk is érte. A tulajdonos nagyon kedvesen sok programtippet is adott nekünk. Csak ajánlani tudom!' },
  { name: 'Kurcz Péter', city: 'Elégedett ügyfél', stars: 5, text: 'Második biciklit vásároltuk itt. A srác nagyon korrekt, előre nem kér egy fillért sem, az árak jóval a netes árak alatt vannak. 600 db van raktáron, szó szerint meg is mutatta nekünk őket. Nagyon elégedettek vagyunk!' },
  { name: 'Kovács Ádám', city: 'Baja', stars: 5, text: 'Nem drága, a tulajdonos rendes és segítőkész. Ha szervizelni kell a bringát, rugalmas és gyors, sokszor még aznap kész a munkával. Nagy választék van jó minőségű új biciklikből. Ajánlom!' },
  { name: 'Berta Tímea', city: 'Elégedett ügyfél', stars: 5, text: 'Profi és hozzáértő kiszolgálás. Türelmes, kedves és barátságos eladó. Csodás biciklit tudtam nála vásárolni. Csak ajánlani tudom!' },
  { name: 'Mendler Gabriella', city: 'Elégedett ügyfél', stars: 5, text: 'Meglepően széles választék, készséges és hozzáértő kiszolgálás.' },
  { name: 'Kovacs Péter', city: 'Baja', stars: 5, text: 'Baja legjobb kerékpárboltja! Udvarias kiszolgálás, jó árak, hatalmas bringaválaszték és tökéletes szerviz. Ajánlom!' },
  { name: 'Kamenik Attila', city: 'Elégedett ügyfél', stars: 5, text: 'Barátságos kiszolgálás, elfogadható árak, minőségi árucikkek.' },
  { name: 'Novok Richárd', city: 'Elégedett ügyfél', stars: 5, text: 'Profi szakértelem, hatalmas választék, olcsó árak, kedves és segítőkész kiszolgálás.' },
  { name: 'Robert Bozso', city: 'Elégedett ügyfél', stars: 5, text: 'Többször vásároltam náluk, nagyon meg vagyok elégedve. Ez egy jó kerékpárüzlet, mindenkinek ajánlom!' },
  { name: 'Groll Mária', city: 'Elégedett ügyfél', stars: 5, text: 'Gyors, pontos, precíz és nagyon udvarias kiszolgálás.' },
  { name: 'Takács Tibor', city: 'Elégedett ügyfél', stars: 5, text: 'Segítőkész és gyors kiszolgálás.' },
  { name: 'Durand Marie-lyse', city: 'Baja', stars: 5, text: 'Szerintem Baján az egyik legjobb üzlet! Mindenkinek aki megbízható boltot és kerékpárt keres csak ajánlani tudom!!!' },
  { name: 'Huszti Gergely', city: 'Elégedett ügyfél', stars: 5, text: 'A feleségemnek itt vettem meg a kerékpárját. Imádja! Szuper üzlet, jó fej tulajdonossal, remek munkaerővel!' },
  { name: 'Antonné Marcsi', city: 'Elégedett ügyfél', stars: 5, text: 'Egy üzlet ahol nem úgy néznek rád, hogy minek jöttél! Figyelmes, segítőkész, megold mindent! Leginkább az első szempont, első a VÁSÁRLÓ!' },
  { name: 'Nagy Mária', city: 'Elégedett ügyfél', stars: 5, text: 'Nagyon szeretek ide járni. Udvariasak, segítőkészek. Mindent megoldanak!!!!!' },
  { name: 'Vujevity Mónika', city: 'Elégedett ügyfél', stars: 5, text: 'Csak ajánlani tudom! Csodás az új paripám. Ha kell valami vagy kérdésed van szólj!' },
  { name: 'Selymesi Ira Mihality', city: 'Baja', stars: 5, text: 'Rengeteg szép kerékpár és praktikus, mert szerviz is itt van.' },
  { name: 'Kollár Mária', city: 'Elégedett ügyfél', stars: 5, text: 'Gyors, megbízható, kedves emberek!!!' },
];

const ZTECH_SPECS = [
  { label: 'Motor teljesítmény', value: '250W', unit: 'brushless' },
  { label: 'Hatótáv', value: '80', unit: 'km+' },
  { label: 'Töltési idő', value: '4', unit: 'óra' },
  { label: 'Max sebesség', value: '25', unit: 'km/h' },
  { label: 'Akkumulátor', value: '36V', unit: 'Li-ion' },
  { label: 'Terhelhetőség', value: '120', unit: 'kg' },
];

const ZTECH_FEATURES = [
  {
    icon: (
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
      </svg>
    ),
    title: 'Hatótáv 80 km+',
    desc: 'Nagy kapacitású lítium akkumulátor, egy töltéssel egész napos kerékpározás.',
  },
  {
    icon: (
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="2" y="7" width="16" height="10" rx="2"/>
        <path d="M22 11v2"/>
        <line x1="6" y1="11" x2="6" y2="13"/>
        <line x1="10" y1="9" x2="10" y2="15"/>
        <line x1="14" y1="11" x2="14" y2="13"/>
      </svg>
    ),
    title: 'Gyorstöltés 4h',
    desc: 'Standard háztartási aljzatból tölthető, 4 óra alatt teljesen feltöltődik.',
  },
  {
    icon: (
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <polyline points="9 12 11 14 15 10"/>
      </svg>
    ),
    title: '2 év garancia',
    desc: 'A motor és az akkumulátor is teljes garanciával rendelkezik.',
  },
  {
    icon: (
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="5" y="2" width="14" height="20" rx="2"/>
        <line x1="12" y1="18" x2="12.01" y2="18" strokeWidth="2"/>
        <path d="M9 7h6M9 11h4"/>
      </svg>
    ),
    title: 'Okos vezérlés',
    desc: 'Bluetooth applikáción keresztül nyomon követheted a teljesítményt és az akkumulátor állapotát.',
  },
];

// ─── ANIMATED COUNTER ───────────────────────────────────────────────
function useCountUp(target, duration = 1800, startWhen = true) {
  const [count, setCount] = useState(0);
  const startRef = useRef(null);
  const rafRef = useRef(null);

  useEffect(() => {
    if (!startWhen) return;
    startRef.current = null;

    const easeOutQuart = t => 1 - Math.pow(1 - t, 4);

    const step = (timestamp) => {
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      setCount(Math.floor(easeOutQuart(progress) * target));
      if (progress < 1) rafRef.current = requestAnimationFrame(step);
    };

    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration, startWhen]);

  return count;
}

// FIX 3: Mobile-friendly stat — compact font, no wrapping
function AnimatedStat({ num, suffix = '', label, duration = 1800 }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.4 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const count = useCountUp(num, duration, visible);

  return (
    <div ref={ref} style={{ textAlign: 'center', minWidth: 0 }}>
      <div style={{
        fontFamily: 'var(--font-display)',
        // FIX: clamp tightened — on very small screens stays on one line
        fontSize: 'clamp(1.6rem, 4vw, 5rem)',
        fontWeight: 900,
        color: 'var(--coral)',
        lineHeight: 1,
        letterSpacing: '-0.02em',
        fontVariantNumeric: 'tabular-nums',
        whiteSpace: 'nowrap',
      }}>
        {count}{suffix}
      </div>
      <div style={{
        fontSize: 'clamp(0.65rem, 1.8vw, var(--fs-sm))',
        color: 'var(--text-muted)',
        fontWeight: 500,
        marginTop: 6,
        letterSpacing: '0.02em',
        whiteSpace: 'nowrap',
      }}>
        {label}
      </div>
    </div>
  );
}

// ─── STAR ROW ────────────────────────────────────────────────────────
function StarRow({ count }) {
  return (
    <div style={{ display: 'flex', gap: 3, marginBottom: 'var(--sp-4)' }}>
      {Array.from({ length: count }).map((_, i) => (
        <svg key={i} width="16" height="16" viewBox="0 0 24 24" fill="var(--peach)" stroke="none">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
        </svg>
      ))}
    </div>
  );
}

// ─── TESTIMONIAL CAROUSEL ────────────────────────────────────────────
// FIX 1: Full-width carousel — uses negative margin to break out of container
function TestimonialCarousel() {
  const trackRef = useRef(null);
  const pausedRef = useRef(false);
  const posRef = useRef(0);
  const animRef = useRef(null);
  const CARD_WIDTH = 340;
  const GAP = 24;
  const STEP = CARD_WIDTH + GAP;
  const SPEED = 0.5;
  const items = [...TESTIMONIALS, ...TESTIMONIALS];

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const totalWidth = TESTIMONIALS.length * STEP;
    const animate = () => {
      if (!pausedRef.current) {
        posRef.current += SPEED;
        if (posRef.current >= totalWidth) posRef.current -= totalWidth;
        track.style.transform = `translateX(-${posRef.current}px)`;
      }
      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  return (
    // FIX 1: Breakout wrapper — stretches edge-to-edge regardless of parent container
    <div style={{
      width: '100vw',
      position: 'relative',
      left: '50%',
      right: '50%',
      marginLeft: '-50vw',
      marginRight: '-50vw',
      overflow: 'hidden',
      cursor: 'default',
      paddingLeft: 24,
    }}
      onMouseEnter={() => { pausedRef.current = true; }}
      onMouseLeave={() => { pausedRef.current = false; }}
    >
      <div ref={trackRef} style={{ display: 'flex', gap: GAP, width: 'max-content', willChange: 'transform' }}>
        {items.map((r, i) => (
          <div key={i} style={{
            width: CARD_WIDTH,
            flexShrink: 0,
            background: 'var(--bg)',
            borderRadius: 'var(--r-xl)',
            padding: 'var(--sp-7)',
            border: '1px solid var(--border)',
            display: 'flex',
            flexDirection: 'column',
            gap: 0,
          }}>
            <StarRow count={r.stars} />
            <p style={{
              fontSize: 'var(--fs-sm)',
              color: 'var(--text-2)',
              lineHeight: 1.75,
              marginBottom: 'var(--sp-5)',
              fontStyle: 'italic',
              flex: 1,
            }}>
              „{r.text}"
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)' }}>
              <div style={{
                width: 38,
                height: 38,
                borderRadius: '50%',
                background: 'var(--coral-light)',
                color: 'var(--coral)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontFamily: 'var(--font-display)',
                fontWeight: 700,
                fontSize: 'var(--fs-md)',
                flexShrink: 0,
              }}>
                {r.name[0].toUpperCase()}
              </div>
              <div>
                <div style={{ fontWeight: 600, color: 'var(--text)', fontSize: 'var(--fs-sm)' }}>{r.name}</div>
                <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>{r.city}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── ZTECH SPEC BAR ─────────────────────────────────────────────────
function ZTechSpecBar({ label, value, unit }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '14px 0',
      borderBottom: '1px solid rgba(255,255,255,0.08)',
    }}>
      <span style={{ fontSize: 'var(--fs-sm)', color: 'rgba(255,255,255,0.55)', fontWeight: 500 }}>{label}</span>
      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'white', fontSize: 'var(--fs-lg)' }}>
        {value} <span style={{ fontSize: 'var(--fs-xs)', color: 'rgba(255,255,255,0.45)', fontWeight: 500 }}>{unit}</span>
      </span>
    </div>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────────────
export default function Home() {
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/api/products?limit=6')
      .then(r => r.json())
      .then(d => { setFeatured(d.products || d || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <main>
      {/* ─ HERO ─ */}
      <section className="hero">
        <div className="hero__image-side">
          <img src="https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=1200&q=85" alt="Cruiser kerékpár" />
          <div className="hero__image-overlay" />
          <div style={{ position: 'absolute', bottom: 40, left: 40, background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(20px)', borderRadius: 'var(--r-xl)', padding: '16px 20px', boxShadow: 'var(--shadow-lg)', maxWidth: 200 }} className="anim-fade-up anim-d3">
            <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, color: 'var(--coral)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>Beüzemelve kiszállítva</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--fs-lg)', color: 'var(--text)' }}>1–3 munkanapon belül</div>
          </div>
        </div>

        <div className="hero__content-side">
          <div>
            <div className="hero__eyebrow anim-fade-right"><span className="hero__eyebrow-dot" />Prémium kerékpárok</div>
            <h1 className="hero__title anim-fade-right anim-d1">Tekerd be<br /><em>stílusosan</em> az életet</h1>
            <p className="hero__subtitle anim-fade-right anim-d2">
              Válaszd ki álomkerékpárodat a legjobb elektromos, túra, városi és gyermek modellek közül. Garancia, beüzemelés, gyors szállítás.
            </p>
          </div>

          <div className="hero__cta anim-fade-right anim-d3">
            <Link to="/kerekparok" className="btn btn-primary btn-lg">
              Kerékpárok megtekintése
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </Link>
            <button className="btn btn-ghost btn-lg" onClick={() => document.getElementById('featured')?.scrollIntoView({ behavior: 'smooth' })}>
              Kiemelt ajánlatok
            </button>
          </div>

          {/* ─ HERO STATS – FIX 3: nowrap + compact mobile sizing ─ */}
          <div className="hero__stats anim-fade-right anim-d4" style={{ flexWrap: 'nowrap', gap: 'clamp(var(--sp-4), 4vw, var(--sp-10))' }}>
            <AnimatedStat num={10} suffix="+" label="Év tapasztalat" duration={1200} />
            <AnimatedStat num={5000} suffix="+" label="Elégedett ügyfél" duration={2000} />
            <AnimatedStat num={2} suffix=" év" label="Garancia" duration={900} />
          </div>
        </div>
      </section>

      {/* ─ CATEGORIES ─ */}
      <section className="section" style={{ background: 'var(--bg)' }}>
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <div className="section-eyebrow">Kategóriák</div>
              <h2 className="section-title">Találd meg a tökéletes bringát</h2>
              <p className="section-sub">Legyen szó városi közlekedésről, túrázásról, elektromos megoldásokról vagy gyermekeknek való kerékpárról — megvan a neked való kerékpár.</p>
            </div>
          </FadeIn>
          <div className="cat-grid">
            {CATEGORIES.map((cat, i) => (
              <FadeIn key={cat.slug} direction="up" delay={i * 0.08}>
                <Link to={`/kerekparok?category=${cat.slug}`} className="cat-card">
                  <img src={cat.img} alt={cat.label} loading="lazy" />
                  <div className="cat-card__overlay" />
                  <div className="cat-card__body">
                    <div className="cat-card__name">{cat.label}</div>
                    <div className="cat-card__count">{cat.count}</div>
                  </div>
                  <div className="cat-card__arrow">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                  </div>
                </Link>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ─ FEATURED PRODUCTS ─ */}
      <section className="section" id="featured" style={{ background: 'var(--white)' }}>
        <div className="container">
          <FadeIn>
            <div className="section-header" style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', textAlign: 'left', marginBottom: 'var(--sp-10)' }}>
              <div>
                <div className="section-eyebrow">Kínálatunkból</div>
                <h2 className="section-title">Kiemelt kerékpárok</h2>
              </div>
              <Link to="/kerekparok" className="btn btn-outline" style={{ flexShrink: 0 }}>Összes megtekintése</Link>
            </div>
          </FadeIn>
          {loading ? (
            <div className="product-grid">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} style={{ borderRadius: 'var(--r-xl)', overflow: 'hidden', border: '1px solid var(--border)' }}>
                  <div className="skeleton" style={{ height: 220 }} />
                  <div style={{ padding: 20 }}>
                    <div className="skeleton" style={{ height: 12, width: '40%', marginBottom: 10 }} />
                    <div className="skeleton" style={{ height: 20, marginBottom: 6 }} />
                    <div className="skeleton" style={{ height: 16, width: '60%' }} />
                  </div>
                </div>
              ))}
            </div>
          ) : featured.length > 0 ? (
            <div className="product-grid">
              {featured.map((product, i) => (
                <FadeIn key={product.id} direction="up" delay={i * 0.07}>
                  <ProductCard product={product} />
                </FadeIn>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <div className="empty-state__icon">🚲</div>
              <h3 className="empty-state__title">Hamarosan érkeznek a termékek</h3>
            </div>
          )}
        </div>
      </section>

      {/* ─ ELEKTROMOS SECTION ─ */}
      <section style={{ background: '#0A0A0F', overflow: 'hidden', position: 'relative' }}>
        {/* Background blobs */}
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: '-180px', left: '-180px', width: 600, height: 600, borderRadius: '50%', background: 'radial-gradient(circle, rgba(200,92,72,0.18) 0%, transparent 70%)' }} />
          <div style={{ position: 'absolute', bottom: '-100px', right: '-100px', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle, rgba(232,164,85,0.12) 0%, transparent 70%)' }} />
          <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.04 }} xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 60" fill="none" stroke="white" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        <div className="container" style={{ position: 'relative', paddingTop: 'var(--sp-20)', paddingBottom: 'var(--sp-20)' }}>

          {/* ── Centred header ── */}
          <FadeIn>
            <div style={{ textAlign: 'center', marginBottom: 'var(--sp-10)' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(200,92,72,0.15)', border: '1px solid rgba(200,92,72,0.3)', borderRadius: 'var(--r-full)', padding: '6px 16px', marginBottom: 'var(--sp-5)' }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--coral)', boxShadow: '0 0 8px var(--coral)', animation: 'pulse 2s infinite' }} />
                <span style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--coral)' }}>Elektromos kerékpárok</span>
              </div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4.5vw, 3.4rem)', fontWeight: 900, color: 'white', lineHeight: 1.1, letterSpacing: '-0.02em', marginBottom: 'var(--sp-4)' }}>
                Elektromos <span style={{ background: 'linear-gradient(90deg, var(--coral) 0%, var(--peach) 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>szabadság</span>, minden nap
              </h2>
              <p style={{ fontSize: 'var(--fs-md)', color: 'rgba(255,255,255,0.5)', lineHeight: 1.7, maxWidth: 520, margin: '0 auto' }}>
                Az elektromos kerékpáraink a legmodernebb technológiát ötvözik időtálló designnal. Tökéletes az ingázáshoz, a kikapcsolódáshoz és a kalandokhoz egyaránt.
              </p>
            </div>
          </FadeIn>

          {/* ── Two-column content ── */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 'var(--sp-6)', alignItems: 'start' }}>

            {/* Left: image + specs */}
            <FadeIn direction="left">
              <div>
                <div style={{ borderRadius: 24, overflow: 'hidden', position: 'relative', aspectRatio: '4/3', marginBottom: 'var(--sp-4)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1000&q=90" alt="Elektromos kerékpár" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(10,10,15,0.7) 0%, transparent 50%)' }} />
                  <div style={{ position: 'absolute', top: 16, right: 16, background: 'var(--coral)', color: 'white', fontSize: 'var(--fs-xs)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', padding: '5px 12px', borderRadius: 'var(--r-full)', boxShadow: '0 4px 16px rgba(200,92,72,0.5)' }}>Bestseller</div>
                  <div style={{ position: 'absolute', bottom: 16, left: 20 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'var(--fs-lg)', color: 'white' }}>ZTech Urban Pro</div>
                    <div style={{ fontSize: 'var(--fs-sm)', color: 'rgba(255,255,255,0.6)' }}>7-fokozatú Shimano váltó · LCD kijelző</div>
                  </div>
                </div>
                <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '6px 20px' }}>
                  {ZTECH_SPECS.map((spec, i) => <ZTechSpecBar key={i} {...spec} />)}
                </div>
              </div>
            </FadeIn>

            {/* Right: features + CTA */}
            <FadeIn direction="right">
              <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
                {ZTECH_FEATURES.map((f, i) => (
                  <div key={i} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '16px 20px', display: 'flex', alignItems: 'flex-start', gap: 14, transition: 'background 0.2s, border-color 0.2s, transform 0.2s', cursor: 'default' }}
                    onMouseEnter={e => { e.currentTarget.style.background = 'rgba(200,92,72,0.08)'; e.currentTarget.style.borderColor = 'rgba(200,92,72,0.25)'; e.currentTarget.style.transform = 'translateX(4px)'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.03)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)'; e.currentTarget.style.transform = ''; }}
                  >
                    <div style={{ width: 44, height: 44, flexShrink: 0, borderRadius: 12, background: 'rgba(200,92,72,0.12)', border: '1px solid rgba(200,92,72,0.2)', color: 'var(--coral)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{f.icon}</div>
                    <div>
                      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-md)', fontWeight: 700, color: 'white', marginBottom: 2 }}>{f.title}</h3>
                      <p style={{ fontSize: 'var(--fs-sm)', color: 'rgba(255,255,255,0.5)', lineHeight: 1.6 }}>{f.desc}</p>
                    </div>
                  </div>
                ))}
                <div style={{ background: 'linear-gradient(135deg, rgba(200,92,72,0.15) 0%, rgba(232,164,85,0.08) 100%)', border: '1px solid rgba(200,92,72,0.2)', borderRadius: 18, padding: '24px' }}>
                  <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--peach)', marginBottom: 8 }}>Exkluzív ajánlat</div>
                  <p style={{ fontSize: 'var(--fs-sm)', color: 'rgba(255,255,255,0.7)', marginBottom: 16, lineHeight: 1.6 }}>250W motor, LCD kijelző, 7-fokozatú Shimano váltó — minden, amire szükséged van a tökéletes elektromos kerékpározáshoz.</p>
                  <Link to="/kerekparok?category=elektromos" className="btn btn-primary btn-lg">
                    Elektromos modellek megtekintése
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                  </Link>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>

        <style>{`
          @keyframes pulse {
            0%, 100% { opacity: 1; box-shadow: 0 0 8px var(--coral); }
            50% { opacity: 0.5; box-shadow: 0 0 16px var(--coral); }
          }
        `}</style>
      </section>

      {/* ─ PROMO BANNER ─ */}
      <section style={{ background: 'linear-gradient(135deg, var(--coral) 0%, #A84835 100%)', padding: 'var(--sp-16) 0', overflow: 'hidden', position: 'relative' }}>
        <div style={{ position: 'absolute', right: '-60px', top: '-60px', width: 320, height: 320, borderRadius: '50%', background: 'rgba(255,255,255,0.06)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', right: '60px', top: '40px', width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', pointerEvents: 'none' }} />
        <div className="container" style={{ position: 'relative' }}>
          <FadeIn>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 40, flexWrap: 'wrap' }}>
              <div>
                <p style={{ fontSize: 'var(--fs-sm)', fontWeight: 700, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.65)', marginBottom: 8 }}>Korlátozott időre</p>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.8rem,4vw,2.8rem)', fontWeight: 700, color: 'white', lineHeight: 1.1, marginBottom: 12 }}>
                  Személyes beüzemelés<br />minden rendeléshez
                </h2>
                <p style={{ fontSize: 'var(--fs-md)', color: 'rgba(255,255,255,0.8)', maxWidth: 480 }}>
                  Szakembereink minden kerékpárt elvisznek hozzád, összeszerelik és bemutatják a működését. Ingyenesen, minden rendelésnél.
                </p>
              </div>
              <div>
                <Link to="/kerekparok" className="btn btn-white btn-lg">
                  Megrendelem most
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </Link>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ─ WHY CHOOSE US ─ */}
      <section className="section" style={{ background: 'var(--bg)' }}>
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <div className="section-eyebrow">Miért minket válassz</div>
              <h2 className="section-title">A Cruiser Shop különlegessége</h2>
            </div>
          </FadeIn>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 'var(--sp-5)' }}>
            {WHY.map((item, i) => (
              <FadeIn key={i} direction="up" delay={i * 0.08}>
                <div style={{ background: 'var(--white)', borderRadius: 'var(--r-xl)', border: '1px solid var(--border)', padding: 'var(--sp-7)', transition: 'box-shadow var(--t-base), transform var(--t-base)' }}
                  onMouseEnter={e => { e.currentTarget.style.boxShadow = 'var(--shadow-lg)'; e.currentTarget.style.transform = 'translateY(-3px)'; }}
                  onMouseLeave={e => { e.currentTarget.style.boxShadow = ''; e.currentTarget.style.transform = ''; }}
                >
                  <div style={{ width: 52, height: 52, borderRadius: 'var(--r-md)', background: 'var(--coral-light)', color: 'var(--coral)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 'var(--sp-4)' }}>{item.icon}</div>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-xl)', fontWeight: 700, color: 'var(--text)', marginBottom: 'var(--sp-2)' }}>{item.title}</h3>
                  <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', lineHeight: 1.7 }}>{item.desc}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ─ ABOUT US ─ */}
      <section className="section" style={{ background: 'var(--white)', overflow: 'hidden' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 'var(--sp-12)', alignItems: 'center' }}>
            <FadeIn direction="left">
              <div style={{ position: 'relative' }}>
                <div style={{ borderRadius: 32, overflow: 'hidden', aspectRatio: '4/5', maxHeight: 520 }}>
                  <img src="https://images.unsplash.com/photo-1517649763962-0c623066013b?w=800&q=85" alt="Cruiser Shop csapat" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <div style={{ position: 'absolute', bottom: -20, right: -16, background: 'var(--coral)', color: 'white', borderRadius: 'var(--r-xl)', padding: '20px 24px', boxShadow: 'var(--shadow-lg)', textAlign: 'center', minWidth: 130 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, lineHeight: 1 }}>10+</div>
                  <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 600, marginTop: 4, opacity: 0.88 }}>Év tapasztalat</div>
                </div>
              </div>
            </FadeIn>

            <FadeIn direction="right">
              <div>
                <div className="section-eyebrow">Vélemények</div>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.8rem,3.5vw,2.6rem)', fontWeight: 700, color: 'var(--text)', lineHeight: 1.15, marginBottom: 'var(--sp-5)' }}>Több mint egy kerékpárbolt</h2>
                <p style={{ fontSize: 'var(--fs-md)', color: 'var(--text-2)', lineHeight: 1.8, marginBottom: 'var(--sp-5)' }}>
                  A Cruiser Shop több mint 10 éve segíti a kerékpározás szerelmeseit megtalálni álomkerékpárjukat. Csapatunk mélyen elkötelezett a minőség és a személyes kiszolgálás iránt — nálunk nem csak terméket veszel, hanem egy hosszú távú partnert.
                </p>
                <p style={{ fontSize: 'var(--fs-md)', color: 'var(--text-2)', lineHeight: 1.8, marginBottom: 'var(--sp-8)' }}>
                  Büszkék vagyunk arra, hogy több mint 5000 elégedett vásárlónk van az ország minden szegletéből. Minden kerékpárt személyesen üzemelünk be, és a vásárlás után is ott vagyunk, ha segítségre van szükséged.
                </p>
                <div style={{ display: 'flex', gap: 'var(--sp-8)', flexWrap: 'wrap', marginBottom: 'var(--sp-8)', paddingTop: 'var(--sp-6)', borderTop: '1px solid var(--border)' }}>
                  {[{ num: '5000+', label: 'Elégedett ügyfél' }, { num: '2 év', label: 'Garancia' }, { num: '50+', label: 'Modell raktáron' }].map((s, i) => (
                    <div key={i}>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', fontWeight: 800, color: 'var(--coral)' }}>{s.num}</div>
                      <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', fontWeight: 500 }}>{s.label}</div>
                    </div>
                  ))}
                </div>
                <Link to="/rolunk" className="btn btn-primary btn-lg">
                  Ismerjük meg egymást
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </Link>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ─ TESTIMONIALS CAROUSEL ─ */}
<section className="section" style={{ background: 'var(--white)', paddingBottom: 'var(--sp-16)' }}>
  <div className="container">
    <FadeIn>
      <div className="section-header">
        <div className="section-eyebrow">Vélemények</div>
        <h2 className="section-title">Mit mondanak vevőink</h2>
        <p className="section-sub">Vidd rá az egeret a megállításhoz — olvasd el a véleményeket!</p>
      </div>
    </FadeIn>
  </div>
  <TestimonialCarousel />
  {/* ÚJ GOMB */}
  <div className="container">
    <FadeIn>
      <div style={{ textAlign: 'center', marginTop: 'var(--sp-10)' }}>
        <Link to="/rolunk" className="btn btn-outline btn-lg">
          Olvasd el az összes véleményt
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </Link>
      </div>
    </FadeIn>
  </div>
</section>

      {/* ─ NEWSLETTER ─ */}
      <NewsletterSection />
    </main>
  );
}

function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email.includes('@')) setSubmitted(true);
  };

  return (
    <section style={{ background: 'var(--gray-900)', padding: 'var(--sp-16) 0' }}>
      <div className="container">
        <FadeIn>
          <div style={{ maxWidth: 560, margin: '0 auto', textAlign: 'center' }}>
            <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--peach)', marginBottom: 'var(--sp-3)' }}>Maradj naprakész</div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.6rem,3.5vw,2.4rem)', fontWeight: 700, color: 'white', marginBottom: 'var(--sp-3)', lineHeight: 1.15 }}>Iratkozz fel hírlevelünkre</h2>
            <p style={{ fontSize: 'var(--fs-md)', color: 'rgba(255,255,255,0.55)', marginBottom: 'var(--sp-8)', lineHeight: 1.7 }}>Értesülj elsőként az akciókról, új termékekről és kerékpáros tippekről.</p>
            {submitted ? (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, color: 'var(--success)', fontWeight: 600, fontSize: 'var(--fs-md)' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                Köszönjük! Hamarosan hallasz rólunk.
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: 'flex', gap: 'var(--sp-3)', maxWidth: 440, margin: '0 auto' }}>
                <input
                  type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="E-mail cím..." required
                  style={{ flex: 1, height: 52, padding: '0 var(--sp-5)', background: 'rgba(255,255,255,0.08)', border: '1.5px solid rgba(255,255,255,0.12)', borderRadius: 'var(--r-full)', color: 'white', fontFamily: 'var(--font-body)', fontSize: 'var(--fs-sm)', outline: 'none', transition: 'border-color var(--t-fast)' }}
                  onFocus={e => e.target.style.borderColor = 'var(--coral)'}
                  onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.12)'}
                />
                <button type="submit" className="btn btn-primary" style={{ flexShrink: 0, height: 52 }}>Feliratkozás</button>
              </form>
            )}
          </div>
        </FadeIn>
      </div>
    </section>
  );
}