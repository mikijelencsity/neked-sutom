const BASE = '';

let refreshing = null;
let accessToken = null;

// Token kezelés
export function setAccessToken(token) {
  accessToken = token;
  if (token) {
    localStorage.setItem('cruiser_access_token', token);
  } else {
    localStorage.removeItem('cruiser_access_token');
  }
}

export function getAccessToken() {
  if (!accessToken) {
    accessToken = localStorage.getItem('cruiser_access_token');
  }
  return accessToken;
}

export function clearAccessToken() {
  accessToken = null;
  localStorage.removeItem('cruiser_access_token');
}

async function api(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  // Access token hozzáadása ha van
  const token = getAccessToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers,
    credentials: 'include',
  });

  // 401 esetén próbáljunk refresh-elni
  if (res.status === 401 && !options._retry) {
    if (!refreshing) {
      refreshing = fetch('/api/auth/refresh', {
        method: 'POST',
        credentials: 'include',
      })
        .then(async (refreshRes) => {
          if (refreshRes.ok) {
            const data = await refreshRes.json();
            if (data.accessToken) {
              setAccessToken(data.accessToken);
            }
            return true;
          }
          // Refresh sikertelen - töröljük a tokent
          clearAccessToken();
          return false;
        })
        .catch(() => {
          clearAccessToken();
          return false;
        })
        .finally(() => { refreshing = null; });
    }
    
    const refreshed = await refreshing;
    if (refreshed) {
      return api(path, { ...options, _retry: true });
    }
  }

  return res;
}

export default api;